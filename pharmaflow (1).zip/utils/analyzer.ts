
/**
 * تم حذف محتوى هذا الملف ودمجه مع accounting.service.ts
 */
export {};
