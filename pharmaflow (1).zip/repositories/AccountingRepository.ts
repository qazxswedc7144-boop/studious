import { db } from '../services/database';
import { AccountingEntry, CashFlow, Transaction } from '../types';

export const AccountingRepository = {
  getEntries: (): AccountingEntry[] => {
    return db.getJournalEntries();
  },

  getCashFlow: (): CashFlow[] => {
    return db.getCashFlow();
  },

  getTransactions: (): Transaction[] => {
    return db.getTransactions();
  },

  getAccountBalance: (accountName: string): number => {
    return db.getAccountBalance(accountName);
  },

  isDateLocked: (date: string): boolean => {
    return db.isDateLocked(date);
  },

  addJournalEntry: async (entry: AccountingEntry) => {
    await db.addJournalEntry(entry);
  }
};