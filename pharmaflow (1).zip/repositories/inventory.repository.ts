
import { db } from '../services/database';
import { Product } from '../types';

export const InventoryRepository = {
  getAll: (): Product[] => db.getProducts(),

  getById: (id: string): Product | undefined => 
    db.getProducts().find(p => p.ProductID === id || p.product_id === id),

  getByBarcode: (barcode: string): Product | undefined => 
    db.getProductByBarcode(barcode),

  save: async (product: Product) => {
    await db.saveProduct(product);
  },

  delete: async (id: string) => {
    const list = db.getProducts().filter(p => p.ProductID !== id);
    await db.persist('products', list, 'ProductID');
  },

  updateStock: async (productId: string, quantityChange: number) => {
    const product = InventoryRepository.getById(productId);
    if (product) {
      product.StockQuantity += quantityChange;
      await db.saveProduct(product);
    }
  },

  search: (term: string): Product[] => {
    const lower = term.toLowerCase();
    return db.getProducts().filter(p => 
      p.Name.toLowerCase().includes(lower) || 
      p.ProductID.includes(term) ||
      (p.barcode && p.barcode.includes(term))
    );
  }
};
