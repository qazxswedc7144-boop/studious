
import { db } from '../services/database';
import { AccountingPeriod } from '../types';

export const AccountingPeriodRepository = {
  getAll: (): AccountingPeriod[] => {
    return db.getAccountingPeriods();
  },

  getActivePeriod: (): AccountingPeriod | undefined => {
    return db.getAccountingPeriods().find(p => !p.isClosed);
  },

  isDateClosed: (dateStr: string): boolean => {
    const periods = db.getAccountingPeriods();
    const date = new Date(dateStr);
    return periods.some(p => p.isClosed && date >= new Date(p.startDate) && date <= new Date(p.endDate));
  },

  closePeriod: async (periodId: string, userId: string) => {
    const periods = db.getAccountingPeriods();
    const idx = periods.findIndex(p => p.id === periodId);
    if (idx > -1) {
      periods[idx].isClosed = true;
      periods[idx].closedBy = userId;
      periods[idx].closedAt = new Date().toISOString();
      await db.saveAccountingPeriod(periods[idx]);
    }
  },

  createPeriod: async (period: AccountingPeriod) => {
    await db.saveAccountingPeriod(period);
  }
};
