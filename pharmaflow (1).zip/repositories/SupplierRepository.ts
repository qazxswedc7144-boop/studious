
import { db } from '../services/database';
import { Supplier, SupplierLedgerEntry, PurchaseRecord, PartnerLedgerEntry } from '../types';

/**
 * Supplier Repository - إدارة الموردين والعملاء مع دعم الرصيد التراكمي الثابت
 */
export const SupplierRepository = {
  getSuppliers: (): Supplier[] => {
    return db.getSuppliers();
  },

  getCustomers: (): Supplier[] => {
    return db.getCustomers();
  },

  getById: (id: string, type: 'S' | 'C'): Supplier | undefined => {
    const list = type === 'S' ? db.getSuppliers() : db.getCustomers();
    return list.find(p => p.id === id);
  },

  /**
   * جلب كشف حساب حقيقي من جدول الـ Ledger مع الأرصدة التراكمية المحفوظة
   */
  getLedger: (partnerId: string): SupplierLedgerEntry[] => {
    return db.getPartnerLedger(partnerId);
  },

  /**
   * جلب الرصيد الحالي فوراً من آخر حركة مسجلة في الـ Ledger
   */
  getPartnerBalance: (partnerId: string, type: 'S' | 'C'): number => {
    const latest = db.getLatestPartnerLedgerEntry(partnerId);
    if (!latest) {
      const partner = SupplierRepository.getById(partnerId, type);
      return partner?.openingBalance || 0;
    }
    return latest.runningBalance;
  },

  save: async (partner: Supplier, type: 'S' | 'C') => {
    if (type === 'S') await db.saveSupplier(partner);
    else await db.saveCustomer(partner);
  },

  /**
   * ترحيل حركة مالية وحساب الرصيد التراكمي الجديد بناءً على النوع (عميل/مورد)
   */
  postToLedger: async (entry: Omit<PartnerLedgerEntry, 'runningBalance'>) => {
    const type = entry.partnerId.startsWith('S') ? 'S' : 'C';
    const lastEntry = db.getLatestPartnerLedgerEntry(entry.partnerId);
    
    let currentBalance = 0;
    if (lastEntry) {
      currentBalance = lastEntry.runningBalance;
    } else {
      const partner = SupplierRepository.getById(entry.partnerId, type);
      currentBalance = partner?.openingBalance || 0;
    }

    let newBalance = currentBalance;
    if (type === 'S') {
      // مورد: الرصيد = الدائن (له) - المدين (عليه)
      newBalance += (entry.credit - entry.debit);
    } else {
      // عميل: الرصيد = المدين (عليه) - الدائن (له)
      newBalance += (entry.debit - entry.credit);
    }

    const finalEntry: PartnerLedgerEntry = {
      ...entry,
      runningBalance: newBalance
    };

    await db.addPartnerLedgerEntry(finalEntry);
  },

  /**
   * تحديث تاريخ مشتريات المورد
   */
  savePurchaseRecord: async (record: PurchaseRecord, supplierId: string) => {
    await db.savePurchase(record, supplierId);
  }
};
