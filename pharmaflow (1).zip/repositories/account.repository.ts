
import { db } from '../services/database';
import { Account, AccountingEntry } from '../types';

export const AccountRepository = {
  // --- دليل الحسابات ---
  getAccounts: (): Account[] => db.getAccounts(),

  getAccountById: (id: string): Account | undefined =>
    db.getAccounts().find(a => a.id === id),

  saveAccount: async (account: Account) => {
    await db.saveAccount(account);
  },

  deleteAccount: async (id: string) => {
    await db.deleteAccount(id);
  },

  // --- القيود اليومية ---
  getJournalEntries: (): AccountingEntry[] => db.getJournalEntries(),

  addEntry: async (entry: AccountingEntry) => {
    await db.addJournalEntry(entry);
  },

  getAccountBalance: (accountName: string): number => {
    return db.getAccountBalance(accountName);
  },

  isDateLocked: (date: string): boolean => {
    return db.isDateLocked(date);
  }
};
