
import { db } from '../services/database';
import { Sale, Purchase } from '../types';

export const InvoiceRepository = {
  // --- المبيعات ---
  getSales: (): Sale[] => db.getSales(),
  
  getSaleById: (id: string): Sale | undefined => 
    db.getSales().find(s => s.SaleID === id || s.sale_id === id),

  saveSale: async (customerId: string, items: any[], subtotal: number, isReturn: boolean, inv: string, curr: string, status: string) => {
    return db.processSale(customerId, items, subtotal, isReturn, inv, curr, status);
  },

  // --- المشتريات ---
  getPurchases: (): Purchase[] => db.getPurchases(),

  getPurchaseById: (id: string): Purchase | undefined =>
    db.getPurchases().find(p => p.purchase_id === id || p.invoiceId === id),

  savePurchase: async (supplierId: string, items: any[], subtotal: number, inv: string, isCash: boolean) => {
    return db.processPurchase(supplierId, items, subtotal, inv, isCash);
  },

  getNextPurchaseNumber: (): string => {
    const purchases = db.getPurchases();
    if (!purchases.length) return "1";
    const nums = purchases.map(p => parseInt(p.invoiceId)).filter(n => !isNaN(n));
    return nums.length ? (Math.max(...nums) + 1).toString() : "1";
  },

  isInvoiceNumberUnique: (invNum: string): boolean => {
    return !db.getPurchases().some(p => p.invoiceId === invNum);
  }
};
