
import { db } from '../services/database';
import { Purchase } from '../types';

export const PurchaseRepository = {
  getAll: (): Purchase[] => {
    return db.getPurchases();
  },

  /**
   * تنفيذ معادلة: MAX(Purchases[رقم الفاتورة]) + 1
   */
  getNextInvoiceNumber: (): string => {
    const purchases = db.getPurchases();
    if (!purchases || purchases.length === 0) return "1";
    
    const numericIds = purchases
      .map(p => parseInt(p.invoiceId))
      .filter(n => !isNaN(n));
      
    if (numericIds.length === 0) return "1";
    return (Math.max(...numericIds) + 1).toString();
  },

  /**
   * التحقق من فرادة رقم الفاتورة لمورد محدد
   * يسمح بتكرار الرقم بين موردين مختلفين ولكن يمنعه لنفس المورد
   */
  isInvoiceDuplicateForSupplier: (invNum: string, supplier: string): boolean => {
    if (!invNum || !supplier) return false;
    const purchases = db.getPurchases();
    return purchases.some(p => 
      p.invoiceId === invNum && 
      (p.partnerId === supplier || p.partnerName === supplier)
    );
  },

  /**
   * تنفيذ قاعدة التحقق العامة: ISBLANK(FILTER("Purchases", ([_THIS] = [رقم الفاتورة])))
   */
  isInvoiceNumberUnique: (invNum: string): boolean => {
    if (!invNum) return true;
    const purchases = db.getPurchases();
    return !purchases.some(p => p.invoiceId === invNum);
  },

  save: async (purchase: any) => {
    // منطق الحفظ من خلال الـ database service
  }
};
