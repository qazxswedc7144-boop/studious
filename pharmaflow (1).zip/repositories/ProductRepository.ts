
import { db } from '../services/database';
import { Product } from '../types';

export const ProductRepository = {
  getAll: (): Product[] => {
    return db.getProducts();
  },

  getById: (id: string): Product | undefined => {
    return db.getProducts().find(p => p.ProductID === id || p.product_id === id);
  },

  getByBarcode: (barcode: string): Product | undefined => {
    return db.getProductByBarcode(barcode);
  },

  search: (term: string): Product[] => {
    const lowerTerm = term.toLowerCase();
    return db.getProducts().filter(p => 
      p.Name.toLowerCase().includes(lowerTerm) || 
      p.ProductID.includes(term) ||
      (p.barcode && p.barcode.includes(term))
    );
  },

  updateStock: async (productId: string, quantityChange: number) => {
    const product = ProductRepository.getById(productId);
    if (product) {
      product.StockQuantity += quantityChange;
      await db.saveProduct(product);
    }
  }
};
