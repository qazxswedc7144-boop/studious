
import { db } from '../services/database';
import { Sale } from '../types';

/**
 * Sales Repository - المسؤول عن الوصول لبيانات المبيعات
 */
export const SalesRepository = {
  getAll: (): Sale[] => {
    return db.getSales();
  },

  getById: (id: string): Sale | undefined => {
    return db.getSales().find(s => s.SaleID === id || s.sale_id === id);
  },

  getByCustomerId: (customerId: string): Sale[] => {
    return db.getSales().filter(s => s.CustomerID === customerId);
  },

  /**
   * تنفيذ عملية حفظ البيع في قاعدة البيانات
   */
  process: async (customerId: string, items: any[], subtotal: number, isReturn: boolean, inv: string, curr: string, status: string) => {
    return db.processSale(customerId, items, subtotal, isReturn, inv, curr, status);
  }
};
