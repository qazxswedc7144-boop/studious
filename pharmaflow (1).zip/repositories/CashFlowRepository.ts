
import { db } from '../services/database';
import { CashFlow } from '../types';

/**
 * CashFlow Repository - إدارة سجلات النقدية والسندات
 */
export const CashFlowRepository = {
  getAll: (): CashFlow[] => {
    return db.getCashFlow();
  },

  getVouchers: (): CashFlow[] => {
    return db.getCashFlow().filter(h => h.notes?.includes('سند'));
  },

  /**
   * تسجيل حركة نقدية جديدة
   */
  record: async (type: 'دخل' | 'خرج', category: string, amount: number, notes?: string) => {
    return db.recordCashFlow(type, category, amount, notes);
  }
};
