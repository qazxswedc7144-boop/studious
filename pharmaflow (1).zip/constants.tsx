
export const MODELS = {
  BASIC_TEXT: 'gemini-3-flash-preview',
  COMPLEX_TEXT: 'gemini-3-pro-preview',
  FAST_LITE: 'gemini-flash-lite-latest',
  IMAGE_GEN_PRO: 'gemini-3-pro-image-preview',
  IMAGE_EDIT: 'gemini-2.5-flash-image',
  VIDEO_GEN: 'veo-3.1-fast-generate-preview',
  AUDIO_TTS: 'gemini-2.5-flash-preview-tts',
  MAPS_GROUNDING: 'gemini-2.5-flash',
};

export const COLORS = {
  primary: '#3b82f6',
  secondary: '#8b5cf6',
  accent: '#f43f5e',
  background: '#0f172a',
  surface: '#1e293b',
};
