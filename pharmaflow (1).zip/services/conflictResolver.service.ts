
import { db } from './database';

/**
 * Conflict Resolver Service
 * المسؤول عن تحديد "الفائز" عند وجود نسختين مختلفتين من نفس السجل
 */
export const conflictResolver = {
  
  /**
   * حل التضارب بناءً على استراتيجية الأحدث (Last Write Wins)
   */
  resolve<T extends { lastModified?: string; date?: string; updatedAt?: string }>(local: T, remote: T): T {
    const localTime = new Date(local.lastModified || local.date || local.updatedAt || 0).getTime();
    const remoteTime = new Date(remote.lastModified || remote.date || remote.updatedAt || 0).getTime();

    if (localTime >= remoteTime) {
      console.log(`[ConflictResolver] Local version won (Time: ${localTime} vs ${remoteTime})`);
      return local;
    }

    console.log(`[ConflictResolver] Remote version won (Time: ${remoteTime} vs ${localTime})`);
    return remote;
  },

  /**
   * دمج التغييرات (Merge) للحقول غير المتعارضة
   */
  merge<T extends object>(local: T, remote: T): T {
    // منطق الدمج الذكي: الحقول الفارغة محلياً تُستبدل بالريموت والعكس
    const merged = { ...remote, ...local };
    
    // توثيق عملية الدمج في سجل الرقابة إذا كانت بيانات حساسة
    if ('amount' in merged || 'StockQuantity' in merged) {
       db.addAuditLog("دمج بيانات", "SyncEngine", "تم دمج نسختين من سجل مالي لضمان التزامن", "info");
    }

    return merged;
  },

  /**
   * التحقق من وجود تضارب فعلي (Deep Content Check)
   */
  hasConflict(local: any, remote: any): boolean {
    if (!local || !remote) return false;
    // استثناء الحقول التقنية من المقارنة
    const keys = Object.keys(local).filter(k => !['lastModified', 'version', 'syncStatus'].includes(k));
    return keys.some(key => JSON.stringify(local[key]) !== JSON.stringify(remote[key]));
  }
};
