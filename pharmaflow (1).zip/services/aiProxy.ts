
import { GoogleGenAI, GenerateContentResponse } from "@google/genai";

/**
 * AI Proxy Service
 * يعمل كطبقة وسيطة (Proxy) لمحاكاة سلوك الـ Backend.
 * هذا هو المكان الوحيد الذي يتعامل مع مفاتيح البيئة و SDK.
 */
class AIProxyService {
  /**
   * إنشاء عميل GoogleGenAI بشكل آمن
   */
  private getClient() {
    const apiKey = process.env.API_KEY;
    if (!apiKey) {
      throw new Error("SECURITY_ERROR: API_KEY is missing from environment. Access Denied.");
    }
    return new GoogleGenAI({ apiKey });
  }

  /**
   * إرسال طلب توليد محتوى (Text/JSON/Multi-part)
   * يحاكي endpoint: POST /api/ai/generate
   */
  async generateContent(model: string, contents: any, config?: any): Promise<GenerateContentResponse> {
    const ai = this.getClient();
    // تنفيذ الطلب عبر SDK مع عزل المفتاح في هذه الطبقة فقط
    return await ai.models.generateContent({
      model,
      contents,
      config
    });
  }

  /**
   * إرسال طلب دردشة (Chat Session)
   * يحاكي endpoint: POST /api/ai/chat
   */
  async sendMessage(model: string, message: string, config?: any): Promise<GenerateContentResponse> {
    const ai = this.getClient();
    const chat = ai.chats.create({
      model,
      config
    });
    return await chat.sendMessage({ message });
  }
}

export const aiProxy = new AIProxyService();
