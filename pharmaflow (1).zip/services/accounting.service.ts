
import { db } from './database';
import { CashFlow, AccountingEntry, IntegrityReport } from '../types';
import { createVoucherJournal } from '../accounting/AutoJournalMapper';
import { dataValidator } from './validators/dataValidator';
import { AccountRepository } from '../repositories/account.repository';
import { InvoiceRepository } from '../repositories/invoice.repository';
import { CashFlowRepository } from '../repositories/CashFlowRepository';
import { reportCache } from './reportCache.service';
import { periodService } from './period.service';

export const accountingService = {
  
  /**
   * المقاييس المالية (مكثفة حسابياً)
   */
  getFinancialMetrics: () => {
    const cacheKey = 'financial_metrics_core';
    const cached = reportCache.get<any>(cacheKey);
    if (cached) return cached;

    try {
      const sales = InvoiceRepository.getSales();
      const cashflow = CashFlowRepository.getAll();
      const expenses = cashflow.filter(t => t.type === 'خرج' && !t.notes?.includes('مشتريات')).reduce((acc, t) => acc + t.amount, 0);
      const totalRevenue = sales.reduce((acc, s) => acc + (s.FinalTotal || s.finalTotal || 0), 0);
      const totalCOGS = sales.reduce((acc, s) => acc + (s.total_cost || s.totalCost || 0), 0);
      const grossProfit = totalRevenue - totalCOGS;
      const netProfit = grossProfit - expenses;
      const margin = totalRevenue > 0 ? (grossProfit / totalRevenue) * 100 : 0;
      
      const metrics = { income: totalRevenue, outcome: totalCOGS + expenses, net: netProfit, margin, grossProfit, cogs: totalCOGS };
      
      // تخزين النتيجة للاستخدام اللاحق
      reportCache.set(cacheKey, metrics);
      return metrics;
    } catch (e) { return { income: 0, outcome: 0, net: 0, margin: 0, grossProfit: 0, cogs: 0 }; }
  },

  getJournalEntries: (): AccountingEntry[] => AccountRepository.getJournalEntries(),
  getEntries: (): AccountingEntry[] => AccountRepository.getJournalEntries(),
  
  addEntry: async (entry: AccountingEntry) => { 
    periodService.validatePeriod(entry.date);
    dataValidator.validateAccountingEntry(entry); 
    await AccountRepository.addEntry(entry); 
    // أي إضافة قيد ستقوم بتحديث نسخة الـ DB آلياً وإبطال الكاش
  },
  
  getAccountBalance: (accountName: string): number => AccountRepository.getAccountBalance(accountName),

  recordVoucher: async (type: 'دخل' | 'خرج', name: string, amount: number, category: string, notes: string) => {
    const today = new Date().toISOString();
    periodService.validatePeriod(today);

    return db.runTransaction(async () => {
      if (!name || amount <= 0) throw new Error("بيانات السند غير مكتملة.");
      const voucherId = db.generateId('V');
      const journalEntry = createVoucherJournal({ id: voucherId, type, amount, name, category, notes });
      dataValidator.validateAccountingEntry(journalEntry);
      
      await AccountRepository.addEntry(journalEntry);
      await CashFlowRepository.record(type, category, amount, `سند #${voucherId} لـ: ${name} | ${notes}`);
      
      return voucherId;
    });
  },

  getCashFlow: (): CashFlow[] => CashFlowRepository.getAll(),
  runIntegrityCheck: (): IntegrityReport => db.generateIntegrityReport(),

  /**
   * تنفيذ تسوية آلية لمطابقة الأرصدة المكتشفة في فحص النزاهة
   */
  performAutoAdjustment: async (pointId: string, diff: number) => {
    return db.runTransaction(async () => {
      const today = new Date().toISOString();
      periodService.validatePeriod(today);
      
      const entryId = db.generateId('ENT');
      const entry: AccountingEntry = {
        EntryID: entryId,
        id: entryId,
        date: today,
        description: `تسوية آلية لـ ${pointId}`,
        TotalAmount: Math.abs(diff),
        totalAmount: Math.abs(diff),
        Status: 'Posted',
        status: 'Posted',
        SourceID: pointId,
        sourceId: pointId,
        EntryType: "ADJUSTMENT",
        sourceType: "ADJUSTMENT",
        notes: "تم توليد هذا القيد آلياً لمطابقة أرصدة الأستاذ مع السجلات الفرعية",
        branchId: db.getCurrentBranchId(),
        lines: [
          {
            lineId: db.generateId('DET'),
            entryId,
            accountId: 'ACC-ADJ',
            accountName: 'تسويات فنية',
            debit: diff < 0 ? Math.abs(diff) : 0,
            credit: diff > 0 ? Math.abs(diff) : 0,
            type: diff < 0 ? 'DEBIT' : 'CREDIT',
            amount: Math.abs(diff)
          },
          {
            lineId: db.generateId('DET'),
            entryId,
            accountId: 'ACC-OFF',
            accountName: 'حساب موازنة التسوية',
            debit: diff > 0 ? Math.abs(diff) : 0,
            credit: diff < 0 ? Math.abs(diff) : 0,
            type: diff > 0 ? 'DEBIT' : 'CREDIT',
            amount: Math.abs(diff)
          }
        ]
      };

      dataValidator.validateAccountingEntry(entry);
      await AccountRepository.addEntry(entry);
    });
  },
  
  getInventoryInsights: () => {
    const cacheKey = 'inventory_insights';
    const cached = reportCache.get<any>(cacheKey);
    if (cached) return cached;

    const products = db.getProducts();
    const today = new Date();
    const nextMonth = new Date();
    nextMonth.setMonth(today.getMonth() + 1);
    
    const insights = {
      criticalStock: products.filter(p => p.StockQuantity <= p.MinLevel),
      expiringSoon: products.filter(p => p.ExpiryDate && new Date(p.ExpiryDate) <= nextMonth)
    };
    
    reportCache.set(cacheKey, insights);
    return insights;
  },

  getTopProfitableItems: (limit: number = 5) => {
    const cacheKey = `top_profitable_${limit}`;
    const cached = reportCache.get<any>(cacheKey);
    if (cached) return cached;

    const products = db.getProducts();
    const result = [...products].sort((a, b) => (b.UnitPrice - b.CostPrice) - (a.UnitPrice - a.CostPrice)).slice(0, limit);
    
    reportCache.set(cacheKey, result);
    return result;
  },

  getChartAnalytics: (days: number = 30) => {
    const cacheKey = `chart_analytics_${days}`;
    const cached = reportCache.get<any>(cacheKey);
    if (cached) return cached;

    const sales = InvoiceRepository.getSales();
    const cashflow = CashFlowRepository.getAll();
    const labels = [];
    const revenue = [];
    const expense = [];
    for (let i = days - 1; i >= 0; i--) {
      const d = new Date();
      d.setDate(d.getDate() - i);
      const dateStr = d.toISOString().split('T')[0];
      const daySales = sales.filter(s => (s.Date || s.date || "").startsWith(dateStr));
      const dayTotalRevenue = daySales.reduce((sum, s) => sum + (s.FinalTotal || s.finalTotal || 0), 0);
      const dayExpenses = cashflow.filter(t => t.type === 'خرج' && t.date.startsWith(dateStr));
      const dayTotalExpense = dayExpenses.reduce((sum, t) => sum + t.amount, 0);
      labels.push(dateStr);
      revenue.push(dayTotalRevenue);
      expense.push(dayTotalExpense);
    }
    
    const result = { labels, revenue, expense };
    reportCache.set(cacheKey, result);
    return result;
  },

  getWeeklyPerformanceData: () => {
    const cacheKey = 'weekly_perf_v2';
    const cached = reportCache.get<any[]>(cacheKey);
    if (cached) return cached;

    const sales = InvoiceRepository.getSales();
    const dayNamesAr = ['ح', 'ن', 'ث', 'أ', 'خ', 'ج', 'س'];
    const weeklyData = [];
    const today = new Date();
    for (let i = 6; i >= 0; i--) {
      const d = new Date();
      d.setDate(today.getDate() - i);
      const dateStr = d.toISOString().split('T')[0];
      const daySales = sales.filter(s => (s.Date || s.date || "").startsWith(dateStr));
      const dayTotalRevenue = daySales.reduce((sum, s) => sum + (s.FinalTotal || s.finalTotal || 0), 0);
      weeklyData.push({ dayNum: d.getDate(), dayLetter: dayNamesAr[d.getDay()], value: dayTotalRevenue > 0 ? Math.min((dayTotalRevenue / 5000) * 100, 100) : 0, actualValue: dayTotalRevenue, isToday: i === 0 });
    }
    
    reportCache.set(cacheKey, weeklyData);
    return weeklyData;
  },

  getPredictedCashflow: (daysAhead: number = 7) => {
    const cacheKey = `predicted_cf_${daysAhead}`;
    const cached = reportCache.get<number[]>(cacheKey);
    if (cached) return cached;

    const weeklyData = accountingService.getWeeklyPerformanceData();
    const data = weeklyData.map(d => d.actualValue);
    if (data.length < 2) return Array(daysAhead).fill(0);
    let sumX = 0, sumY = 0, sumXY = 0, sumX2 = 0;
    const n = data.length;
    data.forEach((y, x) => { sumX += x; sumY += y; sumXY += x * y; sumX2 += x * x; });
    const slope = (n * sumXY - sumX * sumY) / (n * sumX2 - sumX * sumX);
    const intercept = (sumY - slope * sumX) / n;
    const predictions = [];
    for (let i = 1; i <= daysAhead; i++) {
      const nextY = slope * (n + i) + intercept;
      predictions.push(Math.max(0, Math.round(nextY)));
    }
    
    reportCache.set(cacheKey, predictions);
    return predictions;
  }
};
