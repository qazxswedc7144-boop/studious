
import { db } from './database';
import { PendingOperation } from '../types';
import { conflictResolver } from './conflictResolver.service';

/**
 * Sync Service - محرك المزامنة الذكي
 * تم تحديثه ليدعم حل النزاعات وحماية البيانات المالية
 */
export const syncService = {
  isProcessing: false,

  /**
   * تنفيذ المزامنة لكامل الطابور مع حماية التضارب
   */
  performSync: async (): Promise<boolean> => {
    if (syncService.isProcessing || !navigator.onLine) return false;
    
    syncService.isProcessing = true;
    const queue = db.getPendingOperations().filter(op => op.status !== 'syncing');

    if (queue.length === 0) {
      syncService.isProcessing = false;
      return true;
    }

    console.log(`[SyncEngine] Processing ${queue.length} operations with Conflict Protection.`);

    for (const op of queue) {
      try {
        await syncService.processOperation(op);
      } catch (error: any) {
        console.error(`[SyncEngine] Operation ${op.id} failed:`, error);
        if (!navigator.onLine) break;
      }
    }

    syncService.isProcessing = false;
    db.updateSyncDate();
    return true;
  },

  /**
   * معالجة عملية واحدة مع فحص التضارب
   */
  processOperation: async (op: PendingOperation) => {
    db.updatePendingOperation({ ...op, status: 'syncing' });

    // محاكاة استرجاع النسخة الحالية من "السيرفر" للمقارنة
    await new Promise(resolve => setTimeout(resolve, 500));
    
    // محاكاة اكتشاف تضارب (بشكل منطقي بدلاً من عشوائي)
    const mockRemoteData = null; // في حالة حقيقية، نطلب السجل من السيرفر هنا
    
    if (mockRemoteData && conflictResolver.hasConflict(op.payload, mockRemoteData)) {
       console.warn(`[SyncEngine] Conflict detected for ${op.id}. Invoking Resolver.`);
       const resolvedData = conflictResolver.resolve(op.payload, mockRemoteData);
       op.payload = resolvedData; 
       db.addAuditLog("حل تضارب", op.type, `تم حل نزاع بيانات للعملية ${op.id} آلياً`, "warning");
    }

    // محاكاة نجاح الترحيل النهائي للسيرفر
    const success = Math.random() > 0.05; 

    if (success) {
      db.removePendingOperation(op.id);
      console.log(`[SyncEngine] Successfully synced ${op.type} (Ref: ${op.id})`);
    } else {
      const updatedOp: PendingOperation = {
        ...op,
        status: 'failed',
        retries: op.retries + 1,
        lastError: 'Server Acknowledgement Failed'
      };
      
      if (updatedOp.retries >= 5) {
         db.removePendingOperation(op.id); 
         db.addAuditLog("فشل مزامنة نهائي", op.type, `فشل ترحيل العملية ${op.id} بعد 5 محاولات`, 'critical');
      } else {
         db.updatePendingOperation(updatedOp);
      }
      throw new Error("Sync Fail");
    }
  },

  enqueue: (type: string, payload: any) => {
    // إضافة طابع زمني للعملية لدعم حل التضارب لاحقاً
    const payloadWithMeta = {
      ...payload,
      lastModified: new Date().toISOString()
    };
    
    db.addPendingOperation({ type, payload: payloadWithMeta });
    
    if ('serviceWorker' in navigator && 'SyncManager' in window) {
      navigator.serviceWorker.ready.then(reg => {
        return (reg as any).sync.register('pharma-sync-task');
      }).catch(() => {
        if (navigator.onLine) syncService.performSync();
      });
    } else if (navigator.onLine) {
      syncService.performSync();
    }
  },

  hasPendingSync: (): boolean => {
    return db.getPendingOperations().length > 0;
  },

  getPendingCount: (): number => {
    return db.getPendingOperations().length;
  }
};
