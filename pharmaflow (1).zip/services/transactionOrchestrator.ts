
import { db } from './database';
import { dataValidator } from './validators/dataValidator';
import { createSaleJournal, createPurchaseJournal } from '../accounting/AutoJournalMapper';
import { syncService } from './sync.service';
import { PartnerLedgerEntry, PurchaseRecord } from '../types';
import { InvoiceRepository } from '../repositories/invoice.repository';
import { AccountRepository } from '../repositories/account.repository';
import { SupplierRepository } from '../repositories/SupplierRepository';

export const transactionOrchestrator = {
  
  async processInvoiceTransaction(invoice: { 
    type: 'SALE' | 'PURCHASE', 
    payload: any, 
    options?: any 
  }): Promise<{ success: boolean; error?: string }> {
    try {
      return await db.runTransaction(async () => {
        if (invoice.type === 'SALE') {
          await this.executeSaleTransaction(
            invoice.payload.customerId, 
            invoice.payload.cart, 
            invoice.payload.total, 
            invoice.options || {}
          );
        } else if (invoice.type === 'PURCHASE') {
          await this.executePurchaseTransaction(
            invoice.payload.supplierId, 
            invoice.payload.items, 
            invoice.payload.total, 
            invoice.payload.invoiceId, 
            invoice.options?.isCash || false,
            invoice.options?.isReturn || false
          );
        } else {
          throw new Error("نوع الفاتورة غير مدعوم.");
        }
        return { success: true };
      });
    } catch (error: any) {
      await db.addAuditLog("فشل ترحيل ذرّي", invoice.type, error.message, 'critical');
      return { success: false, error: error.message };
    }
  },

  async executeSaleTransaction(customerId: string, cart: any[], total: number, options: any) {
    dataValidator.validateSale(customerId, cart, total);
    
    const { sale_id, totalSaleCost } = await InvoiceRepository.saveSale(
      customerId, cart, total, options.isReturn || false, options.customInvNum, options.currency, options.paymentStatus
    );

    const journals = createSaleJournal({
      id: sale_id,
      total: total,
      cost: totalSaleCost,
      paymentStatus: options.paymentStatus,
      isReturn: options.isReturn || false
    });

    for (const entry of journals) {
      dataValidator.validateAccountingEntry(entry);
      await AccountRepository.addEntry(entry);
    }

    if (options.paymentStatus === 'Credit' && customerId !== 'CASH') {
      const isRet = options.isReturn || false;
      const ledgerEntry: Omit<PartnerLedgerEntry, 'runningBalance'> = {
        id: db.generateId('PL'),
        partnerId: customerId,
        date: new Date().toISOString(),
        description: `فاتورة بيع ${isRet ? 'مرتجعة' : 'آجلة'} #${sale_id}`,
        debit: isRet ? 0 : total,
        credit: isRet ? total : 0,
        referenceId: sale_id,
        type: 'SALE'
      };
      await SupplierRepository.postToLedger(ledgerEntry);
    }

    db.addAuditLog("مبيعات", sale_id, `تم ترحيل فاتورة بقيمة ${total}`, 'info');
    syncService.enqueue('CREATE_SALE', { sale_id, customerId, total, cart });

    return sale_id;
  },

  async executePurchaseTransaction(supplierId: string, items: any[], total: number, invoiceId?: string, isCash: boolean = false, isReturn: boolean = false) {
    dataValidator.validatePurchase(supplierId, items, total, invoiceId);

    const { purchase_id } = await InvoiceRepository.savePurchase(supplierId, items, total, invoiceId || '', isCash);
    
    const record: PurchaseRecord = {
      id: purchase_id,
      date: new Date().toISOString().split('T')[0],
      amount: total,
      status: isCash ? 'paid' : 'pending',
      items: items.map(i => `${i.product_id} (x${i.qty})`)
    };
    await SupplierRepository.savePurchaseRecord(record, supplierId);

    const journals = createPurchaseJournal({ id: purchase_id, total: total, isCash: isCash, isReturn: isReturn });
    for (const entry of journals) {
      dataValidator.validateAccountingEntry(entry);
      await AccountRepository.addEntry(entry);
    }

    if (!isCash) {
      const ledgerEntry: Omit<PartnerLedgerEntry, 'runningBalance'> = {
        id: db.generateId('PL'),
        partnerId: supplierId,
        date: new Date().toISOString(),
        description: `فاتورة مشتريات ${isReturn ? 'مرتجعة' : 'آجلة'} #${invoiceId || purchase_id}`,
        debit: isReturn ? total : 0,
        credit: isReturn ? 0 : total,
        referenceId: purchase_id,
        type: 'PURCHASE'
      };
      await SupplierRepository.postToLedger(ledgerEntry);
    }

    db.addAuditLog("مشتريات", purchase_id, `تم ترحيل فاتورة بقيمة ${total}`, 'info');
    syncService.enqueue('CREATE_PURCHASE', { purchase_id, supplierId, total, items, invoiceId, isReturn });

    return purchase_id;
  }
};
