
/**
 * Export Service - محرك تصدير التقارير الذكي
 */
export const ExportService = {
  /**
   * تصدير البيانات إلى ملف Excel (CSV)
   */
  exportToExcel: (data: any[], fileName: string, headers: string[]) => {
    // بناء محتوى CSV مع دعم الترميز العربي (UTF-8 BOM)
    const BOM = '\uFEFF';
    let csvContent = headers.join(',') + '\n';
    
    data.forEach(row => {
      const values = Object.values(row).map(v => `"${v}"`);
      csvContent += values.join(',') + '\n';
    });

    const blob = new Blob([BOM + csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);
    
    link.setAttribute('href', url);
    link.setAttribute('download', `${fileName}_${new Date().toLocaleDateString('en-GB')}.csv`);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  },

  /**
   * تصدير التقرير بصيغة PDF عبر نافذة طباعة مخصصة
   */
  exportToPDF: (title: string, headers: string[], rows: any[][], summary?: { label: string, value: string }[]) => {
    const printWindow = window.open('', '_blank');
    if (!printWindow) return;

    const html = `
      <html dir="rtl">
        <head>
          <title>${title}</title>
          <script src="https://cdn.tailwindcss.com"></script>
          <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;700;900&display=swap" rel="stylesheet">
          <style>
            body { font-family: 'Cairo', sans-serif; padding: 40px; }
            @media print { .no-print { display: none; } }
          </style>
        </head>
        <body>
          <div class="flex justify-between items-center mb-10 pb-6 border-b-2 border-slate-100">
            <div>
              <h1 class="text-3xl font-black text-[#1E4D4D]">PharmaFlow</h1>
              <p class="text-xs font-bold text-slate-400 tracking-widest">نظام إدارة الصيدلية الذكي</p>
            </div>
            <div class="text-left">
              <h2 class="text-2xl font-black text-slate-800">${title}</h2>
              <p class="text-[10px] font-bold text-slate-400">تاريخ التقرير: ${new Date().toLocaleString('ar-SA')}</p>
            </div>
          </div>

          <table class="w-full text-right mb-10 border-collapse">
            <thead>
              <tr class="bg-slate-50 border-b-2 border-slate-200">
                ${headers.map(h => `<th class="py-4 px-3 text-xs font-black text-slate-600">${h}</th>`).join('')}
              </tr>
            </thead>
            <tbody class="divide-y divide-slate-100">
              ${rows.map(row => `
                <tr class="hover:bg-slate-50">
                  ${row.map(cell => `<td class="py-4 px-3 text-[11px] font-bold text-slate-700">${cell}</td>`).join('')}
                </tr>
              `).join('')}
            </tbody>
          </table>

          ${summary ? `
            <div class="bg-slate-50 p-6 rounded-3xl border border-slate-100 w-fit mr-auto min-w-[200px]">
              ${summary.map(s => `
                <div class="flex justify-between items-center gap-10 mb-2 last:mb-0">
                  <span class="text-[10px] font-black text-slate-400 uppercase">${s.label}</span>
                  <span class="text-sm font-black text-[#1E4D4D]">${s.value}</span>
                </div>
              `).join('')}
            </div>
          ` : ''}

          <div class="fixed bottom-10 left-10 no-print">
            <button onclick="window.print()" class="bg-[#1E4D4D] text-white px-8 py-3 rounded-xl font-black shadow-2xl">طباعة أو حفظ PDF</button>
          </div>
        </body>
      </html>
    `;

    printWindow.document.write(html);
    printWindow.document.close();
  }
};
