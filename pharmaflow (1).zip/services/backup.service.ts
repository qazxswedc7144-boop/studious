
import { db } from './database';
import { ErrorManager } from './errorManager';

export const backupService = {
  /**
   * إنشاء لقطة (Snapshot) فورية لكامل البيانات
   */
  async createAutoSnapshot() {
    try {
      const state = db.getFullState();
      
      // التأكد من وجود بيانات قبل النسخ
      if (!state.db_products || state.db_products.length === 0) return;

      const snapshot = {
        id: `SNAP-${Date.now()}`,
        date: new Date().toISOString(),
        data: state
      };
      
      // حفظ في IndexedDB (جدول مخصص للسنابات)
      await (db as any).persist('snapshots', snapshot);
      localStorage.setItem('db_last_auto_backup', snapshot.date);
      
      console.log(`[BackupService] Auto-snapshot created at ${new Date().toLocaleTimeString()}`);
      
      // توثيق العملية في سجل الرقابة
      await db.addAuditLog("نسخ احتياطي آلي", "System", "تم إنشاء لقطة تلقائية لقاعدة البيانات", "info");
      
    } catch (error) {
      ErrorManager.handleError(error, "AutoBackup");
    }
  },

  /**
   * تشغيل الجدولة التلقائية للنسخ الاحتياطي
   */
  startAutoTimer() {
    // كل ساعة يتم عمل نسخة احتياطية ذكية
    // ملاحظة: تم استخدام setInterval هنا، ولكن في الإنتاج يفضل استخدام Periodic Sync API إذا كان متاحاً
    setInterval(() => {
      if (navigator.onLine) {
        this.createAutoSnapshot();
      }
    }, 1000 * 60 * 60);
    
    console.log("[BackupService] Periodic backup scheduler active.");
  }
};