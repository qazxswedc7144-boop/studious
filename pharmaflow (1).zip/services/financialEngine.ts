
import { JournalLine, AccountingEntry } from '../types';
import { db } from './database';

/**
 * FinancialEngine - العقل الرياضي للنظام مع دعم الذاكرة المؤقتة (Memoization)
 * مسؤول عن الحسابات البحتة والتحقق من التوازن المالي بأعلى أداء ممكن.
 */
class FinancialEngineService {
  private memoCache: Map<string, { version: number; result: any }> = new Map();

  /**
   * دالة مساعدة لتطبيق الـ Memoization بناءً على إصدار الداتا
   */
  private memoize<T>(key: string, fn: () => T): T {
    const currentVersion = db.getVersion();
    const cached = this.memoCache.get(key);

    if (cached && cached.version === currentVersion) {
      return cached.result as T;
    }

    const result = fn();
    this.memoCache.set(key, { version: currentVersion, result });
    return result;
  }

  /**
   * التأكد من توازن القيد المحاسبي (مدين = دائن)
   */
  isBalanced(lines: JournalLine[]): boolean {
    // القيود عادة صغيرة، لكننا نستخدم Memoization للمجموع التراكمي إذا لزم الأمر
    const debit = lines.filter(l => l.type === 'DEBIT').reduce((s, l) => s + l.amount, 0);
    const credit = lines.filter(l => l.type === 'CREDIT').reduce((s, l) => s + l.amount, 0);
    return Math.abs(debit - credit) < 0.001;
  }

  /**
   * حساب صافي الربح مع التخزين المؤقت للنتائج
   */
  calculateNetProfit(revenue: number, cogs: number, expenses: number): number {
    const key = `net_profit_${revenue}_${cogs}_${expenses}`;
    return this.memoize(key, () => revenue - cogs - expenses);
  }

  /**
   * توليد خطوط القيد لعملية دفع بسيطة
   */
  createSimplePaymentLines(amount: number, fromAccount: {id: string, name: string}, toAccount: {id: string, name: string}): JournalLine[] {
    const entryId = 'TEMP';
    return [
      { 
        lineId: db.generateId('L'), 
        entryId, 
        accountId: toAccount.id, 
        accountName: toAccount.name, 
        amount, 
        type: 'DEBIT',
        debit: amount,
        credit: 0
      },
      { 
        lineId: db.generateId('L'), 
        entryId, 
        accountId: fromAccount.id, 
        accountName: fromAccount.name, 
        amount, 
        type: 'CREDIT',
        debit: 0,
        credit: amount
      }
    ];
  }

  /**
   * التحقق من سلامة الأرصدة عبر مقارنة الأستاذ العام بالـ Ledger المساعد
   * عملية ثقيلة يتم عمل Memoization لها
   */
  validatePartnerIntegrity(partnerId: string, type: 'S' | 'C'): boolean {
    const key = `integrity_${partnerId}`;
    return this.memoize(key, () => {
      const ledgerBalance = db.getAccountBalance(partnerId); // من دفتر الأستاذ
      const latestLedgerEntry = db.getLatestPartnerLedgerEntry(partnerId); // من السجل المساعد
      const assistantBalance = latestLedgerEntry?.runningBalance || 0;
      
      return Math.abs(ledgerBalance - assistantBalance) < 0.01;
    });
  }
}

export const FinancialEngine = new FinancialEngineService();
