
import { AccountingPeriodRepository } from '../repositories/AccountingPeriodRepository';
import { AccountingError } from '../types';

/**
 * Period Service - نظام حماية الفترات المحاسبية
 * مسؤول عن منع العمليات المالية في التواريخ المقفلة
 */
export const periodService = {
  /**
   * التحقق من صلاحية التاريخ للعمليات (الحارس المركزي)
   * @throws AccountingError إذا كان التاريخ مغلقاً
   */
  validatePeriod: (date: string): void => {
    if (!date) return;
    
    const isClosed = AccountingPeriodRepository.isDateClosed(date);
    if (isClosed) {
      const formattedDate = new Date(date).toLocaleDateString('ar-SA');
      throw new AccountingError(
        `خطأ حماية: التاريخ [${formattedDate}] يقع ضمن فترة مالية مغلقة ومعتمدة. لا يمكن الإضافة، التعديل، أو الحذف في السجلات المقفلة.`
      );
    }
  },

  /**
   * جلب كافة الفترات المحاسبية
   */
  getPeriods: () => AccountingPeriodRepository.getAll(),

  /**
   * إغلاق فترة مالية بشكل نهائي
   */
  closePeriod: async (periodId: string, userId: string) => {
    await AccountingPeriodRepository.closePeriod(periodId, userId);
  }
};
