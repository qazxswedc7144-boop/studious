
import { PurchaseRepository } from '../repositories/PurchaseRepository';
import { Purchase } from '../types';
import { transactionOrchestrator } from './transactionOrchestrator';

export const purchasesService = {
  getPurchases: (): Purchase[] => {
    return PurchaseRepository.getAll();
  },

  getNextAutoNumber: (): string => {
    return PurchaseRepository.getNextInvoiceNumber();
  },

  checkInvoiceUniqueness: (id: string): boolean => {
    return PurchaseRepository.isInvoiceNumberUnique(id);
  },

  processNewPurchase: async (supplierId: string, items: any[], total: number, invoiceId?: string, isCash: boolean = false) => {
    return transactionOrchestrator.executePurchaseTransaction(supplierId, items, total, invoiceId, isCash);
  }
};
