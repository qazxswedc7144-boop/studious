
import { db } from './database';

/**
 * Report Cache Service
 * محرك التخزين المؤقت للتقارير - يضمن عدم إعادة حساب البيانات ما لم يتغير إصدار قاعدة البيانات.
 */
class ReportCacheService {
  // تخزين البيانات في الذاكرة: Map<Key, { version: number, data: any }>
  private cache: Map<string, { version: number; data: any }> = new Map();

  /**
   * جلب بيانات من الكاش إذا كانت النسخة مطابقة لإصدار قاعدة البيانات الحالي
   */
  get<T>(key: string): T | null {
    const currentDbVersion = db.getVersion();
    const cachedEntry = this.cache.get(key);

    if (cachedEntry && cachedEntry.version === currentDbVersion) {
      // أداء فائق: استرجاع مباشر من الذاكرة
      return cachedEntry.data as T;
    }
    
    // البيانات قديمة أو غير موجودة
    return null;
  }

  /**
   * حفظ نتائج التقرير في الكاش مربوطة بالإصدار الحالي
   */
  set(key: string, data: any): void {
    this.cache.set(key, {
      version: db.getVersion(),
      data
    });
  }

  /**
   * مسح الكاش يدوياً (اختياري، لأن نظام الإصدارات يتكفل بذلك)
   */
  clear(): void {
    this.cache.clear();
  }

  /**
   * فحص ما إذا كان مفتاح معين صالحاً للاستخدام
   */
  isValid(key: string): boolean {
    const cached = this.cache.get(key);
    return !!(cached && cached.version === db.getVersion());
  }
}

export const reportCache = new ReportCacheService();
