
import { Product, ValidationError, AccountingError, InventoryError, AccountingEntry } from '../../types';
import { db } from '../database';
import { PurchaseRepository } from '../../repositories/PurchaseRepository';
import { periodService } from '../period.service';

/**
 * طبقة التحقق المركزية (Validation Layer)
 */
export const dataValidator = {
  
  /**
   * منع العمليات في الفترات المغلقة محاسبياً عبر PeriodService
   */
  validateDateNotLocked: (date: string) => {
    periodService.validatePeriod(date);
    return true;
  },

  /**
   * التحقق من فرادة رقم فاتورة المشتريات
   */
  validatePurchaseInvoiceUniqueness: (invNum: string) => {
    if (!invNum) return true;
    if (!PurchaseRepository.isInvoiceNumberUnique(invNum)) {
      throw new ValidationError(`رقم الفاتورة (${invNum}) مسجل مسبقاً في النظام.`);
    }
    return true;
  },

  /**
   * فحص توفر المخزون ومنع البيع بالسالب
   */
  validateStockLevel: (productId: string, quantityToSell: number) => {
    const products = db.getProducts();
    const product = products.find(p => p.ProductID === productId || p.product_id === productId);
    
    if (!product) throw new InventoryError(`الصنف [${productId}] غير موجود.`);
    
    if (product.StockQuantity < quantityToSell) {
      throw new InventoryError(
        `عجز مخزني في [${product.Name}]: المتاح (${product.StockQuantity}) فقط.`
      );
    }
    return true;
  },

  /**
   * التحقق من سلامة القيد المحاسبي المزدوج وتوازن الحسابات
   */
  validateAccountingEntry: (entry: Partial<AccountingEntry>) => {
    if (entry.date) dataValidator.validateDateNotLocked(entry.date);
    
    if (!entry.lines || entry.lines.length < 2) {
      throw new AccountingError("قيد اليومية يجب أن يحتوي على طرفين على الأقل.");
    }

    const totalDebit = entry.lines.reduce((s, l) => s + (l.debit || 0), 0);
    const totalCredit = entry.lines.reduce((s, l) => s + (l.credit || 0), 0);

    if (Math.abs(totalDebit - totalCredit) > 0.0001) {
      throw new AccountingError(`فشل توازن القيد: المدين (${totalDebit}) != الدائن (${totalCredit}).`);
    }

    return true;
  },

  /**
   * التحقق من سلامة عملية البيع
   */
  validateSale: (customerId: string, cart: any[], total: number) => {
    dataValidator.validateDateNotLocked(new Date().toISOString());
    if (!customerId) throw new ValidationError("يرجى تحديد العميل.");
    if (!cart || cart.length === 0) throw new ValidationError("السلة فارغة.");
    
    cart.forEach(item => {
      dataValidator.validateStockLevel(item.product_id, item.qty);
    });
    return true;
  },

  /**
   * التحقق من سلامة عملية الشراء
   */
  validatePurchase: (supplierId: string, items: any[], total: number, invoiceId?: string) => {
    dataValidator.validateDateNotLocked(new Date().toISOString());
    if (!supplierId) throw new ValidationError("يرجى تحديد المورد.");
    if (invoiceId) dataValidator.validatePurchaseInvoiceUniqueness(invoiceId);
    return true;
  }
};
