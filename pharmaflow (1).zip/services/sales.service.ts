
import { SalesRepository } from '../repositories/SalesRepository';
import { Sale } from '../types';
import { transactionOrchestrator } from './transactionOrchestrator';

/**
 * Sales Service - خدمة إدارة المبيعات
 */
export const salesService = {
  getSales: (): Sale[] => {
    return SalesRepository.getAll();
  },

  processNewSale: async (customerId: string, cart: any[], total: number, options: any) => {
    // تمرير العملية للمنسق السيادي لضمان الذرية (Atomicity)
    return transactionOrchestrator.executeSaleTransaction(customerId, cart, total, options);
  }
};
