
import { MODELS } from "../constants";
import { aiProxy } from "./aiProxy";

/**
 * معالج الأخطاء المركزي لخدمات الذكاء الاصطناعي
 */
const handleApiError = async (error: any) => {
  console.error("[GeminiService] Proxy Layer Error:", error.message);
  
  // في حالة فشل الصلاحية، نطلب من المستخدم اختيار مفتاح (للنماذج المتقدمة)
  if (error?.message?.includes("Requested entity was not found.")) {
    if (typeof window !== 'undefined' && (window as any).aistudio) {
      await (window as any).aistudio.openSelectKey();
    }
  }
  throw error;
};

/**
 * تحليل أداء الصيدلية عبر الوسيط
 */
export const analyzeBusinessPerformance = async (dataSummary: any) => {
  try {
    const prompt = `
      بصفتك مستشاراً مالياً خبيراً للصيدليات، قم بتحليل ملخص البيانات التالي المستخرج من نظام ERP:
      ${JSON.stringify(dataSummary)}
      
      المطلوب:
      1. تحليل اتجاه المبيعات (Sales Trend).
      2. الكشف عن أي خلل في معدل دوران المخزون.
      3. تقديم 3 نصائح عملية لزيادة صافي الربح.
      
      لغة الرد: العربية المهنية.
    `;

    const response = await aiProxy.generateContent(
      MODELS.COMPLEX_TEXT,
      prompt,
      { thinkingConfig: { thinkingBudget: 24576 } }
    );

    return response.text;
  } catch (error) {
    return await handleApiError(error);
  }
};

/**
 * محادثة ذكية مع السياق المحاسبي عبر الوسيط
 */
export const getSmartChatResponse = async (
  prompt: string, 
  history: any[] = [], 
  options: { thinking?: boolean, useSearch?: boolean, useMaps?: boolean, location?: { lat: number, lng: number } } = {}
) => {
  try {
    const config: any = {};
    
    if (options.thinking) {
      const isPro = !options.useMaps && MODELS.COMPLEX_TEXT.includes('gemini-3-pro');
      config.thinkingConfig = { thinkingBudget: isPro ? 32768 : 24576 };
    }

    const tools = [];
    if (options.useSearch) tools.push({ googleSearch: {} });
    if (options.useMaps) {
      tools.push({ googleMaps: {} });
      if (options.location) {
        config.toolConfig = {
          retrievalConfig: {
            latLng: {
              latitude: options.location.lat,
              longitude: options.location.lng
            }
          }
        };
      }
    }
    
    if (tools.length > 0) config.tools = tools;

    const model = options.useMaps ? MODELS.MAPS_GROUNDING : (options.thinking ? MODELS.COMPLEX_TEXT : MODELS.BASIC_TEXT);
    
    // استدعاء الوسيط بدلاً من SDK مباشرة
    return await aiProxy.sendMessage(model, prompt, config);
  } catch (error: any) {
    return await handleApiError(error);
  }
};

/**
 * تحليل محتوى الصور (وصفات، فواتير) عبر الوسيط
 */
export const analyzeImageContent = async (base64Image: string, prompt: string) => {
  try {
    const response = await aiProxy.generateContent(
      MODELS.COMPLEX_TEXT,
      {
        parts: [
          { inlineData: { data: base64Image.split(',')[1], mimeType: 'image/jpeg' } },
          { text: prompt }
        ]
      }
    );
    return response.text;
  } catch (error) {
    return await handleApiError(error);
  }
};

/**
 * توليد فاتورة احترافية بتنسيق HTML عبر الوسيط
 */
export const generateAIInvoice = async (data: any, style: string) => {
  try {
    const prompt = `
      بصفتك خبيراً في تصميم واجهات المستخدم، قم بتوليد كود HTML كامل لفاتورة صيدلية احترافية.
      البيانات: ${JSON.stringify(data)}
      النمط: ${style}
      المتطلبات: استخدم Tailwind CSS، RTL، وتصميم متوافق مع الطباعة.
    `;

    const response = await aiProxy.generateContent(MODELS.BASIC_TEXT, prompt);
    return response.text || "";
  } catch (error) {
    return await handleApiError(error);
  }
};
