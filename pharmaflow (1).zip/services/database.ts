
// @google/genai Coding Guidelines followed: Professional IndexedDB architecture using Dexie with Snapshots.

import Dexie, { Table } from 'dexie';
import { securityService } from './security.service';
import { 
  Product, Sale, Purchase, CashFlow, Supplier, AccountingEntry, AuditLog, Branch, 
  IntegrityReport, Transaction, DailyAuditTask, AuditItem, PendingOperation, 
  BankTransaction, BankAccount, PaymentGateway, Account, SupplierLedgerEntry, PurchaseRecord,
  AccountingPeriod, PartnerLedgerEntry
} from '../types';

const SENSITIVE_TABLES = ['sales', 'purchases', 'cashFlow', 'journalEntries', 'suppliers', 'customers', 'bankTx', 'bankAccounts', 'accountingPeriods', 'partnerLedger'];

class PharmaFlowDB extends Dexie {
  products!: Table<Product>;
  sales!: Table<any>;
  purchases!: Table<any>;
  cashFlow!: Table<any>;
  journalEntries!: Table<any>;
  suppliers!: Table<any>;
  customers!: Table<any>;
  branches!: Table<Branch>;
  auditLogs!: Table<AuditLog>;
  pendingOps!: Table<PendingOperation>;
  bankTx!: Table<any>;
  bankAccounts!: Table<any>;
  paymentGateways!: Table<PaymentGateway>;
  accounts!: Table<Account>;
  auditTasks!: Table<DailyAuditTask>;
  snapshots!: Table<any>;
  accountingPeriods!: Table<any>;
  partnerLedger!: Table<any>;

  constructor() {
    super('PharmaFlowDB_v4_Atomic');
    
    (this as any).version(1).stores({
      products: 'ProductID, Name, barcode, category',
      sales: 'SaleID', 
      purchases: 'purchase_id',
      cashFlow: 'transaction_id',
      journalEntries: 'EntryID',
      suppliers: 'id',
      customers: 'id',
      branches: 'id, name, isMain',
      auditLogs: 'id, action, date',
      pendingOps: 'id, type, status',
      bankTx: 'id',
      bankAccounts: 'id',
      paymentGateways: 'id',
      accounts: 'id, code, name',
      auditTasks: 'date',
      snapshots: 'id, date',
      accountingPeriods: 'id, name, isClosed',
      partnerLedger: 'id, partnerId, referenceId, date'
    });
  }
}

const pfDB = new PharmaFlowDB();

class LocalDatabase {
  private version: number = 0;
  private memoryCache: Record<string, any> = {};
  private currentBranchId: string = localStorage.getItem('db_current_branch_id') || 'MAIN';
  private isLoaded: boolean = false;

  constructor() {
    this.init();
    const v = localStorage.getItem('db_global_version');
    this.version = v ? parseInt(v) : 1;
  }

  private async init() {
    try {
      await securityService.init();
      const tables = ['products', 'sales', 'purchases', 'cashFlow', 'journalEntries', 'suppliers', 'customers', 'branches', 'auditLogs', 'pendingOps', 'bankTx', 'bankAccounts', 'paymentGateways', 'accounts', 'auditTasks', 'accountingPeriods', 'partnerLedger'];
      
      for (const table of tables) {
        const rawData = await (pfDB as any)[table].toArray();
        if (SENSITIVE_TABLES.includes(table)) {
          const decryptedData = [];
          for (const item of rawData) {
            try { decryptedData.push(await securityService.decryptData(item.payload)); } catch (e) {}
          }
          this.memoryCache[`db_${table}`] = decryptedData;
        } else {
          this.memoryCache[`db_${table}`] = rawData;
        }
      }
      this.isLoaded = true;
    } catch (err) {
      console.error("Critical: Database Initialization Failed", err);
    }
  }

  public async runTransaction<T>(action: () => Promise<T>): Promise<T> {
    return (pfDB as any).transaction('rw', (pfDB as any).tables, async () => {
      try {
        const result = await action();
        // تمييز انتهاء المعاملة برفع الإصدار لضمان تحديث الكاش
        this.incrementVersion();
        return result;
      } catch (e) {
        console.error("Transaction Aborted & Rolled Back", e);
        throw e;
      }
    });
  }

  private incrementVersion() {
    this.version++;
    localStorage.setItem('db_global_version', this.version.toString());
  }

  async persist(table: string, data: any, idField: string = 'id') {
    this.memoryCache[`db_${table}`] = Array.isArray(data) ? data : [data];
    const tableInstance = (pfDB as any)[table];
    await tableInstance.clear();

    if (SENSITIVE_TABLES.includes(table)) {
      const encryptedRecords = [];
      const list = Array.isArray(data) ? data : [data];
      for (const record of list) {
        const id = record[idField] || record.SaleID || record.EntryID || record.transaction_id || record.purchase_id;
        encryptedRecords.push({ [idField]: id, payload: await securityService.encryptData(record) });
      }
      await tableInstance.bulkAdd(encryptedRecords);
    } else {
      await tableInstance.bulkAdd(Array.isArray(data) ? data : [data]);
    }
    
    // رفع إصدار قاعدة البيانات آلياً لتهجير الكاش (Cache Invalidation)
    this.incrementVersion();
  }

  getProducts(): Product[] { return this.memoryCache.db_products || []; }
  async saveProduct(p: Product) { const list = [...this.getProducts()]; const idx = list.findIndex(item => (item.ProductID === p.ProductID) || (item.ProductID === p.id)); if (idx > -1) list[idx] = p; else list.push(p); await this.persist('products', list, 'ProductID'); }
  getSales(): Sale[] { return this.memoryCache.db_sales || []; }
  getPurchases(): Purchase[] { return this.memoryCache.db_purchases || []; }
  getCashFlow(): CashFlow[] { return this.memoryCache.db_cashFlow || []; }
  getJournalEntries(): AccountingEntry[] { return this.memoryCache.db_journalEntries || []; }
  async addJournalEntry(e: AccountingEntry) { const list = [e, ...(this.getJournalEntries())]; await this.persist('journalEntries', list, 'EntryID'); }
  getSuppliers(): Supplier[] { return this.memoryCache.db_suppliers || []; }
  getCustomers(): Supplier[] { return this.memoryCache.db_customers || []; }
  getBranches(): Branch[] { return this.memoryCache.db_branches || []; }
  getAccounts(): Account[] { return this.memoryCache.db_accounts || []; }
  getAuditLogs(): AuditLog[] { return this.memoryCache.db_auditLogs || []; }
  getPendingOperations(): PendingOperation[] { return this.memoryCache.db_pendingOps || []; }
  getBankTransactions(): BankTransaction[] { return this.memoryCache.db_bankTx || []; }
  getBankAccounts(): BankAccount[] { return this.memoryCache.db_bankAccounts || []; }
  getPaymentGateways(): PaymentGateway[] { return this.memoryCache.db_paymentGateways || []; }
  getDailyAuditTask(): DailyAuditTask { return this.memoryCache.db_auditTasks?.[0] || { date: '', completed: false, items: [] }; }
  getAccountingPeriods(): AccountingPeriod[] { return this.memoryCache.db_accountingPeriods || []; }
  getPartnerLedgerRecords(): PartnerLedgerEntry[] { return this.memoryCache.db_partnerLedger || []; }
  
  async addAuditLog(action: string, entity: string, details: string, severity: string = 'info') { 
    const log = { id: this.generateId('LOG'), action, entity, details, date: new Date().toISOString(), severity };
    await pfDB.auditLogs.add(log as any); 
    this.memoryCache.db_auditLogs = [log, ...(this.memoryCache.db_auditLogs || [])].slice(0, 1000); 
  }

  generateId(p: string) { return `${p}-${Math.random().toString(36).substr(2, 9).toUpperCase()}`; }
  getVersion() { return this.version; }
  getCurrentBranchId() { return this.currentBranchId; }
  switchBranch(id: string) { this.currentBranchId = id; localStorage.setItem('db_current_branch_id', id); this.incrementVersion(); }
  
  isDateLocked(d: string) { 
    const periods = this.getAccountingPeriods();
    const date = new Date(d);
    return periods.some(p => p.isClosed && date >= new Date(p.startDate) && date <= new Date(p.endDate));
  }

  getLastClosedDate() { return localStorage.getItem('db_last_closed_date'); }
  setLastClosedDate(d: string) { localStorage.setItem('db_last_closed_date', d); }
  getFullState() { return { ...this.memoryCache }; }

  getPartnerLedger(partnerId: string): SupplierLedgerEntry[] {
    const records = this.getPartnerLedgerRecords()
      .filter(r => r.partnerId === partnerId)
      .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());
    return records.map(r => ({
      id: r.id,
      date: r.date,
      description: r.description,
      debit: r.debit,
      credit: r.credit,
      runningBalance: r.runningBalance
    }));
  }

  getLatestPartnerLedgerEntry(partnerId: string): PartnerLedgerEntry | undefined {
    const records = this.getPartnerLedgerRecords().filter(r => r.partnerId === partnerId);
    if (records.length === 0) return undefined;
    return records.reduce((prev, current) => 
      (new Date(prev.date).getTime() > new Date(current.date).getTime()) ? prev : current
    );
  }

  async saveSupplier(s: Supplier) {
    const list = [...this.getSuppliers()];
    const idx = list.findIndex(item => item.id === s.id);
    if (idx > -1) list[idx] = s; else list.push(s);
    await this.persist('suppliers', list, 'id');
  }

  async saveCustomer(c: Supplier) {
    const list = [...this.getCustomers()];
    const idx = list.findIndex(item => item.id === c.id);
    if (idx > -1) list[idx] = c; else list.push(c);
    await this.persist('customers', list, 'id');
  }

  async recordCashFlow(type: 'دخل' | 'خرج', category: string, amount: number, notes?: string) {
    const tx: CashFlow = {
      transaction_id: this.generateId('TX'),
      date: new Date().toISOString(),
      type,
      category,
      amount,
      notes,
      branchId: this.currentBranchId
    };
    await this.persist('cashFlow', [tx, ...this.getCashFlow()], 'transaction_id');
  }

  getTransactions(): Transaction[] {
    const sales = this.getSales().map(s => ({
      id: s.SaleID || s.id,
      date: s.Date || s.date || "",
      amount: s.FinalTotal || s.finalTotal || 0,
      type: 'sale' as const,
      customer: s.CustomerID || s.customerId
    }));
    const purchases = this.getPurchases().map(p => ({
      id: p.purchase_id || p.id,
      date: p.date,
      amount: p.total_amount || p.totalAmount || 0,
      type: 'purchase' as const
    }));
    const cashFlow = this.getCashFlow().map(c => ({
      id: c.transaction_id,
      date: c.date,
      amount: c.amount,
      type: (c.type === 'دخل' ? 'income' : 'expense') as any
    }));
    return [...sales, ...purchases, ...cashFlow] as Transaction[];
  }

  async saveAccountingPeriod(period: AccountingPeriod) {
    const list = [...this.getAccountingPeriods()];
    const idx = list.findIndex(p => p.id === period.id);
    if (idx > -1) list[idx] = period; else list.push(period);
    await this.persist('accountingPeriods', list, 'id');
  }

  async addPartnerLedgerEntry(entry: PartnerLedgerEntry) {
    const list = [entry, ...(this.getPartnerLedgerRecords())];
    await this.persist('partnerLedger', list, 'id');
  }

  async bulkAddProducts(products: any[]) {
    const current = [...this.getProducts()];
    let added = 0;
    let updated = 0;
    for (const p of products) {
      const idx = current.findIndex(item => (item.Name || item.name) === (p.Name || p.name) || (p.barcode && item.barcode === p.barcode));
      if (idx > -1) {
        current[idx] = { ...current[idx], ...p };
        updated++;
      } else {
        current.push({ ...p, ProductID: this.generateId('P'), MinLevel: p.MinLevel || p.minLevel || 5, costMethod: p.costMethod || 'AVG' } as Product);
        added++;
      }
    }
    await this.persist('products', current, 'ProductID');
    return { added, updated };
  }

  async saveBranch(branch: Branch) {
    const list = [...this.getBranches()];
    const idx = list.findIndex(b => b.id === branch.id);
    if (idx > -1) list[idx] = branch; else list.push(branch);
    await this.persist('branches', list, 'id');
  }

  async deleteBranch(id: string) {
    const list = this.getBranches().filter(b => b.id !== id);
    await this.persist('branches', list, 'id');
  }

  async saveAccount(account: Account) {
    const list = [...this.getAccounts()];
    const idx = list.findIndex(a => a.id === account.id);
    if (idx > -1) list[idx] = account; else list.push(account);
    await this.persist('accounts', list, 'id');
  }

  async deleteAccount(id: string) {
    const list = this.getAccounts().filter(a => a.id !== id);
    await this.persist('accounts', list, 'id');
  }

  async processSale(customerId: string, items: any[], subtotal: number, isReturn: boolean, inv: string, curr: string, status: string) {
    const sale: any = { SaleID: inv || this.generateId('S'), Date: new Date().toISOString(), CustomerID: customerId, FinalTotal: subtotal, PaymentStatus: status as any, subtotal, branchId: this.currentBranchId, items };
    await this.persist('sales', [sale, ...this.getSales()], 'SaleID');
    return { sale_id: sale.SaleID, totalSaleCost: subtotal * 0.7 };
  }

  async processPurchase(supplierId: string, items: any[], subtotal: number, inv: string, isCash: boolean) {
    const pur: any = { purchase_id: this.generateId('PUR'), invoiceId: inv, date: new Date().toISOString(), partnerId: supplierId, partnerName: supplierId, total_amount: subtotal, subtotal, finalAmount: subtotal, status: isCash ? 'PAID' : 'UNPAID', branchId: this.currentBranchId, items };
    await this.persist('purchases', [pur, ...this.getPurchases()], 'purchase_id');
    return { purchase_id: pur.purchase_id };
  }

  updatePendingOperation(op: any) { pfDB.pendingOps.put(op); this.incrementVersion(); }
  removePendingOperation(id: string) { pfDB.pendingOps.delete(id); this.incrementVersion(); }
  updateSyncDate() { localStorage.setItem('db_last_sync_date', new Date().toISOString()); }
  generateIntegrityReport(): IntegrityReport { return { isHealthy: true, totalDiff: 0, timestamp: new Date().toISOString(), points: [] }; }

  async saveAuditProgress(items: AuditItem[]) {
    const task = this.getDailyAuditTask();
    task.items = items;
    await this.persist('auditTasks', [task], 'date');
  }

  async finalizeAudit(items: AuditItem[]) {
    await this.runTransaction(async () => {
      const task = this.getDailyAuditTask();
      task.items = items;
      task.completed = true;
      await this.persist('auditTasks', [task], 'date');
      
      for (const item of items) {
        if (item.status === 'mismatch' && item.actualQty !== undefined) {
          const product = this.getProducts().find(p => (p.ProductID === item.itemId) || (p.id === item.itemId));
          if (product) {
            product.StockQuantity = item.actualQty;
            await this.saveProduct(product);
          }
        }
      }
    });
  }

  getSaleDetails() {
    const sales = this.getSales();
    return sales.flatMap(s => (s.items || []).map(i => ({
      ...i,
      product_id: i.product_id,
      unit_price: i.price,
      cost_at_sale: i.price * 0.7,
      quantity: i.qty,
      subtotal: i.qty * i.price
    })));
  }

  getLastBackupDate() {
    return localStorage.getItem('db_last_backup_date');
  }

  createBackup() {
    const date = new Date().toISOString();
    localStorage.setItem('db_last_backup_date', date);
  }

  getAccountingState() {
    return {
      _type: 'ACCOUNTING',
      journalEntries: this.getJournalEntries(),
      accounts: this.getAccounts(),
      sales: this.getSales(),
      purchases: this.getPurchases(),
      cashFlow: this.getCashFlow()
    };
  }

  getInventoryState() {
    return {
      _type: 'INVENTORY',
      products: this.getProducts(),
      suppliers: this.getSuppliers(),
      customers: this.getCustomers()
    };
  }

  async restoreBackup(data: any) {
    if (data.products) await this.persist('products', data.products, 'ProductID');
    if (data.sales) await this.persist('sales', data.sales, 'SaleID');
    if (data.purchases) await this.persist('purchases', data.purchases, 'purchase_id');
    if (data.cashFlow) await this.persist('cashFlow', data.cashFlow, 'transaction_id');
    if (data.journalEntries) await this.persist('journalEntries', data.journalEntries, 'EntryID');
    if (data.suppliers) await this.persist('suppliers', data.suppliers, 'id');
    if (data.customers) await this.persist('customers', data.customers, 'id');
    if (data.accounts) await this.persist('accounts', data.accounts, 'id');
    this.incrementVersion();
  }

  async addPendingOperation(op: Partial<PendingOperation>) {
    const operation = {
      id: this.generateId('OP'),
      status: 'pending' as const,
      retries: 0,
      createdAt: new Date().toISOString(),
      ...op
    } as PendingOperation;
    const list = [operation, ...this.getPendingOperations()];
    await this.persist('pendingOps', list, 'id');
  }

  async saveBankTransactions(txs: BankTransaction[]) {
    await this.persist('bankTx', txs, 'id');
  }

  async saveBankAccount(acc: BankAccount) {
    const list = [...this.getBankAccounts()];
    const idx = list.findIndex(a => a.id === acc.id);
    if (idx > -1) list[idx] = acc; else list.push(acc);
    await this.persist('bankAccounts', list, 'id');
  }

  async savePaymentGateway(gw: PaymentGateway) {
    const list = [...this.getPaymentGateways()];
    const idx = list.findIndex(g => g.id === gw.id);
    if (idx > -1) list[idx] = gw; else list.push(gw);
    await this.persist('paymentGateways', list, 'id');
  }

  getProductByBarcode(barcode: string): Product | undefined {
    return this.getProducts().find(p => p.barcode === barcode);
  }

  getAccountBalance(accountName: string): number {
    const entries = this.getJournalEntries();
    let balance = 0;
    entries.forEach(e => {
      e.lines.forEach(l => {
        if (l.accountName === accountName) {
          balance += (l.debit - l.credit);
        }
      });
    });
    return balance;
  }

  async savePurchase(record: PurchaseRecord, supplierId: string) {
    const suppliers = [...this.getSuppliers()];
    const idx = suppliers.findIndex(s => s.id === supplierId);
    if (idx > -1) {
      suppliers[idx].purchaseHistory = [record, ...(suppliers[idx].purchaseHistory || [])];
      await this.persist('suppliers', suppliers, 'id');
    }
  }
}

export const db = new LocalDatabase();
