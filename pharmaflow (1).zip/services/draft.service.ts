
import { securityService } from './security.service';

/**
 * Draft Service - محرك استمرارية البيانات (Persistence)
 * مسؤول عن حفظ واسترجاع الفواتير غير المكتملة لضمان عدم ضياع العمل
 */
export const draftService = {
  /**
   * حفظ الحالة الحالية لشاشة معينة
   */
  saveDraft: async (key: string, data: any) => {
    try {
      const encryptedData = await securityService.encryptData(data);
      localStorage.setItem(`draft_${key}`, encryptedData);
      return true;
    } catch (e) {
      console.error("Draft Save Failed", e);
      return false;
    }
  },

  /**
   * استرجاع المسودة المحفوظة
   */
  getDraft: async <T>(key: string): Promise<T | null> => {
    try {
      const raw = localStorage.getItem(`draft_${key}`);
      if (!raw) return null;
      return await securityService.decryptData(raw) as T;
    } catch (e) {
      console.warn("Draft Decryption Failed, clearing corrupt data.");
      localStorage.removeItem(`draft_${key}`);
      return null;
    }
  },

  /**
   * مسح المسودة عند إتمام العملية بنجاح
   */
  clearDraft: (key: string) => {
    localStorage.removeItem(`draft_${key}`);
  }
};
