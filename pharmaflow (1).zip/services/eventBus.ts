
type EventCallback = (data: any) => void;

/**
 * EventBus - محرك الأحداث المركزي للنظام
 * تم تحسينه لمنع تسرب الذاكرة (Memory Leak Protection) عبر نمط Unsubscribe الوظيفي.
 */
class EventBus {
  private static instance: EventBus;
  private listeners: Map<string, Set<EventCallback>> = new Map();

  private constructor() {}

  public static getInstance(): EventBus {
    if (!EventBus.instance) EventBus.instance = new EventBus();
    return EventBus.instance;
  }

  /**
   * إلغاء الاشتراك بدقة عالية
   */
  private off(event: string, callback: EventCallback) {
    const eventListeners = this.listeners.get(event);
    if (eventListeners) {
      eventListeners.delete(callback);
      if (eventListeners.size === 0) {
        this.listeners.delete(event);
      }
    }
  }

  /**
   * الاشتراك في حدث
   * @returns دالة إلغاء الاشتراك مباشرة (Unsubscribe Function)
   * 
   * مثال الاستخدام:
   * useEffect(() => {
   *   const unsub = eventBus.subscribe("MY_EVENT", (data) => { ... });
   *   return () => unsub();
   * }, []);
   */
  subscribe(event: string, callback: EventCallback): () => void {
    if (!this.listeners.has(event)) {
      this.listeners.set(event, new Set());
    }
    this.listeners.get(event)!.add(callback);
    
    // إرجاع دالة الـ cleanup مباشرة
    return () => this.off(event, callback);
  }

  /**
   * إطلاق حدث مع معالجة الأخطاء لكل مستمع بشكل مستقل
   */
  emit(event: string, data?: any) {
    const eventListeners = this.listeners.get(event);
    if (!eventListeners) return;
    
    // إنشاء نسخة من المستمعين لتجنب مشاكل التعديل أثناء الحلقة
    const targets = Array.from(eventListeners);
    targets.forEach(callback => {
      try {
        callback(data);
      } catch (err) {
        console.error(`[EventBus Error] Failed to execute callback for event: ${event}`, err);
      }
    });
  }
}

export const eventBus = EventBus.getInstance();

export const EVENTS = {
  SALE_COMPLETED: 'sale.completed',
  PURCHASE_COMPLETED: 'purchase.completed',
  STOCK_LOW: 'inventory.low',
  JOURNAL_CREATED: 'accounting.journal.created',
  SYNC_REQUIRED: 'sync.required',
  SYSTEM_TEST_RUN: 'system.test.run',
  DATA_REFRESHED: 'data.refreshed'
};
