
import { User, UserRole, Permission, ROLE_PERMISSIONS } from '../types';
import { db } from './database';

const SESSION_KEY = 'pharmaflow_session_secure';

export const authService = {
  /**
   * تسجيل الدخول بنظام الأدوار
   */
  login: async (username: string, role: UserRole): Promise<User> => {
    // محاكاة تأخير أمني
    await new Promise(r => setTimeout(r, 600));
    
    const user: User = {
      id: db.generateId('USR'),
      username,
      name: username === 'admin' ? 'المدير العام' : 'موظف العمليات',
      role,
      isActive: true,
      lastLogin: new Date().toISOString()
    };

    // حفظ الجلسة مشفرة في sessionStorage لضمان عدم بقائها بعد إغلاق المتصفح
    sessionStorage.setItem(SESSION_KEY, JSON.stringify(user));
    
    db.addAuditLog("أمان", "Auth", `دخول ناجح للمستخدم: ${username} بصلاحية ${role}`, 'info');
    return user;
  },

  logout: () => {
    sessionStorage.removeItem(SESSION_KEY);
    window.location.reload();
  },

  getCurrentUser: (): User | null => {
    const saved = sessionStorage.getItem(SESSION_KEY);
    try {
      return saved ? JSON.parse(saved) : null;
    } catch {
      return null;
    }
  },

  /**
   * المحرك الأساسي للتحقق من الصلاحيات (Permission Engine)
   */
  hasPermission: (permission: Permission): boolean => {
    const user = authService.getCurrentUser();
    if (!user || !user.isActive) return false;
    
    const permissions = ROLE_PERMISSIONS[user.role] || [];
    return permissions.includes(permission);
  },

  /**
   * التحقق من أدوار متعددة
   */
  isOneOfRoles: (roles: UserRole[]): boolean => {
    const user = authService.getCurrentUser();
    return !!user && roles.includes(user.role);
  }
};
