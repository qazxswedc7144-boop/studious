
import { db } from './database';

export class ErrorManager {
  /**
   * تنفيذ دالة مع إمكانية إعادة المحاولة في حال فشل الشبكة أو تعليق الداتا
   */
  static async retry<T>(fn: () => Promise<T>, retries = 3, delay = 1000): Promise<T> {
    try {
      return await fn();
    } catch (error) {
      if (retries <= 0) throw error;
      await new Promise(r => setTimeout(r, delay));
      return this.retry(fn, retries - 1, delay * 2); // Exponential backoff
    }
  }

  /**
   * تسجيل الخطأ في سجل الرقابة وتنبيه المستخدم
   */
  static handleError(error: any, context: string) {
    console.error(`[ErrorManager] ${context}:`, error);
    db.addAuditLog("خطأ تقني", context, error.message || "حدث خطأ غير معروف", 'error');
    
    // يمكن هنا إضافة منطق إرسال الخطأ لـ Sentry أو أي مراقب خارجي
    if (error.message?.includes("QuotaExceededError")) {
       alert("تنبيه: مساحة تخزين المتصفح ممتلئة. يرجى حذف بعض البيانات القديمة.");
    }
  }
}
