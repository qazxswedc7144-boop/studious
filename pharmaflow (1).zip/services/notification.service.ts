
import { Product } from '../types';

/**
 * خدمة التنبيهات الآلية
 * تقوم بفحص حالة المنتجات وإرجاع مصفوفة من الرسائل التحذيرية
 */
export const notificationService = {
  /**
   * فحص المخزون بحثاً عن الأصناف التي وصلت لحد الطلب أو قاربت على الانتهاء
   */
  checkInventoryAlerts: (products: Product[]): { message: string, type: 'error' | 'warning' }[] => {
    const alerts: { message: string, type: 'error' | 'warning' }[] = [];
    const today = new Date();
    const nextMonth = new Date();
    nextMonth.setDate(today.getDate() + 30);

    products.forEach(product => {
      // 1. فحص النواقص (Stock Level)
      if (product.StockQuantity <= 0) {
        alerts.push({
          message: `🚨 نفذ مخزون: ${product.Name} تماماً!`,
          type: 'error'
        });
      } else if (product.StockQuantity <= product.MinLevel) {
        alerts.push({
          message: `⚠️ تنبيه نواقص: ${product.Name} وصل للحد الأدنى (${product.StockQuantity})`,
          type: 'warning'
        });
      }

      // 2. فحص الصلاحية (Expiry Date)
      if (product.ExpiryDate) {
        const expiry = new Date(product.ExpiryDate);
        if (expiry <= today) {
          alerts.push({
            message: `🚫 منتهي الصلاحية: ${product.Name} انتهى في ${expiry.toLocaleDateString('ar-SA')}`,
            type: 'error'
          });
        } else if (expiry <= nextMonth) {
          alerts.push({
            message: `📅 قرب الانتهاء: ${product.Name} سينتهي قريباً (${expiry.toLocaleDateString('ar-SA')})`,
            type: 'warning'
          });
        }
      }
    });

    return alerts;
  }
};
