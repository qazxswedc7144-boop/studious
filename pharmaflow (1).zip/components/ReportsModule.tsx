
import React, { useState, useMemo, useCallback } from 'react';
import { accountingService } from '../services/accounting.service';
import { db } from '../services/database';
import { ExportService } from '../services/exportService';
import { analyzeBusinessPerformance } from '../services/geminiService';
import { Card, Badge, Button, Modal } from './SharedUI';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  BarElement,
  ArcElement,
  Title,
  Tooltip,
  Legend,
  Filler,
  ChartOptions
} from 'chart.js';
import { Line, Doughnut } from 'react-chartjs-2';
import { useUI } from '../store/AppContext';

ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  BarElement,
  ArcElement,
  Title,
  Tooltip,
  Legend,
  Filler
);

interface ReportsModuleProps {
  lang: 'en' | 'ar';
  onNavigate?: (view: any) => void;
}

const ReportsModule: React.FC<ReportsModuleProps> = ({ lang, onNavigate }) => {
  const isAr = lang === 'ar';
  const { version, currency, addToast } = useUI();
  const [activeTab, setActiveTab] = useState<'financial' | 'profit' | 'inventory' | 'visual' | 'ai-insights'>('visual');
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [aiAnalysisResult, setAiAnalysisResult] = useState<string | null>(null);

  const metrics = useMemo(() => accountingService.getFinancialMetrics(), [version]);
  const comparison = useMemo(() => accountingService.getChartAnalytics(30), [version]);
  
  const handleAiAnalysis = async () => {
    setIsAnalyzing(true);
    addToast("جاري جمع البيانات وإرسالها للمحلل الذكي...", "info");
    
    const summary = {
      metrics,
      topItems: accountingService.getTopProfitableItems(5),
      inventoryStatus: accountingService.getInventoryInsights()
    };

    try {
      const result = await analyzeBusinessPerformance(summary);
      setAiAnalysisResult(result || "عذراً، لم نتمكن من الحصول على تحليل.");
      addToast("تم استلام التحليل الاستراتيجي بنجاح ✅", "success");
    } catch (e) {
      addToast("فشل في الاتصال بمحرك الذكاء الاصطناعي", "error");
    } finally {
      setIsAnalyzing(false);
    }
  };

  const comparisonChartData = useMemo(() => ({
    labels: comparison.labels,
    datasets: [
      { label: 'إيرادات', data: comparison.revenue, borderColor: '#10B981', backgroundColor: 'rgba(16, 185, 129, 0.1)', tension: 0.4, fill: true },
      { label: 'مصاريف', data: comparison.expense, borderColor: '#EF4444', backgroundColor: 'rgba(239, 68, 68, 0.05)', tension: 0.4, fill: true }
    ]
  }), [comparison]);

  return (
    <div className="space-y-6 pb-24 text-right h-full flex flex-col relative animate-in fade-in duration-500" dir="rtl">
      <div className="bg-white px-6 py-4 border-b border-slate-100 flex items-center justify-between shadow-sm shrink-0 relative z-[70]">
        <div className="flex items-center gap-4">
           <button onClick={() => onNavigate?.('dashboard')} className="w-10 h-10 bg-slate-50 rounded-xl flex items-center justify-center text-[#1E4D4D] text-lg font-black shadow-sm">➦</button>
           <h2 className="text-sm font-black text-[#1E4D4D]">لوحة التقارير والذكاء المالي</h2>
        </div>
        <Button variant="success" size="sm" onClick={handleAiAnalysis} isLoading={isAnalyzing} icon="✨">تحليل AI استراتيجي</Button>
      </div>

      <div className="flex-1 overflow-y-auto px-4 sm:px-6 space-y-6 custom-scrollbar">
        <div className="flex gap-2 p-1.5 bg-white border border-slate-100 rounded-[28px] shadow-sm overflow-x-auto no-scrollbar shrink-0 sticky top-0 z-50">
          <button onClick={() => setActiveTab('visual')} className={`px-6 py-3 rounded-2xl text-[11px] font-black transition-all ${activeTab === 'visual' ? 'bg-[#1E4D4D] text-white shadow-lg' : 'text-slate-400'}`}>الرؤية البيانية</button>
          <button onClick={() => setActiveTab('ai-insights')} className={`px-6 py-3 rounded-2xl text-[11px] font-black transition-all ${activeTab === 'ai-insights' ? 'bg-emerald-600 text-white shadow-lg' : 'text-slate-400'}`}>تحليلات Gemini ✨</button>
          <button onClick={() => setActiveTab('profit')} className={`px-6 py-3 rounded-2xl text-[11px] font-black transition-all ${activeTab === 'profit' ? 'bg-[#1E4D4D] text-white shadow-lg' : 'text-slate-400'}`}>تحليل الأرباح</button>
          <button onClick={() => setActiveTab('inventory')} className={`px-6 py-3 rounded-2xl text-[11px] font-black transition-all ${activeTab === 'inventory' ? 'bg-[#1E4D4D] text-white shadow-lg' : 'text-slate-400'}`}>حالة المخزون</button>
        </div>

        {activeTab === 'visual' && (
          <div className="space-y-6 animate-in slide-in-from-bottom-4">
            <Card className="h-96 p-8">
               <h3 className="text-xs font-black text-[#1E4D4D] uppercase tracking-widest mb-6">مقارنة التدفق المالي (إيرادات/مصروفات)</h3>
               <div className="h-64">
                 <Line data={comparisonChartData} options={{ responsive: true, maintainAspectRatio: false }} />
               </div>
            </Card>
          </div>
        )}

        {activeTab === 'ai-insights' && (
          <div className="space-y-6 animate-in slide-in-from-bottom-4">
             {aiAnalysisResult ? (
               <Card className="bg-slate-900 text-white p-10 border-r-8 border-emerald-500">
                  <div className="flex items-center gap-4 mb-6">
                     <span className="text-4xl">🤖</span>
                     <div>
                        <h4 className="text-xl font-black text-emerald-400">تقرير المحلل الاستراتيجي الذكي</h4>
                        <p className="text-[10px] opacity-60 uppercase tracking-widest">Gemini Business Intelligence Report</p>
                     </div>
                  </div>
                  <div className="prose prose-invert max-w-none text-sm font-bold leading-relaxed whitespace-pre-wrap">
                     {aiAnalysisResult}
                  </div>
                  <div className="mt-8 pt-8 border-t border-white/10 flex justify-between items-center">
                     <p className="text-[9px] opacity-40 font-mono italic">Report ID: {db.generateId('AI-REP')}</p>
                     <Button variant="ghost" className="text-emerald-400 border-emerald-400/20" onClick={() => ExportService.exportToPDF('تقرير AI', ['التحليل'], [[aiAnalysisResult]])}>حفظ كـ PDF</Button>
                  </div>
               </Card>
             ) : (
               <div className="bg-white rounded-[40px] border-2 border-dashed border-slate-200 h-96 flex flex-col items-center justify-center text-center p-10 space-y-4">
                  <div className="text-7xl">🔮</div>
                  <h3 className="text-lg font-black text-[#1E4D4D]">بانتظار طلب التحليل</h3>
                  <p className="text-xs text-slate-400 font-bold max-w-xs leading-relaxed">بضغطة واحدة، سيقوم Gemini بتحليل كافة مبيعاتك ومخزونك وتقديم خطة استراتيجية لنمو الصيدلية.</p>
                  <Button variant="primary" className="h-14 px-10 mt-4 shadow-xl" onClick={handleAiAnalysis} isLoading={isAnalyzing}>ابدأ التحليل الآن ✨</Button>
               </div>
             )}
          </div>
        )}
      </div>
    </div>
  );
};

export default ReportsModule;
