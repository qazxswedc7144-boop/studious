
import React from 'react';

interface LogoProps {
  className?: string;
  showText?: boolean;
  size?: number;
}

const Logo: React.FC<LogoProps> = ({ className = "", showText = false, size = 40 }) => {
  return (
    <div className={`flex items-center gap-3 ${className} transition-transform hover:scale-105 active:scale-95 cursor-pointer`}>
      <svg 
        width={size} 
        height={size} 
        viewBox="0 0 512 512" 
        fill="none" 
        xmlns="http://www.w3.org/2000/svg"
        className="drop-shadow-lg"
      >
        <defs>
          <linearGradient id="silver_gradient" x1="0" y1="0" x2="512" y2="512" gradientUnits="userSpaceOnUse">
            <stop stopColor="#F1F5F9" />
            <stop offset="0.5" stopColor="#94A3B8" />
            <stop offset="1" stopColor="#F1F5F9" />
          </linearGradient>
          <linearGradient id="green_growth" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#34D399" />
            <stop offset="100%" stopColor="#059669" />
          </linearGradient>
          <filter id="outer_shadow" x="-20%" y="-20%" width="140%" height="140%">
            <feGaussianBlur in="SourceAlpha" stdDeviation="5" />
            <feOffset dx="2" dy="4" result="offsetblur" />
            <feComponentTransfer>
              <feFuncA type="linear" slope="0.3" />
            </feComponentTransfer>
            <feMerge>
              <feMergeNode />
              <feMergeNode in="SourceGraphic" />
            </feMerge>
          </filter>
        </defs>

        <circle cx="256" cy="256" r="210" fill="white" />
        <circle cx="256" cy="256" r="215" stroke="url(#silver_gradient)" strokeWidth="10" />
        <circle cx="256" cy="256" r="200" stroke="#1E4D4D" strokeWidth="4" />

        <g transform="translate(256, 260) scale(1.0)">
          <rect x="-5" y="-120" width="10" height="240" rx="5" fill="#1E4D4D" />
          <circle cx="0" cy="-130" r="16" fill="#1E4D4D" />
          <path d="M-12 -80 C-90 -80 -100 -30 -12 -15 Z" fill="#1E4D4D" opacity="0.9" />
          <path d="M12 -80 C90 -80 100 -30 12 -15 Z" fill="#1E4D4D" opacity="0.9" />
          <path d="M-45 50 Q0 0 45 50 Q0 100 -45 50" stroke="#1E4D4D" strokeWidth="8" fill="none" strokeLinecap="round" />
          <path d="M-35 -20 Q0 -70 35 -20 Q0 30 -35 -20" stroke="#1E4D4D" strokeWidth="8" fill="none" strokeLinecap="round" />
        </g>

        <g filter="url(#outer_shadow)">
          <path 
            d="M180 400 Q220 380 280 280 T400 120" 
            stroke="url(#green_growth)" 
            strokeWidth="35" 
            strokeLinecap="round" 
            fill="none"
            strokeDasharray="25 15"
          />
          <path d="M380 110 L425 95 L405 140 Z" fill="#059669" />
          <text x="355" y="115" fill="#059669" fontSize="65" fontWeight="900" fontFamily="Cairo">$</text>
        </g>

        <g transform="translate(130, 310)" fill="#10B981">
          <circle cx="0" cy="0" r="15" stroke="#10B981" strokeWidth="4" fill="none" strokeDasharray="6 4">
             <animateTransform attributeName="transform" type="rotate" from="0 0 0" to="360 0 0" dur="10s" repeatCount="indefinite" />
          </circle>
          <circle cx="0" cy="0" r="5" fill="#10B981" />
        </g>
        <g transform="translate(100, 350)" fill="#10B981">
          <circle cx="0" cy="0" r="12" stroke="#10B981" strokeWidth="3" fill="none" strokeDasharray="5 3">
             <animateTransform attributeName="transform" type="rotate" from="360 0 0" to="0 0 0" dur="8s" repeatCount="indefinite" />
          </circle>
          <circle cx="0" cy="0" r="4" fill="#10B981" />
        </g>

        <defs>
          <path id="brandPath" d="M80 430 A230 230 0 0 0 432 430" />
        </defs>
        <text className="font-black">
          <textPath href="#brandPath" startOffset="50%" textAnchor="middle">
            <tspan fill="#1E4D4D" fontSize="64">Pharma</tspan>
            <tspan fill="#10B981" fontSize="64"> Fl</tspan>
            <tspan fill="#10B981" fontSize="72" dy="-5">+</tspan>
            <tspan fill="#10B981" fontSize="64">w</tspan>
          </textPath>
        </text>
      </svg>

      {showText && (
        <div className="flex flex-col -space-y-1">
          <span className="text-xl font-black text-[#1E4D4D] tracking-tighter">Pharma</span>
          <span className="text-xl font-black text-[#10B981] tracking-tighter flex items-center">
            Fl<span className="text-2xl mb-1 mx-0.5">+</span>w
          </span>
        </div>
      )}
    </div>
  );
};

export default Logo;
