
import React, { useState, useMemo, useEffect } from 'react';
import { Supplier, SupplierLedgerEntry } from '../types';
import { db } from '../services/database';
import { SupplierRepository } from '../repositories/SupplierRepository';
import { useAccounting, useUI } from '../store/AppContext';

interface SupplierManagementProps {
  lang: 'en' | 'ar';
  onNavigate?: (view: any) => void;
}

type TabKey = 'overview' | 'history' | 'ledger';
type PartnerType = 'supplier' | 'customer';

const SupplierManagement: React.FC<SupplierManagementProps> = ({ lang, onNavigate }) => {
  const isAr = lang === 'ar';
  const { suppliers, customers } = useAccounting();
  const { refreshGlobal, addToast } = useUI();
  const [partnerType, setPartnerType] = useState<PartnerType>('supplier');
  const [searchTerm, setSearchTerm] = useState('');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [viewingPartner, setViewingPartner] = useState<Supplier | null>(null);
  const [activeTab, setActiveTab] = useState<TabKey>('overview');
  const [ledgerData, setLedgerData] = useState<SupplierLedgerEntry[]>([]);
  const [newPartner, setNewPartner] = useState({ name: '', phone: '', openingBalance: 0 });
  
  useEffect(() => {
    if (viewingPartner) {
      setLedgerData(SupplierRepository.getLedger(viewingPartner.id));
    }
  }, [viewingPartner, suppliers, customers]);

  const t = {
    en: {
      title: 'Partners Directory',
      suppliers: 'Suppliers',
      customers: 'Customers',
      addSupplier: 'New Supplier',
      addCustomer: 'New Customer',
      overview: 'Overview',
      history: 'Orders',
      ledger: 'Account Ledger',
      total: partnerType === 'supplier' ? 'Current Balance (Credit)' : 'Current Balance (Debit)',
      openingBalance: 'Opening Balance',
      name: 'Full Name',
      phone: 'Phone No.',
      date: 'Date',
      description: 'Transaction',
      debit: 'Debit (عليه)',
      credit: 'Credit (له)',
      balance: 'Running Balance',
      search: 'Search by name or phone...'
    },
    ar: {
      title: 'دليل الموردين والعملاء',
      suppliers: 'الموردون',
      customers: 'العملاء',
      addSupplier: 'إضافة مورد',
      addCustomer: 'إضافة عميل',
      overview: 'نظرة عامة',
      history: 'الطلبات',
      ledger: 'كشف الحساب',
      total: partnerType === 'supplier' ? 'إجمالي المستحقات (له)' : 'إجمالي المديونية (عليه)',
      openingBalance: 'الرصيد الافتتاحي',
      name: 'الاسم بالكامل',
      phone: 'رقم الهاتف',
      date: 'التاريخ',
      description: 'البيان',
      debit: 'مدين (عليه)',
      credit: 'دائن (له)',
      balance: 'الرصيد',
      search: 'بحث بالاسم أو الهاتف...'
    }
  }[lang];

  const partners = useMemo(() => {
    const list = partnerType === 'supplier' ? suppliers : customers;
    if (!searchTerm.trim()) return list;
    const term = searchTerm.toLowerCase();
    return list.filter(p => 
      p.name.toLowerCase().includes(term) || 
      (p.phone && p.phone.includes(searchTerm))
    );
  }, [suppliers, customers, partnerType, searchTerm]);

  const accentColor = partnerType === 'supplier' ? 'text-[#1E4D4D]' : 'text-[#2563EB]';
  const accentBg = partnerType === 'supplier' ? 'bg-[#1E4D4D]' : 'bg-[#2563EB]';
  const softBg = partnerType === 'supplier' ? 'bg-emerald-50' : 'bg-blue-50';

  const handleSave = async () => {
    if (!newPartner.name.trim()) {
      addToast(isAr ? 'يرجى إدخال اسم الشريك للمتابعة ⚠️' : 'Please enter partner name to continue ⚠️', 'warning');
      return;
    }

    try {
      const p: Supplier = {
        id: `${partnerType === 'supplier' ? 'S' : 'C'}-${Date.now()}`,
        name: newPartner.name.trim(),
        contactPerson: '', email: '',
        phone: newPartner.phone.trim(),
        paymentTerms: 'Cash',
        openingBalance: newPartner.openingBalance,
        purchaseHistory: []
      };

      if (partnerType === 'supplier') {
        await db.saveSupplier(p);
      } else {
        await db.saveCustomer(p);
      }
      
      addToast(isAr ? 'تم حفظ بيانات الشريك بنجاح ✅' : 'Partner details saved successfully ✅', 'success');
      refreshGlobal();
      setIsModalOpen(false);
      setNewPartner({ name: '', phone: '', openingBalance: 0 });
    } catch (error) {
      console.error("Save Error:", error);
      addToast(isAr ? 'حدث خطأ تقني أثناء محاولة الحفظ ❌' : 'Technical error occurred while saving ❌', 'error');
    }
  };

  const currentFinalBalance = useMemo(() => {
    if (!viewingPartner) return 0;
    return SupplierRepository.getPartnerBalance(viewingPartner.id, partnerType === 'supplier' ? 'S' : 'C');
  }, [viewingPartner, ledgerData, partnerType]);

  if (viewingPartner) {
    return (
      <div className="p-4 md:p-8 space-y-6 animate-in slide-in-from-bottom-4" dir={isAr ? 'rtl' : 'ltr'}>
        <div className="flex items-center justify-between bg-white p-6 rounded-[32px] border border-slate-100 shadow-sm">
           <div className="flex items-center gap-4">
              <button onClick={() => setViewingPartner(null)} className="w-10 h-10 bg-slate-50 rounded-xl flex items-center justify-center hover:bg-slate-100"> {isAr ? '→' : '←'} </button>
              <div>
                 <h2 className={`text-xl font-black ${accentColor}`}>{viewingPartner.name}</h2>
                 <p className="text-xs font-bold text-slate-400">{viewingPartner.phone || (isAr ? 'بدون هاتف' : 'No phone')}</p>
              </div>
           </div>
           <button onClick={() => onNavigate?.('dashboard')} className="w-10 h-10 bg-white border border-slate-100 rounded-xl flex items-center justify-center text-[#1E4D4D] text-xl font-black shadow-sm hover:bg-slate-50 transition-colors">➦</button>
        </div>

        <div className="flex p-1.5 bg-white border border-slate-100 rounded-2xl shadow-sm w-fit overflow-x-auto">
          <button onClick={() => setActiveTab('overview')} className={`px-6 py-3 rounded-xl text-xs font-black transition-all ${activeTab === 'overview' ? `${accentBg} text-white shadow-lg` : 'text-slate-400'}`}>{t.overview}</button>
          <button onClick={() => setActiveTab('history')} className={`px-6 py-3 rounded-xl text-xs font-black transition-all ${activeTab === 'history' ? `${accentBg} text-white shadow-lg` : 'text-slate-400'}`}>{t.history}</button>
          <button onClick={() => setActiveTab('ledger')} className={`px-6 py-3 rounded-xl text-xs font-black transition-all ${activeTab === 'ledger' ? `${accentBg} text-white shadow-lg` : 'text-slate-400'}`}>{t.ledger}</button>
        </div>

        <div className="bg-white rounded-[32px] p-6 border border-slate-100 shadow-sm min-h-[400px]">
          {activeTab === 'overview' ? (
             <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                <div className={`${softBg} p-8 rounded-[40px] border border-white flex flex-col items-center justify-center text-center shadow-inner`}>
                   <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2">{t.total}</p>
                   <h3 className={`text-4xl font-black ${accentColor}`}>{currentFinalBalance.toLocaleString()}</h3>
                   <span className="text-xs font-bold opacity-40 mt-1">AED</span>
                </div>
                <div className="lg:col-span-2 space-y-4 pt-4">
                   <div className="flex justify-between items-center py-4 border-b border-slate-50">
                      <span className="text-xs text-slate-400 font-bold">{t.openingBalance}</span>
                      <span className="text-sm font-black text-slate-700">{viewingPartner.openingBalance.toLocaleString()} AED</span>
                   </div>
                </div>
             </div>
          ) : activeTab === 'history' ? (
             <div className="space-y-4">
                {viewingPartner.purchaseHistory.map(h => (
                  <div key={h.id} className="p-4 bg-slate-50 rounded-2xl flex justify-between items-center">
                    <div>
                      <p className="font-black text-sm text-[#1E4D4D]">#{h.id}</p>
                      <p className="text-[10px] text-slate-400">{h.date}</p>
                    </div>
                    <p className={`font-black ${accentColor}`}>{h.amount.toLocaleString()} د.إ</p>
                  </div>
                ))}
             </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-right text-xs">
                <thead className="text-slate-400 font-black uppercase border-b border-slate-100">
                  <tr>
                    <th className="py-4 px-2">{t.date}</th>
                    <th className="py-4 px-2">{t.description}</th>
                    <th className="py-4 px-2 text-center">{t.debit}</th>
                    <th className="py-4 px-2 text-center">{t.credit}</th>
                    <th className="py-4 px-2 text-left">{t.balance}</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-50">
                  {ledgerData.map(entry => (
                    <tr key={entry.id} className="hover:bg-slate-50">
                      <td className="py-5 px-2 text-slate-500 font-bold">{new Date(entry.date).toLocaleDateString()}</td>
                      <td className="py-5 px-2 font-black text-[#1E4D4D]">{entry.description}</td>
                      <td className="py-5 px-2 text-center text-red-500 font-black">{entry.debit > 0 ? entry.debit.toLocaleString() : '-'}</td>
                      <td className="py-5 px-2 text-center text-emerald-600 font-black">{entry.credit > 0 ? entry.credit.toLocaleString() : '-'}</td>
                      <td className={`py-5 px-2 text-left font-black ${entry.runningBalance >= 0 ? 'text-slate-800' : 'text-red-600'}`}>
                        {Math.abs(entry.runningBalance || 0).toLocaleString()} <span className="text-[8px] font-normal opacity-40">د.إ</span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>
    );
  }

  return (
    <div className="p-4 md:p-8 space-y-6" dir={isAr ? 'rtl' : 'ltr'}>
      <div className="flex flex-col md:flex-row items-center justify-between gap-6 bg-white p-8 rounded-[40px] shadow-sm border border-slate-100">
        <div className="text-center md:text-right w-full md:w-auto">
          <h2 className="text-3xl font-black text-[#1E4D4D]">{t.title}</h2>
          <div className="flex gap-2 mt-4 justify-center md:justify-start">
             <button onClick={() => { setPartnerType('supplier'); setSearchTerm(''); }} className={`px-6 py-2 rounded-xl text-xs font-black transition-all ${partnerType === 'supplier' ? 'bg-[#1E4D4D] text-white shadow-lg' : 'bg-slate-100 text-slate-400'}`}>{t.suppliers}</button>
             <button onClick={() => { setPartnerType('customer'); setSearchTerm(''); }} className={`px-6 py-2 rounded-xl text-xs font-black transition-all ${partnerType === 'customer' ? 'bg-[#2563EB] text-white shadow-lg' : 'bg-slate-100 text-slate-400'}`}>{t.customers}</button>
          </div>
        </div>
        
        <div className="flex-1 max-w-md relative w-full">
           <input 
              type="text" 
              placeholder={t.search} 
              className="w-full bg-slate-50 border border-slate-100 rounded-2xl px-5 py-4 text-xs font-black focus:outline-none focus:border-blue-300 shadow-inner"
              value={searchTerm}
              onChange={e => setSearchTerm(e.target.value)}
           />
           <span className="absolute left-4 top-1/2 -translate-y-1/2 opacity-30">🔍</span>
        </div>

        <div className="flex gap-2 items-center w-full md:w-auto">
          <button onClick={() => setIsModalOpen(true)} className={`flex-1 md:flex-none px-10 py-4 rounded-2xl text-white font-black text-sm shadow-2xl transition-all ${accentBg}`}>
            ➕ {partnerType === 'supplier' ? t.addSupplier : t.addCustomer}
          </button>
          <button onClick={() => onNavigate?.('dashboard')} className="w-12 h-12 bg-white border border-slate-100 rounded-2xl flex items-center justify-center text-[#1E4D4D] text-2xl font-black shadow-sm hover:bg-slate-50 transition-colors shrink-0">➦</button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 pb-20">
        {partners.map(p => (
          <div key={p.id} onClick={() => setViewingPartner(p)} className="bg-white border border-slate-100 rounded-[32px] p-6 shadow-sm hover:shadow-xl transition-all cursor-pointer group">
            <div className="flex items-center gap-4">
               <div className={`w-14 h-14 ${softBg} rounded-2xl flex items-center justify-center text-2xl group-hover:scale-110 transition-transform`}> 
                 {partnerType === 'supplier' ? '🚛' : '🛍️'} 
               </div>
               <div className="min-w-0 flex-1">
                  <h3 className={`text-lg font-black truncate ${accentColor}`}>{p.name}</h3>
                  <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest truncate">{p.phone || (isAr ? 'لا يوجد هاتف' : 'No Phone')}</p>
               </div>
            </div>
          </div>
        ))}
      </div>

      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-sm">
          <div className="bg-white w-full max-w-sm rounded-[36px] p-8 space-y-6 animate-in zoom-in shadow-2xl">
            <h3 className={`text-xl font-black ${accentColor}`}>{partnerType === 'supplier' ? t.addSupplier : t.addCustomer}</h3>
            <div className="space-y-4">
               <input className="w-full bg-slate-50 border border-slate-100 rounded-xl px-4 py-4 font-bold" value={newPartner.name} onChange={e => setNewPartner({...newPartner, name: e.target.value})} placeholder={t.name} />
               <input className="w-full bg-slate-50 border border-slate-100 rounded-xl px-4 py-4 font-bold" value={newPartner.phone} onChange={e => setNewPartner({...newPartner, phone: e.target.value})} placeholder={t.phone} />
               <input type="number" className="w-full bg-slate-50 border border-slate-100 rounded-xl px-4 py-4 font-black text-center" value={newPartner.openingBalance} onChange={e => setNewPartner({...newPartner, openingBalance: parseFloat(e.target.value) || 0})} placeholder={t.openingBalance} />
            </div>
            <div className="flex gap-4 pt-4">
               <button onClick={() => setIsModalOpen(false)} className="flex-1 font-black text-slate-400">إلغاء</button>
               <button onClick={handleSave} className={`flex-1 py-4 rounded-2xl text-white font-black shadow-lg ${accentBg}`}>حفظ</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default SupplierManagement;
