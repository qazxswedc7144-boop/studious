
import React, { useState, useMemo } from 'react';
import { accountingService } from '../services/accounting.service';

interface VouchersModuleProps {
  onNavigate?: (view: any) => void;
}

const VouchersModule: React.FC<VouchersModuleProps> = ({ onNavigate }) => {
  const [vType, setVType] = useState<'دخل' | 'خرج'>('دخل');
  const [searchTerm, setSearchTerm] = useState('');
  const [form, setForm] = useState({
    name: '',
    amount: '',
    category: 'نثرية',
    notes: '',
    date: new Date().toISOString().split('T')[0]
  });

  const handleSave = () => {
    if (!form.name || !form.amount) {
      alert("يرجى إكمال البيانات الأساسية");
      return;
    }
    
    accountingService.recordVoucher(
      vType,
      form.name,
      parseFloat(form.amount),
      form.category,
      form.notes
    );

    alert(`تم حفظ سند ${vType === 'دخل' ? 'القبض' : 'الصرف'} بنجاح`);
    setForm({ name: '', amount: '', category: 'نثرية', notes: '', date: new Date().toISOString().split('T')[0] });
  };

  const handlePrintVoucher = (h: any) => {
    const printWindow = window.open('', '_blank');
    if (!printWindow) return;

    const [person, detail] = h.notes?.split('|') || [h.notes, ''];
    
    const html = `
      <html>
        <head>
          <title>سند ${h.type === 'دخل' ? 'قبض' : 'صرف'}</title>
          <script src="https://cdn.tailwindcss.com"></script>
          <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;700;900&display=swap" rel="stylesheet">
          <style>body { font-family: 'Cairo', sans-serif; direction: rtl; }</style>
        </head>
        <body class="p-10">
          <div class="max-w-2xl mx-auto border-4 border-double border-slate-200 p-8 rounded-[40px]">
            <div class="flex justify-between items-center mb-10 pb-6 border-b">
               <div>
                  <h1 class="text-3xl font-black text-[#1E4D4D]">PharmaFlow</h1>
                  <p class="text-xs font-bold text-slate-400">نظام إدارة الصيدلية الذكي</p>
               </div>
               <div class="text-left">
                  <h2 class="text-2xl font-black ${h.type === 'دخل' ? 'text-emerald-600' : 'text-red-500'}">سند ${h.type === 'دخل' ? 'قبض نقدية' : 'صرف نقدية'}</h2>
                  <p class="text-[10px] font-bold text-slate-400">التاريخ: ${new Date(h.date).toLocaleDateString('ar-SA')}</p>
               </div>
            </div>

            <div class="space-y-6 text-lg">
               <div class="flex border-b border-dashed pb-2">
                  <span class="w-32 font-black text-slate-400">بمبلغ وقدره:</span>
                  <span class="font-black text-[#1E4D4D]">${h.amount.toLocaleString()} د.إ</span>
               </div>
               <div class="flex border-b border-dashed pb-2">
                  <span class="w-32 font-black text-slate-400">${h.type === 'دخل' ? 'مستلم من:' : 'يصرف للسيد:'}</span>
                  <span class="font-black text-[#1E4D4D]">${person}</span>
               </div>
               <div class="flex border-b border-dashed pb-2">
                  <span class="w-32 font-black text-slate-400">وذلك عن:</span>
                  <span class="font-bold text-slate-600">${detail || 'نثريات'}</span>
               </div>
            </div>

            <div class="mt-20 flex justify-between px-10">
               <div class="text-center">
                  <p class="text-xs font-black text-slate-400 mb-10 uppercase">توقيع المستلم</p>
                  <div class="w-32 border-b border-slate-300"></div>
               </div>
               <div class="text-center">
                  <p class="text-xs font-black text-slate-400 mb-10 uppercase">توقيع المحاسب</p>
                  <div class="w-32 border-b border-slate-300"></div>
               </div>
            </div>
          </div>
          <div class="fixed bottom-10 left-0 right-0 flex justify-center no-print">
            <button onclick="window.print()" class="bg-[#1E4D4D] text-white px-10 py-4 rounded-2xl font-black shadow-2xl">طباعة الآن 🖨️</button>
          </div>
        </body>
      </html>
    `;
    printWindow.document.write(html);
    printWindow.document.close();
  };

  const history = accountingService.getCashFlow().filter(h => h.notes?.includes('سند'));
  
  const filteredHistory = useMemo(() => {
    if (!searchTerm.trim()) return history;
    const term = searchTerm.toLowerCase();
    return history.filter(h => {
       const isNoteMatch = h.notes?.toLowerCase().includes(term);
       const isCategoryMatch = h.category.toLowerCase().includes(term);
       const isAmountMatch = h.amount.toString().includes(term);
       const isDateMatch = h.date.includes(term);
       return isNoteMatch || isCategoryMatch || isAmountMatch || isDateMatch;
    });
  }, [history, searchTerm]);

  return (
    <div className="p-4 md:p-8 space-y-8 pb-24" dir="rtl">
      {/* Header */}
      <div className="flex items-center justify-between bg-white p-6 rounded-[32px] border border-slate-100 shadow-sm">
         <div className="flex items-center gap-4">
            <div className="w-12 h-12 bg-[#1E4D4D] text-white rounded-2xl flex items-center justify-center text-2xl shadow-lg">🧾</div>
            <div>
               <h2 className="text-xl md:text-2xl font-black text-[#1E4D4D]">سندات القبض والصرف</h2>
               <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">إدارة التحويلات النقدية والعهدة</p>
            </div>
         </div>
         <button onClick={() => onNavigate?.('dashboard')} className="w-10 h-10 bg-slate-50 border border-slate-100 rounded-xl flex items-center justify-center text-[#1E4D4D] text-xl font-black hover:bg-slate-100 transition-colors">➦</button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Create Voucher Form */}
        <div className="lg:col-span-1 bg-white rounded-[40px] p-8 shadow-sm border border-slate-100 space-y-8 h-fit lg:sticky lg:top-8">
          <div className="flex p-1.5 bg-[#F8FAFA] rounded-3xl border border-slate-100">
             <button 
               onClick={() => setVType('دخل')} 
               className={`flex-1 py-4 rounded-2xl font-black text-sm transition-all ${vType === 'دخل' ? 'bg-emerald-600 text-white shadow-xl' : 'text-slate-400 hover:text-emerald-600'}`}
             >سند قبض 📥</button>
             <button 
               onClick={() => setVType('خرج')} 
               className={`flex-1 py-4 rounded-2xl font-black text-sm transition-all ${vType === 'خرج' ? 'bg-red-500 text-white shadow-xl' : 'text-slate-400 hover:text-red-500'}`}
             >سند صرف 📤</button>
          </div>

          <div className="space-y-5">
             <div className="space-y-1.5">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest block mr-1">يصرف لـ / يستلم من</label>
                <input 
                  className="w-full bg-[#F8FAFA] border-2 border-slate-50 rounded-2xl px-5 py-4 font-black text-[#1E4D4D] focus:outline-none focus:border-[#1E4D4D] transition-all"
                  placeholder="الاسم الكامل للجهة..."
                  value={form.name}
                  onChange={e => setForm({...form, name: e.target.value})}
                />
             </div>
             <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1.5">
                   <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest block mr-1">المبلغ (AED)</label>
                   <input 
                     type="number"
                     className="w-full bg-[#F8FAFA] border-2 border-slate-50 rounded-2xl px-5 py-4 font-black text-[#1E4D4D] text-center text-xl"
                     placeholder="0.00"
                     value={form.amount}
                     onChange={e => setForm({...form, amount: e.target.value})}
                   />
                </div>
                <div className="space-y-1.5">
                   <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest block mr-1">التاريخ</label>
                   <input 
                     type="date"
                     className="w-full bg-[#F8FAFA] border-2 border-slate-50 rounded-2xl px-3 py-4 font-black text-slate-600 text-xs"
                     value={form.date}
                     onChange={e => setForm({...form, date: e.target.value})}
                   />
                </div>
             </div>
             <div className="space-y-1.5">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest block mr-1">البيان والتفاصيل</label>
                <textarea 
                  className="w-full bg-[#F8FAFA] border-2 border-slate-50 rounded-2xl px-5 py-4 font-bold text-slate-700 h-28 focus:outline-none focus:border-[#1E4D4D] transition-all"
                  placeholder="اكتب سبب العملية المالية هنا..."
                  value={form.notes}
                  onChange={e => setForm({...form, notes: e.target.value})}
                />
             </div>
          </div>

          <button 
            onClick={handleSave}
            className={`w-full py-5 rounded-[24px] font-black text-lg text-white shadow-2xl transition-all active:scale-95 ${vType === 'دخل' ? 'bg-emerald-600 hover:bg-emerald-700 shadow-emerald-100' : 'bg-red-500 hover:bg-red-600 shadow-red-100'}`}
          >إتمام العملية وحفظ السند ✨</button>
        </div>

        {/* Voucher Archive with Enhanced Search */}
        <div className="lg:col-span-2 bg-white rounded-[40px] p-8 shadow-sm border border-slate-100 overflow-hidden flex flex-col h-full min-h-[600px]">
           <div className="flex flex-col md:flex-row items-center justify-between gap-6 mb-8">
              <div>
                <h3 className="text-xl font-black text-[#1E4D4D]">أرشيف السندات</h3>
                <p className="text-[9px] font-bold text-slate-400 uppercase tracking-tighter">مراجعة العمليات المالية السابقة</p>
              </div>
              
              {/* Enhanced Search Input */}
              <div className="relative w-full md:w-80 group">
                <input 
                   type="text" 
                   placeholder="ابحث بالاسم، المبلغ، أو الفئة..." 
                   className="w-full bg-slate-50 border border-slate-100 rounded-2xl px-12 py-3.5 text-xs font-black focus:outline-none focus:border-[#1E4D4D] focus:bg-white shadow-inner transition-all group-hover:border-slate-200"
                   value={searchTerm}
                   onChange={e => setSearchTerm(e.target.value)}
                />
                <span className="absolute right-4 top-1/2 -translate-y-1/2 text-xl opacity-30 group-focus-within:opacity-100 transition-opacity">🔍</span>
                {searchTerm && (
                  <button 
                    onClick={() => setSearchTerm('')}
                    className="absolute left-4 top-1/2 -translate-y-1/2 w-6 h-6 bg-slate-200 rounded-full flex items-center justify-center text-[10px] font-black text-slate-500 hover:bg-red-500 hover:text-white transition-all"
                  >✕</button>
                )}
              </div>
           </div>
           
           <div className="space-y-4 overflow-y-auto custom-scrollbar pr-2 flex-1 pb-4">
              {filteredHistory.map(h => (
                <div key={h.transaction_id} className="flex flex-col sm:flex-row items-center justify-between p-6 bg-[#F8FAFA] border border-slate-50 rounded-[32px] hover:bg-white hover:shadow-xl transition-all group relative overflow-hidden">
                   <div className="flex items-center gap-6 w-full sm:w-auto">
                      <div className={`w-14 h-14 rounded-2xl flex items-center justify-center text-2xl shadow-sm shrink-0 transition-transform group-hover:scale-110 ${h.type === 'دخل' ? 'bg-emerald-50 text-emerald-600' : 'bg-red-50 text-red-500'}`}>
                        {h.type === 'دخل' ? '📥' : '📤'}
                      </div>
                      <div className="min-w-0 flex-1">
                        <h4 className="font-black text-[#1E4D4D] truncate group-hover:text-black transition-colors">
                          {h.notes?.split('|')[0].replace('سند قبض لـ: ', '').replace('سند صرف لـ: ', '') || 'سند مالي غير معنون'}
                        </h4>
                        <div className="flex flex-wrap items-center gap-3 mt-1.5">
                          <span className="text-[10px] font-black text-slate-400 bg-white px-2 py-0.5 rounded-md border border-slate-100">
                             📅 {new Date(h.date).toLocaleDateString('ar-SA')}
                          </span>
                          <span className={`text-[9px] font-black px-2 py-0.5 rounded-md ${h.type === 'دخل' ? 'bg-emerald-100 text-emerald-700' : 'bg-red-100 text-red-700'}`}>
                             {h.category}
                          </span>
                        </div>
                        <p className="text-[10px] font-bold text-slate-400 mt-2 truncate italic opacity-60">
                          {h.notes?.split('|')[1] || 'لا توجد ملاحظات إضافية'}
                        </p>
                      </div>
                   </div>
                   
                   <div className="text-center sm:text-left mt-4 sm:mt-0 w-full sm:w-auto flex sm:flex-col items-center sm:items-end justify-between sm:justify-center border-t sm:border-t-0 pt-4 sm:pt-0 border-slate-100">
                      <p className={`text-2xl font-black ${h.type === 'دخل' ? 'text-emerald-600' : 'text-red-500'}`}>
                        {h.type === 'دخل' ? '+' : '-'}{h.amount.toLocaleString()} <span className="text-xs font-normal opacity-40">AED</span>
                      </p>
                      <button 
                        onClick={() => handlePrintVoucher(h)}
                        className="flex items-center gap-1.5 text-[10px] font-black text-[#1E4D4D] bg-white px-3 py-1.5 rounded-xl border border-slate-100 shadow-sm hover:bg-[#1E4D4D] hover:text-white transition-all sm:mt-2"
                      >
                        <span className="text-sm">🖨️</span>
                        طباعة
                      </button>
                   </div>
                   
                   {/* Background Decorative Element */}
                   <div className={`absolute -right-4 -bottom-4 w-12 h-12 rounded-full opacity-5 transition-transform group-hover:scale-[3] ${h.type === 'دخل' ? 'bg-emerald-500' : 'bg-red-500'}`}></div>
                </div>
              ))}
              
              {filteredHistory.length === 0 && (
                <div className="flex flex-col items-center justify-center py-20 text-center space-y-4">
                   <div className="text-5xl opacity-20">📂</div>
                   <div className="space-y-1">
                      <p className="text-slate-400 font-black italic">
                        {searchTerm ? 'عذراً، لم نجد سندات تطابق بحثك' : 'الأرشيف فارغ حالياً'}
                      </p>
                      {searchTerm && (
                         <button onClick={() => setSearchTerm('')} className="text-[10px] font-black text-[#1E4D4D] underline">عرض كافة السندات</button>
                      )}
                   </div>
                </div>
              )}
           </div>
        </div>
      </div>
    </div>
  );
};

export default VouchersModule;
