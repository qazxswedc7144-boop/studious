
import React, { useState, useEffect, useMemo, useRef } from 'react';
import { db } from '../services/database';
import { AuditLog } from '../types';
import { FixedSizeList as List } from 'react-window';

interface AuditLogModuleProps {
  onNavigate?: (view: any) => void;
}

const AuditLogModule: React.FC<AuditLogModuleProps> = ({ onNavigate }) => {
  const [logs, setLogs] = useState<AuditLog[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    setLogs(db.getAuditLogs());
  }, []);

  const filteredLogs = useMemo(() => {
    if (!searchTerm.trim()) return logs;
    const term = searchTerm.toLowerCase();
    return logs.filter(l => 
      l.action.toLowerCase().includes(term) || 
      l.entity.toLowerCase().includes(term) ||
      l.details?.toLowerCase().includes(term)
    );
  }, [logs, searchTerm]);

  const getSeverityStyle = (severity?: AuditLog['severity']) => {
    switch (severity) {
      case 'critical': return 'bg-red-600 text-white border-red-700 shadow-red-100';
      case 'error': return 'bg-red-50 text-red-600 border-red-200';
      case 'warning': return 'bg-amber-50 text-amber-600 border-amber-200';
      default: return 'bg-slate-50 text-slate-500 border-slate-100';
    }
  };

  const getActionIcon = (action: string) => {
    if (action.includes('بيع')) return '💳';
    if (action.includes('شراء')) return '🛒';
    if (action.includes('خطأ')) return '⚠️';
    if (action.includes('حذف')) return '🗑️';
    return '📜';
  };

  const Row = ({ index, style }: { index: number; style: React.CSSProperties }) => {
    const log = filteredLogs[index];
    return (
      <div style={style} className="flex border-b border-slate-50 hover:bg-slate-50/50 transition-colors items-center">
        <div className="w-1/4 px-8 py-3">
          <p className="text-xs font-black text-[#1E4D4D]">{new Date(log.date).toLocaleTimeString('ar-SA')}</p>
          <p className="text-[10px] font-bold text-slate-400">{new Date(log.date).toLocaleDateString('ar-SA')}</p>
        </div>
        <div className="w-1/4 px-8 py-3">
          <div className="flex items-center gap-2">
            <span className="text-base">{getActionIcon(log.action)}</span>
            <span className={`px-3 py-1 rounded-full text-[9px] font-black border transition-all ${getSeverityStyle(log.severity)}`}>
              {log.action}
            </span>
          </div>
        </div>
        <div className="w-1/4 px-8 py-3">
          <p className="text-xs font-black text-[#1E4D4D] truncate">{log.entity}</p>
          <p className="text-[8px] font-bold text-slate-300 uppercase">USR: {log.user}</p>
        </div>
        <div className="w-1/4 px-8 py-3">
          <p className={`text-[10px] font-bold truncate ${log.severity === 'critical' || log.severity === 'error' ? 'text-red-500' : 'text-slate-500'}`} title={log.details}>
            {log.details || '---'}
          </p>
        </div>
      </div>
    );
  };

  return (
    <div className="space-y-8 pb-20 text-right flex flex-col h-full overflow-hidden" dir="rtl">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 px-4 shrink-0">
        <div className="flex items-center gap-4">
          <div>
            <h2 className="text-3xl font-black text-[#1E4D4D]">سجل الرقابة والتدقيق</h2>
            <p className="text-slate-400 font-bold text-sm">تتبع الأنشطة والأخطاء التقنية والمحاسبية</p>
          </div>
          <button onClick={() => onNavigate?.('dashboard')} className="w-10 h-10 bg-white border border-slate-100 rounded-xl flex items-center justify-center text-[#1E4D4D] text-xl font-black shadow-sm hover:bg-slate-50 transition-colors">➦</button>
        </div>
        <div className="relative w-full md:w-80">
          <input 
            className="w-full bg-white border border-slate-100 rounded-2xl px-5 py-4 text-sm font-bold focus:outline-none focus:border-[#1E4D4D] shadow-sm"
            placeholder="بحث في السجلات..."
            value={searchTerm}
            onChange={e => setSearchTerm(e.target.value)}
          />
          <span className="absolute left-4 top-1/2 -translate-y-1/2 opacity-30">🔍</span>
        </div>
      </div>

      <div className="bg-white mx-4 rounded-[40px] shadow-sm border border-slate-100 overflow-hidden flex flex-col flex-1">
        <div className="bg-[#F8FAFA] text-[10px] font-black text-slate-400 uppercase tracking-widest border-b border-slate-100 flex shrink-0">
          <div className="w-1/4 px-8 py-4">الوقت والتاريخ</div>
          <div className="w-1/4 px-8 py-4">الحالة / العملية</div>
          <div className="w-1/4 px-8 py-4">المستهدف</div>
          <div className="w-1/4 px-8 py-4">التفاصيل</div>
        </div>
        
        <div className="flex-1 min-h-0" ref={containerRef}>
          {filteredLogs.length > 0 ? (
            <List
              height={containerRef.current?.clientHeight || 500}
              itemCount={filteredLogs.length}
              itemSize={70}
              width="100%"
              className="custom-scrollbar"
            >
              {Row}
            </List>
          ) : (
            <div className="h-full flex items-center justify-center text-slate-300 italic font-bold">
               لا توجد سجلات حالياً
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default AuditLogModule;
