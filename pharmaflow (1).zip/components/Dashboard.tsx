import React, { useMemo } from 'react';
import { useUI, useInventory, useAccounting } from '../store/AppContext';
import { accountingService } from '../services/accounting.service';
import { AccountingRepository } from '../repositories/AccountingRepository';
import { Card, Badge, Button, HelpTooltip } from './SharedUI';
import RoleGuard from './RoleGuard';
import { Permission } from '../types';

interface DashboardProps {
  lang?: 'ar';
  onNavigate?: (view: any) => void;
}

const StatMiniCard = ({ label, value, icon, color, unit }: { label: string, value: string | number, icon: string, color: string, unit?: string }) => (
  <Card className={`flex items-center justify-between h-24 border-r-4 ${color} group hover:scale-[1.02] transition-all !p-4`}>
    <div className="flex flex-col gap-0.5">
        <p className="text-[8px] font-black text-slate-400 uppercase tracking-widest">{label}</p>
        <h2 className="text-lg font-black text-[#1E4D4D] truncate">{value.toLocaleString()} <span className="text-[9px] opacity-30">{unit}</span></h2>
    </div>
    <div className={`w-9 h-9 bg-slate-50 rounded-xl flex items-center justify-center text-lg shadow-inner group-hover:scale-110 transition-transform`}>{icon}</div>
  </Card>
);

const Dashboard: React.FC<DashboardProps> = ({ onNavigate }) => {
  const { products } = useInventory();
  const { currency, version } = useUI();
  
  const stats = useMemo(() => {
    const metrics = accountingService.getFinancialMetrics();
    const today = new Date().toISOString().split('T')[0];
    const transactions = AccountingRepository.getTransactions();
    const todaySales = transactions.filter(t => t.type === 'sale' && t.date.startsWith(today));
    
    return {
      todaySalesTotal: todaySales.reduce((acc, s) => acc + s.amount, 0),
      todayInvoicesCount: todaySales.length,
      netProfit: metrics.net,
      grossProfit: metrics.grossProfit,
      weeklyData: accountingService.getWeeklyPerformanceData(),
      forecast: accountingService.getPredictedCashflow(7)
    };
  }, [version]);

  const actions = useMemo(() => [
    { id: 'sales', label: 'المبيعات', icon: '💳', bg: 'bg-[#10B981]', permission: 'PERFORM_SALE' as Permission },
    { id: 'purchases', label: 'المشتريات', icon: '🛒', bg: 'bg-[#1E4D4D]', permission: 'MANAGE_PURCHASE' as Permission },
    { id: 'ai-audit', label: 'التدقيق الذكي', icon: '🤖', bg: 'bg-emerald-900', permission: 'AUDIT_ACCESS' as Permission },
    { id: 'inventory', label: 'المخزن', icon: '📦', bg: 'bg-[#2563EB]', permission: 'MANAGE_INVENTORY' as Permission },
    { id: 'reports', label: 'التقارير', icon: '📊', bg: 'bg-[#8B5CF6]', permission: 'VIEW_FINANCE' as Permission },
    { id: 'partners', label: 'الشركاء', icon: '🤝', bg: 'bg-[#4F46E5]', permission: 'MANAGE_PURCHASE' as Permission },
    { id: 'accounting', label: 'المحاسبة', icon: '⚖️', bg: 'bg-[#475569]', permission: 'VIEW_FINANCE' as Permission },
    { id: 'audit', label: 'الجرد', icon: '🔍', bg: 'bg-[#E11D48]', permission: 'MANAGE_INVENTORY' as Permission },
  ], []);

  return (
    <div className="space-y-6 p-4 md:p-8 pb-32 text-right overflow-x-hidden animate-in fade-in duration-500" dir="rtl">
      
      <div className="flex items-center justify-between px-2">
         <h2 className="text-lg font-black text-[#1E4D4D] flex items-center gap-2">لوحة التحكم الرئيسية<HelpTooltip message="ملخص أداء الصيدلية المالي والعملياتي" /></h2>
         <Badge variant="neutral">تحديث: {new Date().toLocaleTimeString('ar-SA')}</Badge>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-4">
           <div className="grid grid-cols-2 gap-4">
              <RoleGuard permission="VIEW_FINANCE" hideOnFailure><StatMiniCard label="مبيعات اليوم" value={stats.todaySalesTotal} icon="💰" color="border-r-emerald-500" unit={currency} /></RoleGuard>
              <StatMiniCard label="فواتير اليوم" value={stats.todayInvoicesCount} icon="📑" color="border-r-blue-500" unit="فاتورة" />
           </div>
           <div className="grid grid-cols-2 gap-4">
              <RoleGuard permission="VIEW_FINANCE" hideOnFailure>
                <StatMiniCard label="صافي الربح" value={stats.netProfit} icon="📈" color="border-r-emerald-600" unit={currency} />
                <StatMiniCard label="الربح التقديري" value={stats.grossProfit} icon="⚖️" color="border-r-amber-500" unit={currency} />
              </RoleGuard>
           </div>

           <Card className="relative overflow-hidden group border-b-8 border-b-[#1E4D4D] mt-2">
            <div className="flex items-center justify-between mb-8">
              <div><p className="text-[9px] font-black text-slate-400 uppercase mb-1.5">مؤشر أداء المبيعات</p><h3 className="text-sm font-black text-[#1E4D4D]">تحليل الـ 7 أيام الماضية</h3></div>
              <Badge variant="success">بيانات مباشرة</Badge>
            </div>
            <div className="flex items-end justify-between h-40 gap-2 sm:gap-4 px-1 pb-2">
              {stats.weeklyData.map((day, i) => (
                <div key={i} className="flex-1 flex flex-col items-center gap-3 group/bar">
                  <div className={`w-full max-w-[24px] rounded-t-lg transition-all duration-1000 origin-bottom relative cursor-pointer ${day.isToday ? 'bg-[#10B981]' : 'bg-slate-100 hover:bg-slate-200'}`} style={{ height: `${day.value}%` }} title={`${day.actualValue.toLocaleString()} ${currency}`}></div>
                  <span className={`text-[9px] font-black ${day.isToday ? 'text-[#1E4D4D]' : 'text-slate-300'}`}>{day.dayLetter}</span>
                </div>
              ))}
            </div>
          </Card>
        </div>

        <div className="lg:col-span-1 space-y-6">
           <RoleGuard permission="AUDIT_ACCESS">
             <Card className="bg-[#1E4D4D] text-white p-8 h-full flex flex-col justify-between border-4 border-emerald-900/10">
                <div>
                  <div className="flex items-center gap-3 mb-6"><div className="w-10 h-10 bg-white/10 rounded-xl flex items-center justify-center text-xl">🔮</div><div><h3 className="text-sm font-black">التنبؤ المالي الذكي</h3><p className="text-[8px] opacity-60 uppercase tracking-widest">Next 7 Days Forecast</p></div></div>
                  <div className="space-y-4">
                    <div className="flex justify-between items-center text-[10px]"><span className="opacity-70">إجمالي التوقع:</span><span className="font-black text-emerald-300">{(stats.forecast.reduce((a,b)=>a+b,0)).toLocaleString()} {currency}</span></div>
                    <div className="flex items-end gap-1 h-14">{stats.forecast.map((f, i) => (<div key={i} className="flex-1 bg-white/10 rounded-t-sm hover:bg-emerald-400 transition-all" style={{ height: `${(f / (Math.max(...stats.forecast) || 1)) * 100}%` }}></div>))}</div>
                  </div>
                </div>
                <Button variant="success" className="w-full mt-6 bg-emerald-600 border-0 h-12 text-xs" onClick={() => onNavigate?.('ai-audit')}>فتح تقرير AI</Button>
             </Card>
           </RoleGuard>
        </div>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        {actions.map(action => (
          <RoleGuard key={action.id} permission={action.permission} hideOnFailure>
            <button onClick={() => onNavigate?.(action.id)} className={`${action.bg} text-white rounded-[24px] p-4 flex flex-col items-center justify-center transition-all h-28 sm:h-32 shadow-lg active:scale-95 group`}>
              <div className="text-2xl mb-2 group-hover:scale-110 transition-transform">{action.icon}</div>
              <h3 className="text-[11px] font-black uppercase">{action.label}</h3>
            </button>
          </RoleGuard>
        ))}
      </div>
    </div>
  );
};

export default Dashboard;