
import React, { useState, useMemo, useEffect, useRef, useCallback } from 'react';
import { db } from '../services/database';
import { PurchaseRepository } from '../repositories/PurchaseRepository';
import { ProductRepository } from '../repositories/ProductRepository';
import { draftService } from '../services/draft.service';
import { Product, Supplier, Purchase } from '../types';
import { useUI, useInventory, useAccounting } from '../store/AppContext';
import { imageService } from '../services/image.service';
import { Card, Button, Input, Modal, Badge } from './SharedUI';

interface PurchaseItem {
  id: string; 
  product_id: string; 
  name: string;
  qty: number;
  price: number;
  sum: number;
  expiry: string;
  note: string;
}

const PurchasesModule: React.FC<{ onNavigate?: (view: any) => void }> = ({ onNavigate }) => {
  const { currency, addToast } = useUI();
  const { processPurchase, suppliers } = useAccounting();
  
  const [tableSearch, setTableSearch] = useState('');
  const [isDuplicate, setIsDuplicate] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [isDraftLoading, setIsDraftLoading] = useState(true);
  const [invoiceImage, setInvoiceImage] = useState<string | null>(null);
  
  const [header, setHeader] = useState({
    supplierName: '',
    supplierId: '',
    supplierPhone: '',
    date: new Date().toISOString().split('T')[0],
    invNum: '', 
    notes: '',
    isCash: true,
    isReturn: false
  });

  const [items, setItems] = useState<PurchaseItem[]>([]);
  const [isItemModalOpen, setIsItemModalOpen] = useState(false);
  const [newItem, setnewItem] = useState({ product_id: '', name: '', qty: 0, price: 0, stock: 0, note: '', expiry: '' });
  const [modalSearch, setModalSearch] = useState('');
  const [modalSuggestions, setModalSuggestions] = useState<Product[]>([]);
  const [supplierSuggestions, setSupplierSuggestions] = useState<Supplier[]>([]);
  const [showSupplierDropdown, setShowSupplierDropdown] = useState(false);
  const [invNumSuggestions, setInvNumSuggestions] = useState<string[]>([]);
  const [showInvSuggestions, setShowInvSuggestions] = useState(false);

  useEffect(() => {
    const recoverDraft = async () => {
      const saved = await draftService.getDraft<{header: any, items: PurchaseItem[]}>('purchase_active');
      if (saved) { 
        setHeader(saved.header); 
        setItems(saved.items); 
        addToast("تم استعادة مسودة المشتريات 🛒", "info"); 
      } else {
        setHeader(h => ({...h, invNum: PurchaseRepository.getNextInvoiceNumber()}));
      }
      setIsDraftLoading(false);
    };
    recoverDraft();
  }, [addToast]);

  useEffect(() => {
    if (!isDraftLoading) {
      const timer = setTimeout(() => { draftService.saveDraft('purchase_active', { header, items }); }, 1000);
      return () => clearTimeout(timer);
    }
  }, [header, items, isDraftLoading]);

  const fileInputRef = useRef<HTMLInputElement>(null);

  // التحقق من تكرار الفاتورة لنفس المورد
  useEffect(() => {
    const duplicate = PurchaseRepository.isInvoiceDuplicateForSupplier(
      header.invNum, 
      header.supplierId || header.supplierName
    );
    setIsDuplicate(duplicate);
  }, [header.invNum, header.supplierId, header.supplierName]);

  const financialSummary = useMemo(() => {
    const subtotal = items.reduce((a, b) => a + b.sum, 0);
    return { subtotal, final: subtotal };
  }, [items]);

  const handleInvNumSearch = (val: string) => {
    setHeader({...header, invNum: val});
    if (val.trim()) {
      const allPurchases = PurchaseRepository.getAll();
      const uniqueIds = Array.from(new Set(allPurchases.map(p => p.invoiceId))).filter(id => id.includes(val));
      setInvNumSuggestions(uniqueIds.slice(0, 5));
      setShowInvSuggestions(true);
    } else {
      setInvNumSuggestions([]);
      setShowInvSuggestions(false);
    }
  };

  const handleFileCapture = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      try {
        const compressed = await imageService.compressImage(file);
        setInvoiceImage(compressed);
        addToast('تم حفظ صورة الفاتورة بنجاح 📷', 'success');
      } catch (err) { addToast('فشل في معالجة الصورة', 'error'); }
    }
  };

  const handleSupplierFocus = () => {
    setSupplierSuggestions(suppliers);
    setShowSupplierDropdown(true);
  };

  const handleSupplierSearch = (val: string) => {
    setHeader({...header, supplierName: val, supplierId: '', supplierPhone: ''});
    if (val.trim().length > 0) {
      setSupplierSuggestions(suppliers.filter(s => s.name.toLowerCase().includes(val.toLowerCase())));
    } else {
      setSupplierSuggestions(suppliers);
    }
    setShowSupplierDropdown(true);
  };

  const selectSupplier = (s: Supplier) => {
    setHeader({
      ...header, 
      supplierName: s.name, 
      supplierId: s.id, 
      supplierPhone: s.phone || ''
    });
    setSupplierSuggestions([]);
    setShowSupplierDropdown(false);
    addToast(`تم اختيار المورد: ${s.name}`, 'info');
  };

  const selectProduct = (p: Product) => {
    setnewItem({ ...newItem, product_id: p.ProductID, name: p.Name, qty: 1, price: p.CostPrice || 0, expiry: p.ExpiryDate?.split('T')[0] || '', note: '' });
    setModalSearch(p.Name);
    setModalSuggestions([]);
  };

  const handleAddItem = () => {
    if (!modalSearch.trim() || newItem.qty <= 0) return;
    setItems(prev => [...prev, { id: db.generateId('P_ITM'), product_id: newItem.product_id || db.generateId('NEW_PRD'), name: modalSearch, qty: newItem.qty, price: newItem.price, sum: newItem.qty * newItem.price, expiry: newItem.expiry, note: newItem.note }]);
    setnewItem({ product_id: '', name: '', qty: 0, price: 0, stock: 0, note: '', expiry: '' });
    setModalSearch('');
    setIsItemModalOpen(false);
  };

  const handleSaveInvoice = useCallback(async () => {
    if (!header.supplierName.trim() || items.length === 0 || isSaving || isDuplicate) return;
    setIsSaving(true);
    try {
      const finalInvNum = header.invNum || PurchaseRepository.getNextInvoiceNumber();
      let finalSuppId = header.supplierId;
      if (!finalSuppId) {
        const existing = suppliers.find(s => s.name.toLowerCase() === header.supplierName.toLowerCase());
        if (existing) finalSuppId = existing.id;
        else {
          const newS = { id: db.generateId('S'), name: header.supplierName, phone: header.supplierPhone, openingBalance: 0, purchaseHistory: [] };
          await db.saveSupplier(newS as any);
          finalSuppId = newS.id;
        }
      }
      await processPurchase(finalSuppId, items.map(i => ({ product_id: i.product_id, qty: i.qty, price: i.price, expiry: i.expiry })), financialSummary.subtotal, finalInvNum, header.isCash, header.isReturn);
      draftService.clearDraft('purchase_active');
      addToast('تم ترحيل المشتريات بنجاح ✅', 'success');
      onNavigate?.('dashboard');
    } catch (e: any) { addToast("❌ خطأ: " + e.message, 'error'); } finally { setIsSaving(false); }
  }, [header, items, onNavigate, processPurchase, addToast, financialSummary, isDuplicate, suppliers]);

  return (
    <div className="flex flex-col h-full bg-[#F0F7F7] font-['Cairo'] pb-40" dir="rtl" onClick={() => { setShowSupplierDropdown(false); setShowInvSuggestions(false); }}>
      <div className="flex-1 overflow-y-auto px-4 py-4 space-y-4 custom-scrollbar">
        
        <div className="flex items-center justify-between mb-2">
           <div className="flex items-center gap-3">
             <div className="w-10 h-10 bg-white border border-slate-200 text-[#1E4D4D] rounded-xl flex items-center justify-center shadow-sm"><span className="text-xl">🛒</span></div>
             <div className="flex flex-col"><span className="text-[10px] font-black text-[#1E4D4D]">المشتريات</span><span className="text-[7px] text-slate-400 font-bold uppercase tracking-widest leading-none">Procurement</span></div>
           </div>
           
           <div className="flex items-center gap-3">
              <label className="flex items-center gap-2 bg-white px-3 py-1 rounded-full border border-slate-200 shadow-sm h-8 cursor-pointer transition-all hover:bg-red-50 group" onClick={e => e.stopPropagation()}>
                 <span className="text-[9px] font-black text-slate-700 group-hover:text-red-600 transition-colors">مرتجع</span>
                 <input type="checkbox" checked={header.isReturn} onChange={e => setHeader({...header, isReturn: e.target.checked})} className="w-4 h-4 rounded border-slate-300 text-red-600 focus:ring-red-500" />
              </label>

              <div className="flex bg-white p-1 rounded-full border border-[#10B981] h-8 w-32 shadow-sm overflow-hidden">
                 <button onClick={(e) => { e.stopPropagation(); setHeader({...header, isCash: true}); }} className={`flex-1 rounded-full text-[9px] font-black transition-all ${header.isCash ? 'bg-[#10B981] text-white shadow-md' : 'text-[#10B981]'}`}>نقداً</button>
                 <button onClick={(e) => { e.stopPropagation(); setHeader({...header, isCash: false}); }} className={`flex-1 rounded-full text-[9px] font-black transition-all ${!header.isCash ? 'bg-[#10B981] text-white shadow-md' : 'text-[#10B981]'}`}>آجل</button>
              </div>
           </div>
        </div>

        <div className="space-y-2">
          {/* الصف الأول: اسم المورد والتاريخ */}
          <div className="flex gap-2">
             <div className="w-2/3 relative" onClick={e => e.stopPropagation()}>
                <div className="bg-white border border-slate-200 rounded-xl px-4 py-2 shadow-sm h-11 flex items-center">
                   <input 
                    placeholder="ابحث أو اختر مورداً..." 
                    value={header.supplierName} 
                    onFocus={handleSupplierFocus}
                    onChange={e => handleSupplierSearch(e.target.value)} 
                    className="w-full font-black text-[#1E4D4D] bg-transparent outline-none text-right placeholder-slate-300 text-sm" 
                   />
                   <span className={`text-[10px] transition-transform duration-200 ${showSupplierDropdown ? 'rotate-180' : ''}`}>▼</span>
                </div>
                {showSupplierDropdown && supplierSuggestions.length > 0 && (
                  <div className="absolute top-full right-0 left-0 z-50 mt-1 bg-white border border-slate-200 rounded-xl shadow-xl overflow-hidden max-h-60 overflow-y-auto border-t-0 animate-in fade-in slide-in-from-top-1 custom-scrollbar">
                     <div className="px-4 py-2 bg-slate-50 border-b text-[8px] font-black text-slate-400 uppercase tracking-widest">الموردون المسجلون</div>
                     {supplierSuggestions.map(s => (
                       <button key={s.id} onClick={() => selectSupplier(s)} className="w-full text-right px-4 py-3 hover:bg-emerald-50 border-b last:border-0 font-black text-xs text-[#1E4D4D] flex justify-between items-center group transition-colors">
                         <div className="flex flex-col">
                            <span className="group-hover:text-emerald-700">{s.name}</span>
                            <span className="text-[8px] text-slate-300 font-bold">ID: {s.id}</span>
                         </div>
                         <span className="text-[10px] text-slate-400 font-bold bg-slate-100 px-2 py-0.5 rounded-full">{s.phone || 'بدون هاتف'}</span>
                       </button>
                     ))}
                  </div>
                )}
                {showSupplierDropdown && supplierSuggestions.length === 0 && header.supplierName.trim() && (
                  <div className="absolute top-full right-0 left-0 z-50 mt-1 bg-white border border-slate-200 rounded-xl shadow-xl p-4 text-center animate-in fade-in slide-in-from-top-1">
                     <p className="text-[10px] font-bold text-slate-400 mb-2">مورد جديد غير مسجل</p>
                     <Badge variant="info">سيتم حفظه تلقائياً عند الترحيل ✨</Badge>
                  </div>
                )}
             </div>
             <div className="w-1/3">
                <div className="bg-white border border-slate-200 rounded-xl px-2 py-2 h-11 flex items-center justify-between shadow-sm">
                   <input type="date" value={header.date} onChange={e => setHeader({...header, date: e.target.value})} className="w-full font-black text-[#1E4D4D] bg-transparent outline-none text-center text-[10px]" />
                </div>
             </div>
          </div>

          {/* الصف الثاني: رقم الفاتورة والبيان */}
          <div className="flex gap-2">
             <div className="w-1/2 relative" onClick={e => e.stopPropagation()}>
                <div className={`bg-white border rounded-xl px-4 py-2 h-11 shadow-sm flex items-center transition-colors ${isDuplicate ? 'border-red-500 bg-red-50' : 'border-slate-200'}`}>
                   <input 
                    type="text"
                    placeholder="رقم الفاتورة#" 
                    value={header.invNum} 
                    onFocus={() => { if (header.invNum && !isDuplicate) setShowInvSuggestions(true); }}
                    onChange={e => handleInvNumSearch(e.target.value)} 
                    className={`w-full font-black bg-transparent outline-none text-right placeholder-slate-300 text-sm ${isDuplicate ? 'text-red-600' : 'text-[#1E4D4D]'}`} 
                   />
                </div>
                {showInvSuggestions && invNumSuggestions.length > 0 && !isDuplicate && (
                  <div className="absolute top-full left-0 right-0 z-[60] mt-1 bg-white border border-slate-200 rounded-xl shadow-2xl overflow-hidden min-w-[120px] animate-in zoom-in-95 duration-200">
                    <p className="px-2 py-1 bg-slate-50 text-[8px] font-black text-slate-400 border-b uppercase text-center">أرقام سابقة</p>
                    {invNumSuggestions.map((id, idx) => (
                      <button key={idx} onClick={() => { setHeader({...header, invNum: id}); setShowInvSuggestions(false); }} className="w-full px-3 py-2 text-center text-[11px] font-black text-[#1E4D4D] hover:bg-emerald-50 border-b last:border-0 transition-colors">{id}</button>
                    ))}
                  </div>
                )}
                {isDuplicate && (
                   <div className="absolute top-full right-0 mt-1 whitespace-nowrap bg-red-600 text-white text-[8px] font-black px-2 py-1 rounded shadow-lg animate-in fade-in slide-in-from-top-1 z-50">
                      هذا الرقم مسجل مسبقاً لهذا المورد ⚠️
                   </div>
                )}
             </div>
             <div className="w-1/2 flex items-center bg-white border border-slate-200 rounded-xl px-4 py-2 shadow-sm h-11">
                <input placeholder="البيان / الملاحظات..." value={header.notes} onChange={e => setHeader({...header, notes: e.target.value})} className="flex-1 font-black text-[#1E4D4D] bg-transparent outline-none text-right placeholder-slate-300 text-sm" />
                <button onClick={() => fileInputRef.current?.click()} className={`text-xl mr-2 transition-all hover:scale-110 ${invoiceImage ? 'text-emerald-500' : 'opacity-30'}`}>📷</button>
                <input type="file" accept="image/*" capture="environment" className="hidden" ref={fileInputRef} onChange={handleFileCapture} />
             </div>
          </div>

          {/* معلومات إضافية للمورد (تظهر عند الاختيار) */}
          <div className="flex gap-2">
             <div className="w-1/2">
                <div className="bg-slate-50 border border-slate-100 rounded-xl px-4 py-2 h-10 flex items-center justify-between">
                   <span className="text-[9px] font-black text-slate-400 uppercase">هاتف المورد</span>
                   <input 
                    placeholder="0000..." 
                    value={header.supplierPhone} 
                    onChange={e => setHeader({...header, supplierPhone: e.target.value})}
                    className="bg-transparent border-0 font-black text-[#1E4D4D] text-xs text-left outline-none w-1/2" 
                   />
                </div>
             </div>
          </div>
        </div>

        <Card noPadding className="flex-1 min-h-[400px] !rounded-[24px] mt-4 shadow-xl border-slate-100">
           <div className="p-4 border-b border-slate-50 flex items-center justify-between gap-3 bg-slate-50/20">
              <div className="flex-1 max-w-sm relative">
                <input placeholder="بحث في البنود..." value={tableSearch} onChange={e => setTableSearch(e.target.value)} className="w-full bg-white border border-slate-200 rounded-xl px-10 py-2.5 text-[11px] font-black shadow-sm" />
                <span className="absolute right-3 top-1/2 -translate-y-1/2 opacity-30 text-sm">🔍</span>
              </div>
              <Button onClick={() => setIsItemModalOpen(true)} variant="primary" icon="＋" className="h-10 !rounded-[12px] !px-6 font-black text-[11px]">إضافة صنف</Button>
           </div>
           <div className="flex-1 overflow-x-auto custom-scrollbar">
              <table className="w-full text-right text-[11px]">
                 <thead className="bg-slate-100 text-slate-500 font-black border-b border-slate-200">
                    <tr><th className="px-6 py-4 text-right">الصنف</th><th className="px-6 py-4 text-center">الكمية</th><th className="px-6 py-4 text-center">التكلفة</th><th className="px-6 py-4 text-left">الإجمالي</th></tr>
                 </thead>
                 <tbody className="divide-y divide-slate-100">
                    {items.filter(i => i.name.toLowerCase().includes(tableSearch.toLowerCase())).map(item => (
                      <tr key={item.id} className="hover:bg-slate-50 group">
                         <td className="px-6 py-4 flex items-center gap-3">
                            <button onClick={() => setItems(items.filter(i => i.id !== item.id))} className="w-8 h-8 rounded-lg bg-red-50 text-red-400 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-all shadow-sm">✕</button>
                            <span className="font-black text-[#1E4D4D] text-sm">{item.name}</span>
                         </td>
                         <td className="px-6 py-4 text-center font-bold text-slate-700">{item.qty}</td>
                         <td className="px-6 py-4 text-center font-bold text-slate-700">{item.price.toLocaleString()}</td>
                         <td className="px-6 py-4 text-left font-black text-[#1E4D4D] text-sm">{item.sum.toLocaleString()} <span className="text-[8px] opacity-30">{currency}</span></td>
                      </tr>
                    ))}
                 </tbody>
              </table>
           </div>
        </Card>
      </div>

      <div className="fixed bottom-0 left-0 right-0 p-4 bg-white/95 backdrop-blur-xl border-t border-slate-100 shadow-2xl z-[100]">
        <div className="max-w-7xl mx-auto flex items-center justify-between gap-4">
           <div className="flex flex-col">
              <p className="text-[8px] font-black text-slate-400 uppercase tracking-widest">صافي الفاتورة</p>
              <h3 className="text-2xl font-black text-[#1E4D4D]">{financialSummary.final.toLocaleString()} <span className="text-xs opacity-30 uppercase ml-1">{currency}</span></h3>
           </div>
           <Button onClick={handleSaveInvoice} disabled={items.length === 0 || isSaving || isDuplicate || !header.supplierName} variant="primary" className="h-14 px-12 !rounded-[20px] text-base shadow-2xl" isLoading={isSaving} icon="💾">حفظ وترحيل</Button>
        </div>
      </div>

      <Modal isOpen={isItemModalOpen} onClose={() => setIsItemModalOpen(false)} title="إضافة صنف" footer={<Button onClick={handleAddItem} variant="success" className="w-full h-14 !rounded-[16px] font-black text-base" icon="✅">تأكيد الإضافة</Button>}>
        <div className="space-y-5">
           <div className="relative">
              <Input label="اسم الصنف" placeholder="بحث..." value={modalSearch} onChange={e => { setModalSearch(e.target.value); if (e.target.value.length > 1) setModalSuggestions(ProductRepository.search(e.target.value)); else setModalSuggestions([]); }} />
              {modalSuggestions.length > 0 && (
                <div className="absolute top-full right-0 left-0 z-[100] mt-1 bg-white border border-slate-200 rounded-[16px] shadow-2xl max-h-48 overflow-y-auto">
                   {modalSuggestions.map(p => (
                     <button key={p.ProductID} onClick={() => selectProduct(p)} className="w-full text-right px-6 py-4 hover:bg-emerald-50 border-b last:border-0 font-black text-[11px] flex justify-between">
                       <span>{p.Name}</span><span className="text-[9px] opacity-40">رصيد: {p.StockQuantity}</span>
                     </button>
                   ))}
                </div>
              )}
           </div>
           <div className="grid grid-cols-2 gap-4">
              <Input label="الكمية" type="number" className="text-center" value={newItem.qty || ''} onChange={e => setnewItem({...newItem, qty: parseInt(e.target.value) || 0})} />
              <Input label="سعر التكلفة" type="number" className="text-center" value={newItem.price || ''} onChange={e => setnewItem({...newItem, price: parseFloat(e.target.value) || 0})} />
           </div>
           <Input label="الصلاحية" type="date" value={newItem.expiry} onChange={e => setnewItem({...newItem, expiry: e.target.value})} icon="📅" />
        </div>
      </Modal>
    </div>
  );
};

export default PurchasesModule;
