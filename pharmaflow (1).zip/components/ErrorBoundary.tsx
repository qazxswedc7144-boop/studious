
// @google/genai Coding Guidelines followed: Using React and Standard TS patterns.

import React, { ErrorInfo, ReactNode } from 'react';

interface Props {
  children?: ReactNode;
}

interface State {
  hasError: boolean;
  error: Error | null;
}

/**
 * ErrorBoundary component to catch rendering errors in the component tree.
 */
class ErrorBoundary extends React.Component<Props, State> {
  // Explicit declarations to satisfy TS compiler if it fails to infer from base React.Component
  public state: State;
  public props: Props;

  constructor(props: Props) {
    super(props);
    this.props = props;
    this.state = {
      hasError: false,
      error: null
    };
  }

  // Static method to update state when an error occurs in a child component during rendering.
  public static getDerivedStateFromError(error: Error): State {
    return { hasError: true, error };
  }

  // Lifecycle method to log errors caught by the boundary
  public componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    console.error("Uncaught error caught by ErrorBoundary:", error, errorInfo);
  }

  public render(): ReactNode {
    const { hasError, error } = this.state;
    const { children } = this.props;

    if (hasError) {
      return (
        <div className="min-h-screen bg-[#F0F7F7] flex items-center justify-center p-6 text-right" dir="rtl">
          <div className="bg-white p-10 rounded-[48px] shadow-2xl max-w-lg w-full border-2 border-red-100 space-y-6">
            <div className="w-20 h-20 bg-red-50 text-red-500 rounded-3xl flex items-center justify-center text-4xl mx-auto">⚠️</div>
            <h1 className="text-2xl font-black text-[#1E4D4D] text-center">عذراً، حدث خطأ غير متوقع</h1>
            <p className="text-slate-500 font-bold text-center leading-relaxed">
              واجه النظام مشكلة تقنية مفاجئة. تم تسجيل الخطأ وسنقوم بمعالجته. يرجى محاولة إعادة تحميل الصفحة.
            </p>
            <div className="bg-slate-50 p-4 rounded-2xl text-[10px] font-mono text-red-400 overflow-auto max-h-32">
              {error?.toString()}
            </div>
            <button 
              onClick={() => window.location.reload()}
              className="w-full bg-[#1E4D4D] text-white py-4 rounded-2xl font-black shadow-lg hover:bg-[#2A6666] transition-all"
            >
              إعادة تشغيل النظام 🔄
            </button>
          </div>
        </div>
      );
    }

    return children || null;
  }
}

export default ErrorBoundary;
