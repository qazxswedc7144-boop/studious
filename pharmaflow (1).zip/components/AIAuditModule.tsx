
import React, { useState, useMemo, useEffect } from 'react';
import { useAccounting, useUI, useInventory } from '../store/AppContext';
import { db } from '../services/database';
import { Card, Button, Badge, HelpTooltip } from './SharedUI';
import { accountingService } from '../services/accounting.service';
import { getSmartChatResponse } from '../services/geminiService';

interface AuditAnomalies {
  duplicates: any[];
  unbalanced: any[];
  unusualExpenses: any[];
}

const AIAuditModule: React.FC<{ onNavigate?: (view: any) => void }> = ({ onNavigate }) => {
  const { journalEntries, refreshAccounting, sales } = useAccounting();
  const { products } = useInventory();
  const { currency, addToast } = useUI();
  
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [auditResults, setAuditResults] = useState<AuditAnomalies | null>(null);
  const [forecast, setForecast] = useState<number[]>([]);
  const [aiReport, setAiReport] = useState<string | null>(null);

  useEffect(() => {
    const p = accountingService.getPredictedCashflow(7);
    setForecast(p);
  }, []);

  const runSmartAudit = async () => {
    setIsAnalyzing(true);
    addToast("جاري تشغيل مراجعة الذكاء الاصطناعي...", "info");

    try {
      const seenRefs = new Set();
      const duplicates = sales.filter(s => {
        if (seenRefs.has(s.sale_id)) return true;
        seenRefs.add(s.sale_id);
        return false;
      });

      const unbalanced = journalEntries.filter(e => {
        const debit = e.lines.filter(l => l.type === 'DEBIT').reduce((a, b) => a + b.amount, 0);
        const credit = e.lines.filter(l => l.type === 'CREDIT').reduce((a, b) => a + b.amount, 0);
        return Math.abs(debit - credit) > 0.01;
      });

      const cashflow = db.getCashFlow().filter(c => c.type === 'خرج');
      const avg = cashflow.reduce((a, b) => a + b.amount, 0) / (cashflow.length || 1);
      const unusualExpenses = cashflow.filter(c => c.amount > avg * 3);

      setAuditResults({ duplicates, unbalanced, unusualExpenses });

      const metrics = accountingService.getFinancialMetrics();
      const prompt = `
        أنت مدقق حسابات ذكي. حلل هذه البيانات المحاسبية للصيدلية:
        - إجمالي المبيعات: ${metrics.income}
        - عدد القيود غير المتوازنة: ${unbalanced.length}
        - عدد المصاريف الضخمة: ${unusualExpenses.length}
        - التوقعات النقدية للأسبوع القادم: ${forecast.join(', ')}
        قدم تقريراً باللغة العربية يتضمن:
        1. تقييم جودة البيانات.
        2. تنبيه بأي عجز نقدي متوقع.
        3. نصيحة لأتمتة التصحيح.
      `;
      const res = await getSmartChatResponse(prompt, [], { thinking: true });
      setAiReport(res.text || "لم يتمكن المساعد من توليد التقرير.");
      
      addToast("اكتملت عملية المراجعة الذكية ✅", "success");
    } catch (e) {
      addToast("فشل في تحليل البيانات", "error");
    } finally {
      setIsAnalyzing(false);
    }
  };

  const handleAutoFix = async () => {
    if (!auditResults) return;
    
    try {
      await db.runTransaction(async () => {
        auditResults.unbalanced.forEach(entry => {
          const debit = entry.lines.filter(l => l.type === 'DEBIT').reduce((a, b) => a + b.amount, 0);
          const credit = entry.lines.filter(l => l.type === 'CREDIT').reduce((a, b) => a + b.amount, 0);
          const diff = debit - credit;
          
          if (Math.abs(diff) < 100) { 
            const fixLine = {
              accountId: 'ACC-ADJ',
              accountName: 'تسويات تقريب آلية',
              amount: Math.abs(diff),
              type: (diff > 0 ? 'CREDIT' : 'DEBIT') as 'CREDIT' | 'DEBIT'
            };
            const updated = { ...entry, lines: [...entry.lines, fixLine], notes: entry.notes + " (تم التصحيح آلياً عبر AI)" };
            db.addJournalEntry(updated);
          }
        });
      });
      
      addToast("تمت معالجة كافة الفروقات الطفيفة بنجاح 🛠️", "success");
      refreshAccounting();
      runSmartAudit();
    } catch (error: any) {
      addToast(`فشل الإصلاح الآلي: ${error.message}`, "error");
    }
  };

  return (
    <div className="space-y-8 p-6 md:p-10 pb-32 animate-in fade-in duration-500" dir="rtl">
      <div className="flex flex-col md:flex-row items-center justify-between gap-6 bg-white p-8 rounded-[40px] shadow-sm border border-slate-100">
        <div className="flex items-center gap-6">
          <div className="w-16 h-16 bg-[#10B981] text-white rounded-3xl flex items-center justify-center text-4xl shadow-xl animate-pulse">🤖</div>
          <div>
            <h2 className="text-3xl font-black text-[#1E4D4D]">المراجعة والتدقيق الذكي</h2>
            <p className="text-slate-400 font-bold text-sm">نظام المراجعة التلقائية والتنبؤ المالي المدعوم بـ AI</p>
          </div>
        </div>
        <div className="flex gap-3">
          <Button variant="primary" onClick={runSmartAudit} isLoading={isAnalyzing} icon="🔍">بدء الفحص الشامل</Button>
          <button onClick={() => onNavigate?.('dashboard')} className="w-12 h-12 bg-white border border-slate-100 rounded-2xl flex items-center justify-center text-[#1E4D4D] text-2xl font-black shadow-sm">➦</button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-1 space-y-6">
          <Card className="bg-[#1E4D4D] text-white overflow-hidden relative border-4 border-emerald-900/20">
             <div className="relative z-10 space-y-4">
                <div className="flex justify-between items-center">
                   <h3 className="text-sm font-black uppercase tracking-widest">توقعات التدفق النقدي</h3>
                   <Badge variant="success">AI Predictor</Badge>
                </div>
                <div className="flex items-end gap-2 h-32 pt-4">
                   {forecast.map((val, i) => (
                     <div key={i} className="flex-1 flex flex-col items-center gap-2 group">
                        <div className="w-full bg-white/20 rounded-t-lg transition-all hover:bg-white/40 cursor-help relative" style={{ height: `${(val / (Math.max(...forecast) || 1)) * 100}%` }}>
                           <div className="absolute bottom-full mb-1 left-1/2 -translate-x-1/2 bg-white text-[#1E4D4D] text-[8px] font-black px-1.5 py-0.5 rounded opacity-0 group-hover:opacity-100 whitespace-nowrap">+{val}</div>
                        </div>
                        <span className="text-[8px] font-bold opacity-50">ي{i+1}</span>
                     </div>
                   ))}
                </div>
                <p className="text-[10px] opacity-70 font-bold leading-relaxed">
                   بناءً على المبيعات التاريخية، يتوقع النظام سيولة نقدية تراكمية تصل إلى <span className="text-emerald-300">+{forecast.reduce((a,b)=>a+b,0).toLocaleString()}</span> خلال الـ 7 أيام القادمة.
                </p>
             </div>
             <div className="absolute -right-10 -bottom-10 w-32 h-32 bg-white/5 rounded-full blur-2xl"></div>
          </Card>

          <Card className="space-y-4">
            <h4 className="text-xs font-black text-slate-400 uppercase tracking-widest">تنبيهات الأتمتة الذكية</h4>
            <div className="space-y-3">
               {products.some(p => p.quantityinstock === 0) && (
                 <div className="p-3 bg-red-50 border border-red-100 rounded-2xl flex gap-3">
                    <span className="text-xl">🚨</span>
                    <div>
                       <p className="text-[10px] font-black text-red-600">نفاذ مخزون حرج</p>
                       <p className="text-[9px] text-red-400 font-bold">هناك أصناف رصيدها صفر وتؤثر على نمو المبيعات.</p>
                    </div>
                 </div>
               )}
               <div className="p-3 bg-blue-50 border border-blue-100 rounded-2xl flex gap-3">
                  <span className="text-xl">🛡️</span>
                  <div>
                     <p className="text-[10px] font-black text-blue-600">تحديثات ضريبية</p>
                     <p className="text-[9px] text-blue-400 font-bold">لم يطرأ أي تغيير على معدلات الضريبة المسجلة (15%).</p>
                  </div>
               </div>
            </div>
          </Card>
        </div>

        <div className="lg:col-span-2 space-y-6">
           {auditResults ? (
             <div className="space-y-6 animate-in slide-in-from-left duration-500">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                   <div className="bg-white p-6 rounded-[32px] border border-slate-100 shadow-sm text-center">
                      <h5 className="text-[10px] font-black text-slate-400 uppercase mb-2">فواتير مكررة</h5>
                      <p className={`text-2xl font-black ${auditResults.duplicates.length > 0 ? 'text-red-500' : 'text-emerald-500'}`}>{auditResults.duplicates.length}</p>
                   </div>
                   <div className="bg-white p-6 rounded-[32px] border border-slate-100 shadow-sm text-center">
                      <h5 className="text-[10px] font-black text-slate-400 uppercase mb-2">قيود غير متزنة</h5>
                      <p className={`text-2xl font-black ${auditResults.unbalanced.length > 0 ? 'text-red-500' : 'text-emerald-500'}`}>{auditResults.unbalanced.length}</p>
                   </div>
                   <div className="bg-white p-6 rounded-[32px] border border-slate-100 shadow-sm text-center">
                      <h5 className="text-[10px] font-black text-slate-400 uppercase mb-2">مصاريف استثنائية</h5>
                      <p className={`text-2xl font-black ${auditResults.unusualExpenses.length > 0 ? 'text-amber-500' : 'text-emerald-500'}`}>{auditResults.unusualExpenses.length}</p>
                   </div>
                </div>

                {auditResults.unbalanced.length > 0 && (
                  <Card className="border-2 border-red-100 bg-red-50/30">
                     <div className="flex justify-between items-center mb-4">
                        <h4 className="text-sm font-black text-red-700">القيود المحاسبية التي تحتاج تصحيحاً</h4>
                        <Button variant="danger" size="sm" onClick={handleAutoFix} icon="🛠️">تصحيح آلي للفروقات البسيطة</Button>
                     </div>
                     <div className="space-y-3">
                        {auditResults.unbalanced.slice(0,3).map(e => (
                          <div key={e.id} className="bg-white p-4 rounded-2xl flex justify-between items-center text-xs">
                             <span className="font-bold text-slate-500">#{e.sourceId}</span>
                             <span className="font-black text-red-500">فرق في القيد!</span>
                          </div>
                        ))}
                     </div>
                  </Card>
                )}

                {aiReport && (
                  <Card className="bg-slate-50 border-slate-200">
                     <div className="flex items-center gap-2 mb-4">
                        <span className="text-xl">📝</span>
                        <h4 className="text-sm font-black text-[#1E4D4D]">تقرير المراجعة الاستراتيجي (AI Report)</h4>
                     </div>
                     <div className="text-xs font-bold text-slate-700 leading-relaxed whitespace-pre-wrap bg-white p-6 rounded-[24px] border border-slate-100 shadow-inner">
                        {aiReport}
                     </div>
                  </Card>
                )}
             </div>
           ) : (
             <div className="bg-white rounded-[40px] border-2 border-dashed border-slate-200 h-96 flex flex-col items-center justify-center text-center p-10 space-y-4">
                <div className="text-6xl opacity-20">📊</div>
                <h3 className="text-lg font-black text-slate-300">بانتظار تشغيل الفحص الذكي</h3>
                <p className="text-sm text-slate-300 font-bold max-w-xs">اضغط على زر "بدء الفحص الشامل" للسماح للذكاء الاصطناعي بمراجعة كافة العمليات المالية.</p>
             </div>
           )}
        </div>
      </div>
    </div>
  );
};

export default AIAuditModule;
