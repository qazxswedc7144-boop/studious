
import React, { useState } from 'react';

// --- Toast Component ---
export const Toast: React.FC<{ message: string; type: 'success' | 'error' | 'info' | 'warning'; onClose: () => void }> = ({ message, type, onClose }) => {
  const styles = {
    success: "bg-emerald-600 border-emerald-500 shadow-emerald-200/50",
    error: "bg-red-600 border-red-500 shadow-red-200/50",
    info: "bg-[#1E4D4D] border-slate-700 shadow-slate-200/50",
    warning: "bg-amber-500 border-amber-400 shadow-amber-200/50"
  };

  const icons = {
    success: "✅",
    error: "❌",
    info: "ℹ️",
    warning: "⚠️"
  };

  return (
    <div className={`fixed bottom-24 left-1/2 -translate-x-1/2 z-[999] min-w-[320px] max-w-[90vw] p-5 rounded-[28px] border-4 border-white/20 text-white flex items-center justify-between gap-4 animate-in slide-in-from-bottom-10 fade-in duration-500 shadow-2xl ${styles[type]}`}>
      <div className="flex items-center gap-3">
        <span className="text-xl">{icons[type]}</span>
        <p className="text-xs font-black leading-relaxed">{message}</p>
      </div>
      <button onClick={onClose} className="w-10 h-10 rounded-full bg-white/10 flex items-center justify-center font-black text-xs hover:bg-white/20 transition-all active:scale-90 touch-manipulation">✕</button>
    </div>
  );
};

// --- Card Component ---
export const Card: React.FC<{ children: React.ReactNode; className?: string; noPadding?: boolean }> = ({ children, className = "", noPadding = false }) => (
  <div className={`bg-white rounded-[32px] sm:rounded-[40px] border border-slate-100 shadow-sm overflow-hidden transition-all hover:shadow-md active:shadow-sm sm:active:shadow-md ${noPadding ? '' : 'p-6 sm:p-8'} ${className}`}>
    {children}
  </div>
);

// --- Button Component ---
interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'primary' | 'secondary' | 'danger' | 'success' | 'ghost';
  isLoading?: boolean;
  icon?: string;
  size?: 'sm' | 'md' | 'lg';
}

export const Button: React.FC<ButtonProps> = ({ 
  children, variant = 'primary', isLoading, icon, size = 'md', className = "", ...props 
}) => {
  const baseStyles = "relative flex items-center justify-center gap-2 font-black transition-all active:scale-95 disabled:opacity-50 disabled:cursor-not-allowed overflow-hidden touch-manipulation min-h-[48px]";
  
  const variants = {
    primary: "bg-[#1E4D4D] text-white hover:bg-[#2A6666] shadow-lg shadow-emerald-50/50",
    secondary: "bg-slate-50 text-[#1E4D4D] hover:bg-slate-100 border border-slate-100",
    danger: "bg-red-50 text-red-600 hover:bg-red-500 hover:text-white border border-red-100",
    success: "bg-[#10B981] text-white hover:bg-emerald-600 shadow-lg shadow-emerald-50/50",
    ghost: "bg-transparent text-slate-400 hover:text-[#1E4D4D] hover:bg-slate-50"
  };

  const sizes = {
    sm: "px-4 py-2 text-[10px] rounded-xl min-h-[40px]",
    md: "px-6 py-3.5 text-xs rounded-2xl min-h-[48px]",
    lg: "px-10 py-5 text-sm rounded-3xl min-h-[60px]"
  };

  return (
    <button className={`${baseStyles} ${variants[variant]} ${sizes[size]} ${className}`} {...props}>
      {isLoading ? (
        <div className="w-5 h-5 border-2 border-current border-t-transparent rounded-full animate-spin" />
      ) : (
        <>
          {icon && <span className="text-lg">{icon}</span>}
          {children}
        </>
      )}
    </button>
  );
};

// --- Input Component ---
interface InputProps extends React.InputHTMLAttributes<HTMLInputElement> {
  label?: string;
  error?: string;
  icon?: string;
  help?: string;
}

export const Input = React.forwardRef<HTMLInputElement, InputProps>(({ label, error, icon, help, className = "", ...props }, ref) => (
  <div className="space-y-1.5 w-full relative">
    <div className="flex items-center justify-between mr-1">
      {label && <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest block">{label}</label>}
      {help && <HelpTooltip message={help} />}
    </div>
    <div className="relative group">
      <input
        ref={ref}
        className={`w-full bg-slate-50/50 border-2 rounded-2xl px-5 py-4 text-sm font-black text-[#1E4D4D] outline-none transition-all focus:bg-white focus:ring-4 focus:ring-[#1E4D4D]/5 touch-manipulation ${
          error ? 'border-red-200 focus:border-red-500' : 'border-slate-100 focus:border-[#1E4D4D]'
        } ${icon ? 'pr-12' : ''} ${className}`}
        {...props}
      />
      {icon && <span className="absolute right-4 top-1/2 -translate-y-1/2 opacity-30 text-lg group-focus-within:opacity-100 transition-opacity">{icon}</span>}
    </div>
    {error && <p className="text-[9px] font-black text-red-500 mr-1 animate-in slide-in-from-top-1">{error}</p>}
  </div>
));

// --- Modal Component ---
export const Modal: React.FC<{ isOpen: boolean; onClose: () => void; title: string; children: React.ReactNode; footer?: React.ReactNode }> = ({
  isOpen, onClose, title, children, footer
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[500] flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-in fade-in duration-300">
      <div className="bg-white w-full max-w-lg rounded-[40px] sm:rounded-[48px] p-0 flex flex-col animate-in zoom-in duration-300 shadow-2xl overflow-hidden border-4 border-white max-h-[90vh]">
        <div className="p-6 flex items-center justify-between bg-slate-50/50 border-b border-slate-100 shrink-0">
           <h3 className="text-base font-black text-[#1E4D4D]">{title}</h3>
           <button onClick={onClose} className="w-12 h-12 bg-white border border-slate-100 text-slate-400 rounded-full flex items-center justify-center font-black hover:bg-red-50 hover:text-red-500 transition-all active:scale-90 shadow-sm touch-manipulation">✕</button>
        </div>
        <div className="px-6 py-8 overflow-y-auto custom-scrollbar flex-1">
          {children}
        </div>
        {footer && (
          <div className="px-6 py-6 bg-slate-50/80 border-t border-slate-100 flex items-center gap-4 shrink-0">
            {footer}
          </div>
        )}
      </div>
    </div>
  );
};

// --- Badge Component ---
export const Badge: React.FC<{ children: React.ReactNode; variant?: 'success' | 'warning' | 'danger' | 'info' | 'neutral' }> = ({
  children, variant = 'neutral'
}) => {
  const styles = {
    success: "bg-emerald-50 text-emerald-600 border-emerald-100",
    warning: "bg-amber-50 text-amber-600 border-amber-100",
    danger: "bg-red-50 text-red-600 border-red-100",
    info: "bg-blue-50 text-blue-600 border-blue-100",
    neutral: "bg-slate-50 text-slate-400 border-slate-100"
  };

  return (
    <span className={`px-3 py-1 rounded-full text-[9px] font-black border transition-all ${styles[variant]}`}>
      {children}
    </span>
  );
};

// --- Help Tooltip Component ---
export const HelpTooltip: React.FC<{ message: string }> = ({ message }) => {
  const [show, setShow] = useState(false);

  return (
    <div className="relative inline-block">
      <button 
        type="button"
        onMouseEnter={() => setShow(true)}
        onMouseLeave={() => setShow(false)}
        onClick={() => setShow(!show)}
        className="w-6 h-6 rounded-full bg-slate-100 text-slate-400 flex items-center justify-center text-[10px] hover:bg-[#1E4D4D] hover:text-white transition-all cursor-help active:scale-90 touch-manipulation"
      >
        ?
      </button>
      {show && (
        <div className="absolute bottom-full mb-3 right-0 w-56 p-4 bg-slate-800 text-white text-[11px] font-bold rounded-2xl shadow-xl z-[600] animate-in fade-in slide-in-from-bottom-2 leading-relaxed">
          {message}
          <div className="absolute top-full right-2.5 w-0 h-0 border-l-[8px] border-l-transparent border-r-[8px] border-r-transparent border-t-[8px] border-t-slate-800"></div>
        </div>
      )}
    </div>
  );
};
