
import React, { useState, useMemo } from 'react';
import { useInventory, useUI } from '../store/AppContext';
import { Product } from '../types';
import { db } from '../services/database';
import { notificationService } from '../services/notification.service';
import { Card, Button, Input, Modal, Badge } from './SharedUI';

const InventoryModule: React.FC<{ onNavigate?: (view: any) => void }> = ({ onNavigate }) => {
  const { products } = useInventory();
  const { refreshGlobal, addToast, currency } = useUI();
  const [searchTerm, setSearchTerm] = useState('');
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [inventoryAlerts, setInventoryAlerts] = useState<{ message: string, type: 'error' | 'warning' }[]>([]);
  const [isAlertsModalOpen, setIsAlertsModalOpen] = useState(false);

  const filtered = useMemo(() => {
    return products.filter(p => 
      p.Name.toLowerCase().includes(searchTerm.toLowerCase()) || 
      p.ProductID.includes(searchTerm)
    );
  }, [products, searchTerm]);

  const handleSave = () => {
    if (!editingProduct) return;
    db.saveProduct(editingProduct);
    refreshGlobal();
    setEditingProduct(null);
    addToast("تم حفظ بيانات المنتج في جدول المخزن ✅", "success");
  };

  const handleCheckAlerts = () => {
    const alerts = notificationService.checkInventoryAlerts(products);
    if (alerts.length === 0) {
      addToast("المخزن سليم! لا توجد نواقص أو أصناف منتهية حالياً ✅", "success");
    } else {
      setInventoryAlerts(alerts);
      setIsAlertsModalOpen(true);
    }
  };

  return (
    <div className="p-6 space-y-6 bg-[#F0F7F7] min-h-full" dir="rtl">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <h2 className="text-2xl font-black text-[#1E4D4D]">جدول المنتجات والمخزن</h2>
        <div className="flex gap-2">
          <Button variant="secondary" icon="⚠️" onClick={handleCheckAlerts}>فحص التنبيهات</Button>
          <Button icon="＋" onClick={() => setEditingProduct({ ProductID: db.generateId('P'), Name: '', Category: 'أدوية', UnitPrice: 0, CostPrice: 0, StockQuantity: 0, ExpiryDate: '', SupplierID: '', MinLevel: 5, costMethod: 'AVG', batches: [], name: '', unitPrice: 0, costPrice: 0, stockQuantity: 0, minLevel: 0, expiryDate: '', id: '' })}>إضافة صنف جديد</Button>
        </div>
      </div>

      <Input placeholder="بحث باسم المنتج أو ID..." value={searchTerm} onChange={e => setSearchTerm(e.target.value)} icon="🔍" />

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filtered.map(p => (
          <Card key={p.ProductID} className="border-r-8 border-r-[#1E4D4D] hover:shadow-xl transition-all">
            <div className="flex justify-between items-start mb-4">
               <div>
                  <h3 className="text-lg font-black text-[#1E4D4D]">{p.Name}</h3>
                  <p className="text-[10px] text-slate-400 font-bold uppercase">ID: {p.ProductID}</p>
               </div>
               <Badge variant={p.StockQuantity <= p.MinLevel ? "danger" : "success"}>
                  {p.StockQuantity <= p.MinLevel ? "تحت حد الطلب" : "متوفر"}
               </Badge>
            </div>
            <div className="grid grid-cols-2 gap-4 text-center bg-slate-50 p-4 rounded-2xl">
               <div><p className="text-[9px] font-black text-slate-400">الرصيد</p><p className="text-xl font-black text-[#1E4D4D]">{p.StockQuantity}</p></div>
               <div><p className="text-[9px] font-black text-slate-400">السعر</p><p className="text-xl font-black text-emerald-600">{p.UnitPrice}</p></div>
            </div>
            <div className="mt-4 flex justify-between gap-2">
               <Button variant="secondary" className="flex-1" onClick={() => setEditingProduct(p)}>تعديل البيانات</Button>
            </div>
          </Card>
        ))}
      </div>

      {editingProduct && (
        <Modal isOpen={!!editingProduct} onClose={() => setEditingProduct(null)} title="تعديل بيانات الصنف في الجدول" footer={<Button className="w-full h-14" onClick={handleSave}>حفظ في قاعدة البيانات ✅</Button>}>
          <div className="space-y-4">
             <Input label="اسم المنتج (Name)" value={editingProduct.Name} onChange={e => setEditingProduct({...editingProduct, Name: e.target.value})} />
             <div className="grid grid-cols-2 gap-4">
                <Input label="سعر البيع (UnitPrice)" type="number" value={editingProduct.UnitPrice} onChange={e => setEditingProduct({...editingProduct, UnitPrice: parseFloat(e.target.value) || 0})} />
                <Input label="سعر التكلفة (CostPrice)" type="number" value={editingProduct.CostPrice} onChange={e => setEditingProduct({...editingProduct, CostPrice: parseFloat(e.target.value) || 0})} />
             </div>
             <div className="grid grid-cols-2 gap-4">
                <Input label="الكمية (StockQuantity)" type="number" value={editingProduct.StockQuantity} onChange={e => setEditingProduct({...editingProduct, StockQuantity: parseFloat(e.target.value) || 0})} />
                <Input label="حد التنبيه (MinLevel)" type="number" value={editingProduct.MinLevel} onChange={e => setEditingProduct({...editingProduct, MinLevel: parseFloat(e.target.value) || 0})} />
             </div>
             <Input label="تاريخ الانتهاء (ExpiryDate)" type="date" value={editingProduct.ExpiryDate} onChange={e => setEditingProduct({...editingProduct, ExpiryDate: e.target.value})} />
          </div>
        </Modal>
      )}

      <Modal 
        isOpen={isAlertsModalOpen} 
        onClose={() => setIsAlertsModalOpen(false)} 
        title="تقرير تنبيهات المخزن"
        footer={<Button variant="primary" className="w-full" onClick={() => setIsAlertsModalOpen(false)}>حسناً، فهمت</Button>}
      >
        <div className="space-y-3">
          {inventoryAlerts.map((alert, idx) => (
            <div key={idx} className={`p-4 rounded-2xl border flex items-center gap-4 ${
              alert.type === 'error' ? 'bg-red-50 border-red-100 text-red-700' : 'bg-amber-50 border-amber-100 text-amber-700'
            }`}>
              <span className="text-xl">{alert.type === 'error' ? '🚨' : '⚠️'}</span>
              <p className="text-sm font-black leading-relaxed">{alert.message}</p>
            </div>
          ))}
        </div>
      </Modal>
    </div>
  );
};

export default InventoryModule;
