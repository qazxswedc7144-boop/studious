
import React, { useState, useEffect, useRef } from 'react';
import { db } from '../services/database';
import { Branch, AccountingPeriod } from '../types';
import { useUI } from '../store/AppContext';
import { Card, Button, Badge, Input, Modal } from './SharedUI';
import { dataValidator } from '../services/validators/dataValidator';
import { AccountingPeriodRepository } from '../repositories/AccountingPeriodRepository';
import { periodService } from '../services/period.service';
import RoleGuard from './RoleGuard';

interface SettingsModuleProps {
  onNavigate?: (view: any) => void;
}

const SettingsModule: React.FC<SettingsModuleProps> = ({ onNavigate }) => {
  const [activeTab, setActiveTab] = useState<'backup' | 'branches' | 'general' | 'compliance' | 'import'>('backup');
  const [lastBackup, setLastBackup] = useState<string | null>(null);
  const [branches, setBranches] = useState<Branch[]>([]);
  const [online, setOnline] = useState(navigator.onLine);
  const [periods, setPeriods] = useState<AccountingPeriod[]>([]);
  const { refreshGlobal, addToast, currency } = useUI();
  const dataImportRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    setLastBackup(db.getLastBackupDate());
    setBranches(db.getBranches());
    setPeriods(periodService.getPeriods());

    const handleStatus = () => setOnline(navigator.onLine);
    window.addEventListener('online', handleStatus);
    window.addEventListener('offline', handleStatus);
    return () => {
      window.removeEventListener('online', handleStatus);
      window.removeEventListener('offline', handleStatus);
    };
  }, []);

  const handleBackupExport = (type: 'FULL' | 'ACCOUNTING' | 'INVENTORY') => {
    let rawData;
    let name;
    if (type === 'ACCOUNTING') { rawData = db.getAccountingState(); name = 'Accounting'; } 
    else if (type === 'INVENTORY') { rawData = db.getInventoryState(); name = 'Inventory'; } 
    else { rawData = db.getFullState(); name = 'FullERP'; }

    const cleanData = JSON.parse(JSON.stringify(rawData, (key, value) => {
      if (key.toLowerCase().includes('key') || key.toLowerCase().includes('secret')) return '***PROTECTED***';
      return value;
    }));

    const blob = new Blob([JSON.stringify(cleanData, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `PharmaFlow_${name}_${new Date().toISOString().split('T')[0]}.json`;
    a.click();
    db.createBackup();
    setLastBackup(db.getLastBackupDate());
    addToast(`تم تصدير النسخة الاحتياطية بنجاح ✅`, 'success');
  };

  const handleClosePeriod = async (periodId: string) => {
    if (confirm("هل أنت متأكد من رغبتك في إغلاق هذه الفترة المالية؟ سيتم منع أي تعديلات على السجلات ضمن هذا النطاق الزمني نهائياً.")) {
      try {
        await periodService.closePeriod(periodId, 'ADMIN');
        setPeriods(periodService.getPeriods());
        addToast("تم إغلاق الفترة المحاسبية بنجاح 🔒", "success");
        refreshGlobal();
      } catch (e: any) {
        addToast(e.message, "error");
      }
    }
  };

  const createNewPeriod = async () => {
    const startDate = prompt("تاريخ بداية الفترة (YYYY-MM-DD):", new Date().toISOString().split('T')[0]);
    const endDate = prompt("تاريخ نهاية الفترة (YYYY-MM-DD):");
    const name = prompt("اسم الفترة (مثلاً: الربع الأول 2025):");
    
    if (startDate && endDate && name) {
      const p: AccountingPeriod = {
        id: db.generateId('PRD'),
        name,
        startDate,
        endDate,
        isClosed: false
      };
      await AccountingPeriodRepository.createPeriod(p);
      setPeriods(periodService.getPeriods());
      addToast("تم إنشاء فترة مالية جديدة", "success");
    }
  };

  return (
    <div className="space-y-8 pb-32 text-right px-4 md:px-0" dir="rtl">
      <input type="file" accept=".json" ref={dataImportRef} className="hidden" />
      
      <div className="flex items-center justify-between bg-white p-6 rounded-[32px] border border-slate-100 shadow-sm">
        <div>
          <h2 className="text-3xl font-black text-[#1E4D4D]">الإعدادات والأمان</h2>
          <p className="text-slate-400 font-bold text-sm">إدارة صلاحيات الوصول وحماية البيانات</p>
        </div>
        <button onClick={() => onNavigate?.('dashboard')} className="w-12 h-12 bg-slate-50 border border-slate-100 rounded-2xl flex items-center justify-center text-[#1E4D4D] text-2xl font-black hover:bg-white transition-colors">➦</button>
      </div>

      <div className="flex p-1.5 bg-white border border-slate-100 rounded-[28px] shadow-sm w-fit overflow-x-auto no-scrollbar shrink-0">
        <button onClick={() => setActiveTab('backup')} className={`px-8 py-3.5 rounded-2xl text-xs font-black transition-all whitespace