// @google/genai Coding Guidelines followed: Standard UI/UX logic for pharmacy ERP.

import React, { useState, useMemo, useRef } from 'react';
import { useAccounting, useUI } from '../store/AppContext';
import { AccountingEntry } from '../types';
import { FixedSizeList as List } from 'react-window';
import { Card, Button, Input, Modal, Badge } from './SharedUI';
import { db } from '../services/database';

interface AccountingModuleProps {
  onNavigate?: (view: any) => void;
}

const AccountingModule: React.FC<AccountingModuleProps> = ({ onNavigate }) => {
  const { journalEntries, refreshAccounting } = useAccounting();
  const { currency, addToast } = useUI();
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedEntry, setSelectedEntry] = useState<AccountingEntry | null>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  const filteredEntries = useMemo(() => {
    if (!searchTerm.trim()) return journalEntries;
    const term = searchTerm.toLowerCase();
    return journalEntries.filter(e => 
      e.sourceType.toLowerCase().includes(term) ||
      e.sourceId.toLowerCase().includes(term) ||
      e.notes?.toLowerCase().includes(term) ||
      e.description?.toLowerCase().includes(term) ||
      e.lines.some(l => l.accountName.toLowerCase().includes(term))
    );
  }, [journalEntries, searchTerm]);

  const stats = useMemo(() => {
    return {
      totalVolume: journalEntries.reduce((acc, e) => acc + (e.lines.reduce((s, l) => s + l.debit, 0)), 0),
      entryCount: journalEntries.length
    };
  }, [journalEntries]);

  const handleCorrectEntry = () => {
    if (!selectedEntry) return;

    if (db.isDateLocked(selectedEntry.date)) {
       addToast("هذا القيد يقع ضمن فترة مالية مغلقة. لا يمكن إجراء تسوية عليه.", "error");
       return;
    }

    if (confirm("هل أنت متأكد من رغبتك في إنشاء قيد تسوية عكسي لهذا القيد؟ سيتم ترحيل القيد الجديد فوراً.")) {
      const reversalId = db.generateId('ACC');
      const reversal: AccountingEntry = {
        EntryID: reversalId,
        id: reversalId,
        date: new Date().toISOString(),
        description: `تسوية عكسية لـ: ${selectedEntry.description}`,
        TotalAmount: selectedEntry.TotalAmount,
        // Fix: Added totalAmount to satisfy the AccountingEntry interface requirement
        totalAmount: selectedEntry.totalAmount,
        Status: 'Posted',
        status: 'Posted',
        SourceID: `REV-${selectedEntry.sourceId || selectedEntry.SourceID}`,
        sourceId: `REV-${selectedEntry.sourceId || selectedEntry.SourceID}`,
        EntryType: "ADJUSTMENT",
        sourceType: "ADJUSTMENT",
        notes: `قيد تسوية عكسي للقيد الأصلي #${selectedEntry.id || selectedEntry.EntryID}`,
        branchId: db.getCurrentBranchId(),
        lines: selectedEntry.lines.map(line => ({
          ...line,
          lineId: db.generateId('DET'),
          debit: line.credit,
          credit: line.debit,
          type: line.type === 'DEBIT' ? 'CREDIT' : 'DEBIT'
        }))
      };

      db.addJournalEntry(reversal);
      addToast("تم ترحيل قيد التسوية العكسي بنجاح ✅", "success");
      refreshAccounting();
      setSelectedEntry(null);
    }
  };

  const getSourceBadge = (type: AccountingEntry['sourceType']) => {
    switch(type) {
      case 'SALE': return <Badge variant="success">مبيعات</Badge>;
      case 'PURCHASE': return <Badge variant="info">مشتريات</Badge>;
      case 'VOUCHER': return <Badge variant="warning">سند مالي</Badge>;
      case 'COGS': return <Badge variant="neutral">تكلفة مخزن</Badge>;
      default: return <Badge variant="neutral">{type}</Badge>;
    }
  };

  const getStatusBadge = (status: AccountingEntry['status']) => {
    return status === 'Posted' 
      ? <Badge variant="success">🔒 Posted</Badge> 
      : <Badge variant="neutral">📝 Draft</Badge>;
  };

  const Row = ({ index, style }: { index: number; style: React.CSSProperties }) => {
    const entry = filteredEntries[index];
    const isLocked = entry.status === 'Posted' || db.isDateLocked(entry.date);
    return (
      <div 
        style={style} 
        className={`flex border-b border-slate-50 hover:bg-slate-50/50 transition-colors items-center cursor-pointer touch-manipulation ${isLocked ? 'bg-slate-50/30' : ''}`}
        onClick={() => setSelectedEntry(entry)}
      >
        <div className="w-1/4 px-8 py-3">
          <div className="flex items-center gap-2">
             <p className="text-xs font-black text-[#1E4D4D]">{new Date(entry.date).toLocaleDateString('ar-SA')}</p>
             {isLocked && <span title="عملية مقفلة" className="text-[10px]">🔒</span>}
          </div>
          <p className="text-[9px] font-bold text-slate-300">REF: {entry.sourceId}</p>
          <div className="flex gap-1 mt-1">
            {getSourceBadge(entry.sourceType)}
          </div>
        </div>
        <div className="w-1/2 px-8 py-3">
          <div className="space-y-1">
            {entry.lines.slice(0, 2).map((line, idx) => (
              <div key={idx} className="flex items-center justify-between gap-4">
                <div className="flex items-center gap-2">
                  <span className={`w-8 text-[7px] font-black text-center py-0.5 rounded ${line.debit > 0 ? 'bg-red-50 text-red-500' : 'bg-emerald-50 text-emerald-600'}`}>
                    {line.debit > 0 ? 'مدين' : 'دائن'}
                  </span>
                  <span className="text-[10px] font-bold text-slate-700 truncate max-w-[150px]">{line.accountName}</span>
                </div>
                <span className={`text-[10px] font-black ${line.debit > 0 ? 'text-red-500' : 'text-emerald-600'}`}>
                  {(line.debit || line.credit).toLocaleString()}
                </span>
              </div>
            ))}
            {entry.lines.length > 2 && <p className="text-[8px] text-slate-300 font-bold mr-10">+ {entry.lines.length - 2} تفاصيل أخرى...</p>}
          </div>
        </div>
        <div className="w-1/4 px-8 py-3">
          <p className="text-xs font-black text-[#1E4D4D] truncate mb-1">{entry.description}</p>
          <div className="mt-1">{getStatusBadge(entry.status)}</div>
        </div>
      </div>
    );
  };

  return (
    <div className="space-y-8 pb-24 lg:pb-12 text-right font-['Cairo'] flex flex-col h-full overflow-hidden animate-in fade-in duration-500" dir="rtl">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 px-4 shrink-0 mt-4">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 bg-[#1E4D4D] text-white rounded-2xl flex items-center justify-center text-2xl shadow-lg">⚖️</div>
          <div>
            <h2 className="text-2xl font-black text-[#1E4D4D]">دفتر الأستاذ والعمليات</h2>
            <p className="text-slate-400 font-bold text-[10px] uppercase tracking-widest leading-none mt-1">نظام القيد المزدوج (Debit/Credit Protection)</p>
          </div>
        </div>
        <div className="relative w-full md:w-80 group">
          <input 
            className="w-full bg-white border border-slate-100 rounded-2xl px-12 py-4 text-xs font-black focus:outline-none focus:border-[#1E4D4D] shadow-sm transition-all focus:ring-4 focus:ring-[#1E4D4D]/5"
            placeholder="بحث في المراجع، الحسابات..."
            setSearchTerm={(e) => setSearchTerm(e.target.value)}
            value={searchTerm}
            onChange={e => setSearchTerm(e.target.value)}
          />
          <span className="absolute right-4 top-1/2 -translate-y-1/2 text-xl opacity-20 group-focus-within:opacity-100 transition-opacity">🔍</span>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 px-4 shrink-0">
        <Card className="flex items-center justify-between !p-5">
          <div>
            <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">إجمالي الحجم المالي (مدين)</p>
            <h3 className="text-2xl font-black text-[#1E4D4D]">{stats.totalVolume.toLocaleString()} <span className="text-xs opacity-30">{currency}</span></h3>
          </div>
          <div className="w-12 h-12 bg-emerald-50 text-emerald-600 rounded-2xl flex items-center justify-center text-xl shadow-inner">💹</div>
        </Card>
        <Card className="flex items-center justify-between !p-5">
          <div>
            <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">إجمالي العمليات المرحلة</p>
            <h3 className="text-2xl font-black text-blue-600">{journalEntries.filter(e => e.status === 'Posted').length} <span className="text-xs opacity-30">قيد</span></h3>
          </div>
          <div className="w-12 h-12 bg-blue-50 text-blue-600 rounded-2xl flex items-center justify-center text-xl shadow-inner">📑</div>
        </Card>
      </div>

      <div className="bg-white mx-4 rounded-[40px] shadow-sm border border-slate-100 overflow-hidden flex flex-col flex-1 min-h-0">
        <div className="bg-[#F8FAFA] text-[9px] font-black text-slate-400 uppercase tracking-widest border-b border-slate-100 flex shrink-0 py-1">
          <div className="w-1/4 px-8 py-4">التاريخ / المرجع</div>
          <div className="w-1/2 px-8 py-4">أبرز أسطر القيد (Double Entry)</div>
          <div className="w-1/4 px-8 py-4">البيان / الحالة</div>
        </div>
        
        <div className="flex-1 min-h-0" ref={containerRef}>
          {filteredEntries.length > 0 ? (
            <div className="h-full w-full">
               <List
                height={containerRef.current?.clientHeight || 500}
                itemCount={filteredEntries.length}
                itemSize={110}
                width="100%"
                className="custom-scrollbar"
              >
                {Row}
              </List>
            </div>
          ) : (
            <div className="h-full flex items-center justify-center text-slate-300 italic font-black py-20">لا توجد سجلات</div>
          )}
        </div>
      </div>

      <Modal 
        isOpen={!!selectedEntry} 
        onClose={() => setSelectedEntry(null)} 
        title="تفاصيل القيد المحاسبي"
        footer={
          <div className="flex w-full gap-3">
             {selectedEntry?.status === 'Posted' && (
               <Button variant="danger" className="flex-1 h-14" icon="🔄" onClick={handleCorrectEntry}>إجراء تسوية عكسية</Button>
             )}
             <Button variant="secondary" className="flex-1 h-14" onClick={() => setSelectedEntry(null)}>إغلاق</Button>
          </div>
        }
      >
        {selectedEntry && (
          <div className="space-y-6">
            <div className="bg-slate-50 p-6 rounded-[32px] border border-slate-100 flex justify-between items-center">
               <div>
                  <p className="text-[10px] font-black text-slate-400 uppercase">بيان العملية</p>
                  <p className="text-sm font-black text-[#1E4D4D] mt-1">{selectedEntry.description}</p>
                  <p className="text-[9px] text-slate-400 font-bold mt-1">المرجع: {selectedEntry.sourceId}</p>
               </div>
               <div className="text-left">
                  <p className="text-[10px] font-black text-slate-400 uppercase">الحالة</p>
                  <div className="mt-1">{getStatusBadge(selectedEntry.status)}</div>
               </div>
            </div>

            <div className="border border-slate-100 rounded-[32px] overflow-hidden shadow-sm">
               <table className="w-full text-right text-xs">
                  <thead className="bg-slate-50 text-[9px] font-black text-slate-400 uppercase border-b">
                     <tr>
                        <th className="px-5 py-4">اسم الحساب (Account Name)</th>
                        <th className="px-5 py-4 text-center">مدين (+) Debit</th>
                        <th className="px-5 py-4 text-center">دائن (-) Credit</th>
                     </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-50">
                     {selectedEntry.lines.map((line) => (
                       <tr key={line.lineId} className="hover:bg-slate-50 transition-colors">
                          <td className="px-5 py-4 font-bold text-slate-700">
                             {line.accountName}
                             <p className="text-[8px] text-slate-300 font-mono">ID: {line.lineId}</p>
                          </td>
                          <td className={`px-5 py-4 text-center font-black ${line.debit > 0 ? 'text-red-500 bg-red-50/30' : 'text-slate-200'}`}>
                             {line.debit > 0 ? line.debit.toLocaleString() : '0.00'}
                          </td>
                          <td className={`px-5 py-4 text-center font-black ${line.credit > 0 ? 'text-emerald-600 bg-emerald-50/30' : 'text-slate-200'}`}>
                             {line.credit > 0 ? line.credit.toLocaleString() : '0.00'}
                          </td>
                       </tr>
                     ))}
                  </tbody>
                  <tfoot className="bg-slate-100/50 font-black">
                     <tr>
                        <td className="px-5 py-4 text-[#1E4D4D]">المجموع الكلي</td>
                        <td className="px-5 py-4 text-center text-red-600">{selectedEntry.lines.reduce((s,l)=>s+l.debit,0).toLocaleString()}</td>
                        <td className="px-5 py-4 text-center text-emerald-700">{selectedEntry.lines.reduce((s,l)=>s+l.credit,0).toLocaleString()}</td>
                     </tr>
                  </tfoot>
               </table>
            </div>

            <div className="p-4 bg-blue-50 border border-blue-100 rounded-2xl flex items-center gap-3">
               <span className="text-xl">ℹ️</span>
               <p className="text-[10px] font-bold text-blue-800 leading-relaxed">
                  هذا القيد يتبع نظام القيد المزدوج الموحد. كافة العمليات المسجلة مربوطة بمرجع الفاتورة الأصلي لضمان سهولة التتبع في حالة التدقيق الخارجي.
               </p>
            </div>
          </div>
        )}
      </Modal>
    </div>
  );
};

export default AccountingModule;