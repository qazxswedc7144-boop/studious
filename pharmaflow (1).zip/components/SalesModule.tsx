
import React, { useState, useMemo, useEffect, useRef, useCallback } from 'react';
import { db } from '../services/database';
import { inventoryService } from '../services/inventory.service';
import { draftService } from '../services/draft.service';
import { Product, CartItem } from '../types';
import { useInventory, useAccounting, useUI } from '../store/AppContext';
import { Card, Button, Input, Modal, Badge } from './SharedUI';

const SalesModule: React.FC<{ onNavigate?: (view: any) => void }> = ({ onNavigate }) => {
  const { products } = useInventory();
  const { processSale } = useAccounting();
  const { currency, addToast } = useUI();
  const [tableSearch, setTableSearch] = useState('');
  const [isSaving, setIsSaving] = useState(false);
  const [isDraftLoading, setIsDraftLoading] = useState(true);
  
  const [header, setHeader] = useState({
    customerName: 'عميل نقدي',
    customerId: 'CASH',
    date: new Date().toISOString().split('T')[0],
    invNum: '', 
    discount: 0,
    paymentStatus: 'Cash' as 'Cash' | 'Credit',
    notes: '',
    isReturn: false
  });

  const [cart, setCart] = useState<CartItem[]>([]);
  const [isItemModalOpen, setIsItemModalOpen] = useState(false);
  const [newItem, setNewItem] = useState({ product_id: '', name: '', qty: 0, price: 0, stock: 0, note: '', expiry: '' });
  const [modalSearch, setModalSearch] = useState('');
  const [modalSuggestions, setModalSuggestions] = useState<Product[]>([]);

  useEffect(() => {
    const recoverDraft = async () => {
      const saved = await draftService.getDraft<{header: any, cart: CartItem[]}>('sales_active');
      if (saved) { setHeader(saved.header); setCart(saved.cart); addToast("تم استعادة مسودة البيع غير المكتملة 📑", "info"); }
      setIsDraftLoading(false);
    };
    recoverDraft();
  }, []);

  useEffect(() => {
    if (!isDraftLoading) {
      const timer = setTimeout(() => { draftService.saveDraft('sales_active', { header, cart }); }, 1000);
      return () => clearTimeout(timer);
    }
  }, [header, cart, isDraftLoading]);

  const financialSummary = useMemo(() => {
    const subtotal = cart.reduce((a, b) => a + b.sum, 0) - header.discount;
    return { subtotal, final: subtotal };
  }, [cart, header.discount]);

  const handleSaveInvoice = useCallback(async () => {
    if (cart.length === 0 || isSaving) return;
    setIsSaving(true);
    try {
      const finalInvNum = header.invNum || `${Date.now()}`;
      await processSale(header.customerId || header.customerName, cart.map(i => ({ product_id: i.product_id, qty: i.qty, price: i.price })), financialSummary.subtotal, { 
          isCash: header.paymentStatus === 'Cash', 
          customInvNum: finalInvNum,
          currency: currency
      });
      draftService.clearDraft('sales_active');
      setCart([]);
      addToast('تم ترحيل المبيعة بنجاح ✅', 'success');
      onNavigate?.('dashboard');
    } catch (e: any) { addToast(e.message, 'error'); } finally { setIsSaving(false); }
  }, [cart, header, currency, processSale, onNavigate, isSaving, addToast, financialSummary]);

  const selectProduct = (p: Product) => {
    setNewItem({ product_id: p.ProductID, name: p.Name, qty: 1, price: p.UnitPrice, stock: p.StockQuantity, expiry: p.ExpiryDate?.split('T')[0] || '', note: '' });
    setModalSearch(p.Name);
    setModalSuggestions([]);
  };

  const handleAddItem = () => {
    if (!newItem.product_id || newItem.qty <= 0) return;
    try { inventoryService.assertStockAvailability([{ product_id: newItem.product_id, qty: newItem.qty }]); } catch (error: any) { addToast(error.message, 'error'); return; }
    setCart(prev => [...prev, { id: db.generateId('CART'), product_id: newItem.product_id, name: newItem.name, qty: newItem.qty, price: newItem.price, sum: newItem.qty * newItem.price, note: newItem.note, expiry: newItem.expiry }]);
    setNewItem({ product_id: '', name: '', qty: 0, price: 0, stock: 0, note: '', expiry: '' });
    setModalSearch('');
    setIsItemModalOpen(false);
  };

  return (
    <div className="flex flex-col h-full bg-[#F0F7F7] font-['Cairo'] pb-40" dir="rtl">
      <div className="flex-1 overflow-y-auto px-4 py-4 space-y-4 custom-scrollbar">
        
        <div className="flex items-center justify-between mb-2">
           <div className="flex items-center gap-3">
             <div className="w-10 h-10 bg-white border border-slate-200 text-emerald-600 rounded-xl flex items-center justify-center shadow-sm"><span className="text-xl">💳</span></div>
             <div className="flex flex-col"><span className="text-[10px] font-black text-[#1E4D4D]">المبيعات</span><span className="text-[7px] text-slate-400 font-bold uppercase tracking-widest leading-none">Smart POS</span></div>
           </div>
           <div className="flex items-center gap-3">
              <div className="flex bg-white p-1 rounded-full border border-[#10B981] h-8 w-32 shadow-sm overflow-hidden">
                 <button onClick={() => setHeader({...header, paymentStatus: 'Cash'})} className={`flex-1 rounded-full text-[9px] font-black transition-all ${header.paymentStatus === 'Cash' ? 'bg-[#10B981] text-white shadow-md' : 'text-[#10B981]'}`}>نقداً</button>
                 <button onClick={() => setHeader({...header, paymentStatus: 'Credit'})} className={`flex-1 rounded-full text-[9px] font-black transition-all ${header.paymentStatus === 'Credit' ? 'bg-[#10B981] text-white shadow-md' : 'text-[#10B981]'}`}>آجل</button>
              </div>
           </div>
        </div>

        <div className="space-y-2">
          {/* الصف الأول: اسم العميل (2/3) والتاريخ (1/3) */}
          <div className="flex gap-2">
             <div className="w-2/3 relative">
                <div className="bg-white border border-slate-200 rounded-xl px-4 py-2 shadow-sm h-11 flex items-center">
                   <input placeholder="اسم العميل..." value={header.customerName} onChange={e => setHeader({...header, customerName: e.target.value})} className="w-full font-black text-[#1E4D4D] bg-transparent outline-none text-right placeholder-slate-300 text-sm" />
                </div>
             </div>
             <div className="w-1/3">
                <div className="bg-white border border-slate-200 rounded-xl px-2 py-2 h-11 flex items-center justify-between shadow-sm">
                   <input type="date" value={header.date} onChange={e => setHeader({...header, date: e.target.value})} className="w-full font-black text-[#1E4D4D] bg-transparent outline-none text-center text-[10px]" />
                </div>
             </div>
          </div>

          {/* الصف الثاني: رقم الفاتورة (1/2) والبيان (1/2) مع أيقونة الكاميرا */}
          <div className="flex gap-2">
             <div className="w-1/2">
                <div className="bg-white border border-slate-200 rounded-xl px-4 py-2 h-11 shadow-sm flex items-center">
                   <input 
                    type="number"
                    inputMode="numeric"
                    placeholder="رقم الفاتورة#" 
                    value={header.invNum} 
                    onChange={e => setHeader({...header, invNum: e.target.value})} 
                    className="w-full font-black bg-transparent outline-none text-right placeholder-slate-300 text-sm text-[#1E4D4D]" 
                   />
                </div>
             </div>
             <div className="w-1/2 flex items-center bg-white border border-slate-200 rounded-xl px-4 py-2 shadow-sm h-11 group">
                <input placeholder="البيان / ملاحظات..." value={header.notes} onChange={e => setHeader({...header, notes: e.target.value})} className="flex-1 font-black text-[#1E4D4D] bg-transparent outline-none text-right placeholder-slate-300 text-sm" />
                <span className="text-xl mr-2 opacity-30 hover:scale-110 cursor-pointer">📷</span>
             </div>
          </div>

          {/* الصف الثالث: حقل الخصم (اختياري للحفاظ على الوظائف) */}
          <div className="flex justify-end">
             <div className="w-1/4 bg-white border border-slate-200 rounded-xl px-2 py-2 shadow-sm h-11">
                <div className="flex items-center h-full">
                  <span className="text-[10px] font-black text-slate-400 ml-2">خصم:</span>
                  <input type="number" placeholder="0.00" value={header.discount || ''} onChange={e => setHeader({...header, discount: parseFloat(e.target.value) || 0})} className="w-full font-black text-red-500 bg-transparent outline-none text-left text-xs" />
                </div>
             </div>
          </div>
        </div>

        <Card noPadding className="flex flex-col min-h-[400px] !rounded-[24px] mt-4 shadow-xl border-slate-100">
           <div className="p-4 border-b border-slate-50 flex items-center justify-between bg-slate-50/20">
              <div className="flex-1 max-w-sm relative">
                <input placeholder="بحث في السلة..." value={tableSearch} onChange={e => setTableSearch(e.target.value)} className="w-full bg-white border border-slate-200 rounded-xl px-10 py-2.5 text-[11px] font-black shadow-sm" />
                <span className="absolute right-3 top-1/2 -translate-y-1/2 opacity-30 text-sm">🔍</span>
              </div>
              <Button variant="success" icon="＋" onClick={() => setIsItemModalOpen(true)} className="h-10 !rounded-[12px] !px-6 font-black text-[11px]">إضافة دواء</Button>
           </div>
           <div className="flex-1 overflow-x-auto custom-scrollbar">
              <table className="w-full text-right text-[11px]">
                 <thead className="bg-slate-100 text-slate-500 font-black border-b border-slate-200">
                    <tr><th className="px-6 py-4">الصنف</th><th className="px-6 py-4 text-center">الكمية</th><th className="px-6 py-4 text-center">السعر</th><th className="px-6 py-4 text-left">الإجمالي</th></tr>
                 </thead>
                 <tbody className="divide-y divide-slate-100">
                    {cart.filter(i => i.name.toLowerCase().includes(tableSearch.toLowerCase())).map(item => (
                      <tr key={item.id} className="hover:bg-slate-50 group transition-all">
                        <td className="px-6 py-4 flex items-center gap-3">
                           <button onClick={() => setCart(prev => prev.filter(i => i.id !== item.id))} className="w-8 h-8 rounded-lg bg-red-50 text-red-400 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-all shadow-sm hover:bg-red-500 hover:text-white">✕</button>
                           <span className="font-black text-[#1E4D4D] text-sm">{item.name}</span>
                        </td>
                        <td className="px-6 py-4 text-center font-bold text-slate-700">{item.qty}</td>
                        <td className="px-6 py-4 text-center font-bold text-slate-700">{item.price.toLocaleString()}</td>
                        <td className="px-6 py-4 text-left font-black text-[#10B981] text-sm">{item.sum.toLocaleString()}</td>
                      </tr>
                    ))}
                 </tbody>
              </table>
           </div>
        </Card>
      </div>

      <div className="fixed bottom-0 left-0 right-0 p-4 bg-white/95 backdrop-blur-xl border-t border-slate-100 shadow-[0_-10px_25px_rgba(0,0,0,0.05)] z-[100]">
        <div className="max-w-7xl mx-auto flex items-center justify-between gap-4">
           <div className="flex flex-col">
              <p className="text-[8px] font-black text-slate-400 uppercase tracking-widest">إجمالي المبيعات</p>
              <h3 className="text-2xl font-black text-[#1E4D4D] leading-none">{financialSummary.final.toLocaleString()} <span className="text-xs opacity-30 font-black mr-2 uppercase">{currency}</span></h3>
           </div>
           <Button onClick={handleSaveInvoice} disabled={cart.length === 0 || isSaving} variant="success" className="h-14 px-12 !rounded-[20px] text-base bg-[#10B981]" isLoading={isSaving} icon="✅">تأكيد المبيعة</Button>
        </div>
      </div>

      <Modal isOpen={isItemModalOpen} onClose={() => setIsItemModalOpen(false)} title="إضافة صنف" footer={<Button variant="success" onClick={handleAddItem} className="w-full h-14 !rounded-[16px] font-black text-base" icon="✅">إضافة للسلة</Button>}>
        <div className="space-y-4">
           <Input label="بحث سريع" value={modalSearch} onChange={e => { setModalSearch(e.target.value); if (e.target.value.length > 1) setModalSuggestions(products.filter(p => p.Name.toLowerCase().includes(e.target.value.toLowerCase()))); else setModalSuggestions([]); }} />
           {modalSuggestions.length > 0 && (
              <div className="bg-white border border-slate-200 rounded-[16px] shadow-2xl max-h-48 overflow-y-auto">
                 {modalSuggestions.map(p => (
                   <button key={p.ProductID} onClick={() => selectProduct(p)} className="w-full text-right px-6 py-4 hover:bg-emerald-50 border-b last:border-0 font-black text-[11px] flex justify-between transition-all"><span>{p.Name}</span><span className="text-[9px] opacity-40">رصيد: {p.StockQuantity}</span></button>
                 ))}
              </div>
           )}
           <div className="grid grid-cols-2 gap-4"><Input label="الكمية" type="number" value={newItem.qty || ''} onChange={e => setNewItem({...newItem, qty: parseInt(e.target.value) || 0})} /><Input label="السعر" type="number" value={newItem.price || ''} onChange={e => setNewItem({...newItem, price: parseFloat(e.target.value) || 0})} /></div>
        </div>
      </Modal>
    </div>
  );
};

export default SalesModule;
