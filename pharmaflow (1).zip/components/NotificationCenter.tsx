
import React from 'react';
import { AppNotification } from '../types';
import { Card, Badge } from './SharedUI';

interface NotificationCenterProps {
  notifications: AppNotification[];
  onMarkRead: (id: string) => void;
  onClearAll: () => void;
}

const NotificationCenter: React.FC<NotificationCenterProps> = ({ notifications, onMarkRead, onClearAll }) => {
  const unreadCount = notifications.filter(n => !n.isRead).length;

  return (
    <div className="flex flex-col h-full bg-white font-['Cairo']" dir="rtl">
      <div className="p-6 border-b border-slate-100 flex justify-between items-center bg-slate-50/50">
        <div>
           <h2 className="text-lg font-black text-[#1E4D4D]">مركز التنبيهات</h2>
           <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest">Active System Alerts</p>
        </div>
        {unreadCount > 0 && (
          <Badge variant="danger">{unreadCount} تنبيه جديد</Badge>
        )}
      </div>

      <div className="flex-1 overflow-y-auto p-4 space-y-3 custom-scrollbar">
        {notifications.length === 0 ? (
          <div className="h-full flex flex-col items-center justify-center text-center p-10 opacity-20">
             <span className="text-6xl mb-4">🔔</span>
             <p className="font-black text-slate-500">لا توجد تنبيهات حالياً</p>
          </div>
        ) : (
          notifications.map(n => (
            <div 
              key={n.id} 
              onClick={() => onMarkRead(n.id)}
              className={`p-4 rounded-3xl border transition-all cursor-pointer group ${
                n.isRead ? 'bg-white border-slate-50 opacity-60' : 'bg-emerald-50/30 border-emerald-100 shadow-sm'
              }`}
            >
              <div className="flex gap-4">
                 <div className={`w-12 h-12 rounded-2xl flex items-center justify-center text-xl shrink-0 ${
                   n.type === 'EXPIRY' ? 'bg-red-100 text-red-600' :
                   n.type === 'STOCK' ? 'bg-amber-100 text-amber-600' : 'bg-blue-100 text-blue-600'
                 }`}>
                   {n.type === 'EXPIRY' ? '⌛' : n.type === 'STOCK' ? '📦' : '🛡️'}
                 </div>
                 <div className="min-w-0 flex-1">
                    <div className="flex justify-between items-start mb-1">
                       <h4 className={`text-xs font-black truncate ${n.isRead ? 'text-slate-500' : 'text-[#1E4D4D]'}`}>{n.title}</h4>
                       <span className="text-[8px] font-bold text-slate-300 whitespace-nowrap mr-2">{new Date(n.date).toLocaleTimeString('ar-SA')}</span>
                    </div>
                    <p className="text-[11px] text-slate-500 font-bold leading-relaxed">{n.message}</p>
                 </div>
              </div>
            </div>
          ))
        )}
      </div>

      {notifications.length > 0 && (
        <div className="p-4 border-t border-slate-50 bg-slate-50/30">
           <button onClick={onClearAll} className="w-full py-3 text-[10px] font-black text-slate-400 hover:text-red-500 transition-colors">مسح كافة التنبيهات</button>
        </div>
      )}
    </div>
  );
};

export default NotificationCenter;
