
import React, { useState, useMemo } from 'react';
import { getSmartChatResponse } from '../services/geminiService';
import { accountingService } from '../services/accounting.service';

interface GeminiToolsProps {
  lang?: 'ar';
}

const GeminiTools: React.FC<GeminiToolsProps> = () => {
  const [chatInput, setChatInput] = useState('');
  const [messages, setMessages] = useState<{ role: 'u' | 'ai', content: string }[]>([]);
  const [loading, setLoading] = useState(false);

  // تحضير الملخص المحاسبي اللغوي للذكاء الاصطناعي
  const accountingSummary = useMemo(() => {
    const metrics = accountingService.getFinancialMetrics();
    const insights = accountingService.getInventoryInsights();
    const topItems = accountingService.getTopProfitableItems(3);

    return `
    خلاصة أداء الصيدلية المحاسبية:
    - إجمالي الإيرادات: ${metrics.income} د.إ
    - هامش الربح الحالي: ${metrics.margin.toFixed(2)}%
    - صافي الربح التقديري: ${metrics.net} د.إ
    - حالة المخزون: يوجد ${insights.criticalStock.length} أصناف وصلت لحد النواقص.
    - أصناف قريبة الانتهاء: ${insights.expiringSoon.length} أصناف.
    // Fix: Used i.Name instead of i.name to match Product interface definition in types.ts
    - أكثر الأصناف ربحية: ${topItems.map(i => i.Name).join(', ')}.
    `;
  }, []);

  const handleSend = async () => {
    if (!chatInput.trim()) return;
    const input = chatInput;
    setMessages(prev => [...prev, { role: 'u', content: input }]);
    setChatInput('');
    setLoading(true);

    const systemInstruction = `
    أنت مستشار ERP مالي متخصص في الصيدليات. 
    مهمتك هي تفسير النتائج المحاسبية المقدمة لك لغوياً وبشكل استراتيجي.
    لا تحلل البيانات الخام، بل اقرأ الملخص المحاسبي الجاهز وقدم النصيحة بناءً عليه.
    تحدث بلغة واثقة، مهنية، وموجهة لمدير الصيدلية.
    `;

    try {
      const prompt = `
      ${systemInstruction}
      السياق المحاسبي الحالي:
      ${accountingSummary}
      
      سؤال المستخدم: ${input}
      `;

      const res = await getSmartChatResponse(prompt, [], { thinking: true });
      setMessages(prev => [...prev, { role: 'ai', content: res.text || "" }]);
    } catch (e) {
      setMessages(prev => [...prev, { role: 'ai', content: "عذراً، واجهت مشكلة في الاتصال بمحرك الذكاء الاصطناعي." }]);
    } finally { setLoading(false); }
  };

  return (
    <div className="flex flex-col h-full bg-white border-r border-slate-200" dir="rtl">
      <div className="p-6 border-b border-slate-100 text-right">
        <div className="flex items-center gap-2 mb-1">
          <span className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse"></span>
          <h2 className="text-xs font-black uppercase tracking-widest text-emerald-600">
            مفسر البيانات المالي (AI)
          </h2>
        </div>
        <p className="text-[10px] text-slate-400 font-bold">يترجم الأرقام المحاسبية إلى نصائح استراتيجية</p>
      </div>

      <div className="flex-1 overflow-y-auto p-6 space-y-4 custom-scrollbar">
        {messages.length === 0 && (
          <div className="text-center py-12 space-y-4">
            <div className="text-4xl">💡</div>
            <p className="text-slate-400 italic text-sm px-4">
              أنا مطلع على أداء صيدليتك المالي حالياً. اسألني عن تفسير الأرباح أو كيف تحسن وضع المخزون.
            </p>
          </div>
        )}
        {messages.map((m, i) => (
          <div key={i} className={`flex ${m.role === 'u' ? 'justify-start' : 'justify-end'}`}>
            <div className={`max-w-[85%] p-4 rounded-3xl text-sm shadow-sm font-bold leading-relaxed ${
              m.role === 'u' ? 'bg-emerald-600 text-white rounded-bl-none' : 'bg-slate-50 border border-slate-100 text-slate-700 rounded-br-none'
            }`}>
              {m.content}
            </div>
          </div>
        ))}
        {loading && (
          <div className="flex items-center gap-2 text-emerald-500 text-[10px] font-black animate-pulse">
            <span>⚡</span> جاري تحليل الملخص المالي...
          </div>
        )}
      </div>

      <div className="p-4 border-t border-slate-100 bg-slate-50/50">
        <div className="flex gap-2 bg-white p-2 rounded-2xl border border-slate-200 shadow-inner">
          <input 
            value={chatInput} 
            onChange={e => setChatInput(e.target.value)} 
            onKeyDown={e => e.key === 'Enter' && handleSend()}
            placeholder="اسأل المستشار المالي..." 
            className="flex-1 bg-transparent px-3 text-sm font-bold focus:outline-none text-right"
          />
          <button onClick={handleSend} disabled={loading} className="w-10 h-10 bg-emerald-600 text-white rounded-xl shadow-lg flex items-center justify-center hover:scale-105 active:scale-95 transition-all">🚀</button>
        </div>
      </div>
    </div>
  );
};

export default GeminiTools;
