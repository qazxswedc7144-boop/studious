
import React, { useState, useEffect, useCallback } from 'react';
import { db } from '../services/database';
import { Transaction } from '../types';
import { generateAIInvoice } from '../services/geminiService';
import { useInvoice, useUI } from '../store/AppContext';
import { Button, Card, Badge, Input } from './SharedUI';

interface InvoiceModuleProps {
  lang: 'en' | 'ar';
  onNavigate?: (view: any) => void;
}

const InvoiceModule: React.FC<InvoiceModuleProps> = ({ lang, onNavigate }) => {
  const isAr = lang === 'ar';
  const { generatedHtml, setGeneratedHtml, isGenerating, setIsGenerating, lastUsedStyle, setLastUsedStyle } = useInvoice();
  const { currency, addToast } = useUI();
  const [recentSales, setRecentSales] = useState<Transaction[]>([]);
  const [selectedSale, setSelectedSale] = useState<Transaction | null>(null);
  const [customerName, setCustomerName] = useState('');

  useEffect(() => {
    const txs = db.getTransactions().filter(t => t.type === 'sale').sort((a,b) => new Date(b.date).getTime() - new Date(a.date).getTime());
    setRecentSales(txs);
  }, []);

  const sanitizeHtml = (html: string): string => {
    if (!html) return "";
    return html
      .replace(/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi, "")
      .replace(/\bon\w+="[^"]*"/g, "")
      .replace(/\bon\w+='[^']*'/g, "");
  };

  const handleGenerate = async () => {
    if (!selectedSale && !customerName) {
      addToast(isAr ? "يرجى اختيار مبيعة أو إدخال اسم عميل" : "Please select a sale or enter customer name", "warning");
      return;
    }

    setIsGenerating(true);
    addToast(isAr ? "جاري تصميم الفاتورة بالذكاء الاصطناعي..." : "Generating AI design...", "info");
    try {
      const data = {
        invoiceId: selectedSale?.id || `INV-${Date.now()}`,
        date: selectedSale?.date || new Date().toISOString(),
        customer: customerName || (selectedSale?.customer) || (isAr ? "عميل نقدي" : "Cash Customer"),
        items: selectedSale?.items || [],
        total: selectedSale?.amount || 0,
        currency
      };

      const html = await generateAIInvoice(data, lastUsedStyle);
      setGeneratedHtml(sanitizeHtml(html || ""));
      addToast(isAr ? "تم توليد الفاتورة بنجاح ✅" : "Invoice generated successfully ✅", "success");
    } catch (error) {
      console.error(error);
      addToast(isAr ? "خطأ في توليد الفاتورة" : "Error generating invoice", "error");
    } finally {
      setIsGenerating(false);
    }
  };

  const handlePrint = useCallback(() => {
    if (!generatedHtml) return;
    
    const printWindow = window.open('', '_blank');
    if (printWindow) {
      printWindow.document.write(`
        <!DOCTYPE html>
        <html lang="${isAr ? 'ar' : 'en'}" dir="${isAr ? 'rtl' : 'ltr'}">
          <head>
            <title>Invoice - PharmaFlow</title>
            <meta charset="UTF-8">
            <script src="https://cdn.tailwindcss.com"></script>
            <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;700;900&display=swap" rel="stylesheet">
            <style>
              body { font-family: 'Cairo', sans-serif; padding: 0; margin: 0; background: white; }
              @media print {
                .no-print { display: none; }
                body { padding: 0; margin: 0; }
                @page { margin: 1cm; }
              }
            </style>
          </head>
          <body>
            <div id="invoice-content">
              ${generatedHtml}
            </div>
            <script>
              // انتظر حتى يتم تحميل Tailwind والخطوط
              window.onload = () => {
                setTimeout(() => {
                  window.print();
                  // window.close(); // اختياري: غلق النافذة بعد الطباعة
                }, 500);
              };
            </script>
          </body>
        </html>
      `);
      printWindow.document.close();
    }
  }, [generatedHtml, isAr]);

  const handleClear = () => {
    setGeneratedHtml(null);
    setSelectedSale(null);
    setCustomerName('');
  };

  return (
    <div className="p-4 md:p-8 space-y-8 bg-[#F8FAFA] min-h-full pb-32" dir={isAr ? 'rtl' : 'ltr'}>
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <div className="w-14 h-14 bg-white text-[#1E4D4D] border border-slate-100 rounded-2xl flex items-center justify-center text-3xl shadow-sm">📄</div>
          <div>
            <h2 className="text-2xl md:text-3xl font-black text-[#1E4D4D]">{isAr ? 'مصمم الفواتير الذكي' : 'AI Invoice Designer'}</h2>
            <p className="text-slate-400 text-sm font-bold">{isAr ? 'توليد فواتير احترافية مدعومة بـ Gemini' : 'Professional invoices powered by Gemini'}</p>
          </div>
        </div>
        <button onClick={() => onNavigate?.('dashboard')} className="bg-white border border-slate-200 text-[#1E4D4D] px-6 py-3 rounded-2xl text-xs font-black flex items-center gap-2 hover:bg-slate-50 transition-all shadow-sm">🏠 {isAr ? 'الرئيسية' : 'Home'}</button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Settings Panel */}
        <div className="lg:col-span-4 space-y-6">
          <Card className="shadow-xl border-slate-100 p-8 space-y-8">
            <div className="space-y-4">
              <div className="flex items-center gap-2 border-b border-slate-50 pb-4">
                <span className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse"></span>
                <h3 className="text-xs font-black uppercase tracking-widest text-slate-400">{isAr ? 'إعدادات الفاتورة' : 'Invoice Settings'}</h3>
              </div>

              <div className="space-y-2">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest mr-1">{isAr ? 'مبيعة سابقة' : 'Select Previous Sale'}</label>
                <select 
                  className="w-full bg-slate-50 border-2 border-slate-100 rounded-2xl px-4 py-4 font-black text-[#1E4D4D] text-xs outline-none focus:border-[#1E4D4D] transition-all appearance-none"
                  value={selectedSale?.id || ''}
                  onChange={(e) => setSelectedSale(recentSales.find(s => s.id === e.target.value) || null)}
                >
                  <option value="">{isAr ? '--- اختر من المبيعات الأخيرة ---' : '--- Recent Sales ---'}</option>
                  {recentSales.map(s => (
                    <option key={s.id} value={s.id}>{new Date(s.date).toLocaleDateString('ar-SA')} - {s.amount} {currency} (#{s.id})</option>
                  ))}
                </select>
              </div>

              <div className="space-y-2">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest mr-1">{isAr ? 'اسم العميل (تعديل)' : 'Customer Name'}</label>
                <Input 
                  placeholder={isAr ? 'أدخل اسم العميل يدوياً...' : 'Type customer name...'} 
                  value={customerName} 
                  onChange={(e) => setCustomerName(e.target.value)} 
                  icon="👤"
                />
              </div>

              <div className="space-y-2">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest mr-1">{isAr ? 'نمط التصميم الذكي' : 'AI Template Style'}</label>
                <select 
                  className="w-full bg-slate-50 border-2 border-slate-100 rounded-2xl px-4 py-4 font-black text-[#1E4D4D] text-xs outline-none focus:border-[#1E4D4D] transition-all appearance-none"
                  value={lastUsedStyle} 
                  onChange={(e) => setLastUsedStyle(e.target.value)}
                >
                  <option value="Modern Medical Green">{isAr ? 'طبي عصري (أخضر)' : 'Modern Medical Green'}</option>
                  <option value="Minimalist Clean Black">{isAr ? 'بسيط وأنيق (أسود)' : 'Minimalist Clean Black'}</option>
                  <option value="Luxury Corporate Blue">{isAr ? 'مؤسسي فاخر (أزرق)' : 'Luxury Corporate Blue'}</option>
                </select>
              </div>
            </div>

            <div className="pt-4 space-y-3">
              <Button 
                onClick={handleGenerate} 
                disabled={isGenerating || (!selectedSale && !customerName)} 
                variant="primary" 
                className="w-full h-16 rounded-[24px] text-base shadow-2xl" 
                isLoading={isGenerating}
                icon="✨"
              >
                {isAr ? 'توليد التصميم الذكي' : 'Generate AI Design'}
              </Button>
              {generatedHtml && (
                <Button onClick={handleClear} variant="ghost" className="w-full text-xs font-black text-slate-400">{isAr ? 'إعادة ضبط' : 'Clear View'}</Button>
              )}
            </div>
          </Card>

          <div className="p-6 bg-[#1E4D4D] rounded-[32px] text-white space-y-3 relative overflow-hidden">
             <span className="text-3xl block mb-2">💡</span>
             <h4 className="text-sm font-black">{isAr ? 'نصيحة تقنية' : 'Pro Tip'}</h4>
             <p className="text-[10px] font-bold opacity-70 leading-relaxed">
               {isAr 
                 ? 'يقوم Gemini بتصميم الفاتورة بناءً على هوية الصيدلية. يمكنك طباعة الفاتورة أو حفظها كـ PDF مباشرة من المتصفح.' 
                 : 'Gemini designs the invoice based on pharmacy identity. You can print or save as PDF directly from the browser.'}
             </p>
             <div className="absolute -right-4 -bottom-4 w-20 h-20 bg-white opacity-5 rounded-full"></div>
          </div>
        </div>

        {/* Preview Panel */}
        <div className="lg:col-span-8">
          <div className={`bg-white rounded-[40px] border-2 border-slate-100 min-h-[700px] flex flex-col overflow-hidden transition-all shadow-xl ${!generatedHtml ? 'border-dashed' : 'border-solid'}`}>
            {generatedHtml ? (
              <div className="flex flex-col h-full animate-in fade-in duration-700">
                <div className="px-8 py-5 border-b border-slate-100 flex justify-between items-center bg-white sticky top-0 z-10 shadow-sm">
                  <div className="flex items-center gap-3">
                    <Badge variant="success">{isAr ? 'التصميم جاهز' : 'Design Ready'}</Badge>
                    <span className="text-[10px] font-black text-slate-300 uppercase tracking-tighter">AI-GEN-002</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <Button onClick={handlePrint} variant="secondary" size="sm" icon="🖨️">
                      {isAr ? 'طباعة مباشرة' : 'Print Directly'}
                    </Button>
                    <Button onClick={handlePrint} variant="success" size="sm" icon="📥">
                      {isAr ? 'حفظ كـ PDF' : 'Save as PDF'}
                    </Button>
                  </div>
                </div>
                <div className="flex-1 p-10 overflow-auto bg-slate-50/30 custom-scrollbar">
                  <div className="bg-white shadow-2xl rounded-2xl mx-auto max-w-[800px] min-h-[1000px] transform origin-top transition-transform">
                    <div className="p-0" dangerouslySetInnerHTML={{ __html: generatedHtml }} />
                  </div>
                </div>
              </div>
            ) : (
              <div className="flex-1 flex flex-col items-center justify-center text-slate-300 italic p-16 text-center space-y-6">
                <div className="w-24 h-24 bg-slate-50 rounded-[32px] flex items-center justify-center text-6xl shadow-inner animate-bounce duration-[3000ms]">📄</div>
                <div className="space-y-2">
                  <h3 className="text-xl font-black text-slate-400 uppercase tracking-widest">{isAr ? 'معاينة الفاتورة' : 'Invoice Preview'}</h3>
                  <p className="max-w-xs text-xs font-bold leading-relaxed opacity-60">
                    {isAr 
                      ? 'اختر مبيعة من القائمة الجانبية واضغط على زر التوليد لتصميم فاتورة احترافية باستخدام الذكاء الاصطناعي.' 
                      : 'Select a sale from the sidebar and click generate to design a professional AI invoice.'}
                  </p>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default InvoiceModule;
