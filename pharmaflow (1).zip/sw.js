
const CACHE_NAME = 'pharmaflow-v3-atomic';
const OFFLINE_URL = '/index.html';

const ASSETS = [
  '/',
  '/index.html',
  'https://cdn.tailwindcss.com',
  'https://fonts.googleapis.com/css2?family=Cairo:wght@300;400;600;700;900&display=swap',
  'https://esm.sh/dexie@^3.2.4',
  'https://esm.sh/zustand@^5.0.0'
];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => cache.addAll(ASSETS))
  );
  self.skipWaiting();
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((keys) => Promise.all(
      keys.map((key) => {
        if (key !== CACHE_NAME) return caches.delete(key);
      })
    ))
  );
});

self.addEventListener('fetch', (event) => {
  // استراتيجية Stale-While-Revalidate لضمان السرعة وتحديث البيانات
  event.respondWith(
    caches.match(event.request).then((cachedResponse) => {
      const fetchPromise = fetch(event.request).then((networkResponse) => {
        if (event.request.method === 'GET' && networkResponse.ok) {
          caches.open(CACHE_NAME).then((cache) => {
            cache.put(event.request, networkResponse.clone());
          });
        }
        return networkResponse;
      }).catch(() => cachedResponse);
      return cachedResponse || fetchPromise;
    })
  );
});

/**
 * معالج المزامنة في الخلفية (Background Sync API)
 * يشتعل هذا الحدث عندما يستعيد المتصفح الاتصال بالإنترنت
 */
self.addEventListener('sync', (event) => {
  if (event.tag === 'pharma-sync-task') {
    event.waitUntil(processBackgroundSync());
  }
});

/**
 * وظيفة معالجة المزامنة في الخلفية
 */
async function processBackgroundSync() {
  console.log('[SW] Background Sync Started...');
  
  // إشعار المستخدم ببدء المزامنة
  if (self.registration.showNotification) {
    await self.registration.showNotification("PharmaFlow", {
      body: "جاري ترحيل عملياتك المعلقة للسيرفر... 🔄",
      icon: "https://cdn-icons-png.flaticon.com/512/3063/3063176.png",
      tag: 'sync-status',
      silent: true
    });
  }

  // ملاحظة: المزامنة الفعلية تتم عبر تطبيق الـ Client الرئيسي عادةً
  // ولكن هنا نرسل إشارة لكافة الـ Windows النشطة لتبدأ الـ sync logic
  const clients = await self.clients.matchAll();
  clients.forEach(client => {
    client.postMessage({ type: 'TRIGGER_SYNC' });
  });

  return Promise.resolve();
}

/**
 * معالجة الضغط على الإشعارات
 */
self.addEventListener('notificationclick', (event) => {
  event.notification.close();
  event.waitUntil(
    self.clients.matchAll({ type: 'window' }).then(clientList => {
      if (clientList.length > 0) return clientList[0].focus();
      return self.clients.openWindow('/');
    })
  );
});
