
import React, { useState, useEffect, Suspense, lazy, useRef, useCallback, useTransition, useMemo } from 'react';
import Dashboard from './components/Dashboard';
import ErrorBoundary from './components/ErrorBoundary';
import { useUI, AppProvider, useInventory } from './store/AppContext';
import { db } from './services/database';
import { authService } from './services/auth.service';
import { syncService } from './services/sync.service';
import { notificationService } from './services/notification.service';
import Logo from './components/Logo';
import { Branch, User, Permission, AppNotification } from './types';
import { Toast, Button, Card, Input } from './components/SharedUI';
import RoleGuard from './components/RoleGuard';
import NotificationCenter from './components/NotificationCenter';

// Lazy loading components
const PurchasesModule = lazy(() => import('./components/PurchasesModule'));
const SalesModule = lazy(() => import('./components/SalesModule'));
const ExpensesModule = lazy(() => import('./components/ExpensesModule'));
const InventoryModule = lazy(() => import('./components/InventoryModule'));
const ReportsModule = lazy(() => import('./components/ReportsModule'));
const SupplierManagement = lazy(() => import('./components/SupplierManagement'));
const InventoryAuditModule = lazy(() => import('./components/InventoryAuditModule')); 
const GeminiTools = lazy(() => import('./components/GeminiTools'));
const VouchersModule = lazy(() => import('./components/VouchersModule'));
const AuditLogModule = lazy(() => import('./components/AuditLogModule'));
const SettingsModule = lazy(() => import('./components/SettingsModule'));
const AccountingModule = lazy(() => import('./components/AccountingModule'));
const AccountManagement = lazy(() => import('./components/AccountManagement'));
const IntegrationsModule = lazy(() => import('./components/IntegrationsModule'));
const HelpModule = lazy(() => import('./components/HelpModule'));
const AIAuditModule = lazy(() => import('./components/AIAuditModule'));
const ReconciliationModule = lazy(() => import('./components/ReconciliationModule'));
const SystemHealthModule = lazy(() => import('./components/SystemHealthModule'));
const InvoiceModule = lazy(() => import('./components/InvoiceModule'));

type View = 'dashboard' | 'sales' | 'purchases' | 'vouchers' | 'partners' | 'inventory' | 'reports' | 'expenses' | 'audit' | 'logs' | 'settings' | 'accounting' | 'account-management' | 'integrations' | 'help' | 'about' | 'support' | 'ai-audit' | 'reconciliation' | 'system-health' | 'invoices';

interface ModuleConfig {
  id: View;
  label: string;
  icon: string;
  group: 'core' | 'finance' | 'admin' | 'info';
  mobile?: boolean;
  permission?: Permission;
}

const MODULES: ModuleConfig[] = [
  { id: 'dashboard', label: 'الرئيسية', icon: '🏠', group: 'core', mobile: true },
  { id: 'sales', label: 'المبيعات', icon: '💳', group: 'core', mobile: true, permission: 'PERFORM_SALE' },
  { id: 'purchases', label: 'المشتريات', icon: '🛒', group: 'core', permission: 'MANAGE_PURCHASE' },
  { id: 'invoices', label: 'الفواتير الذكية', icon: '📄', group: 'core', permission: 'PERFORM_SALE' },
  { id: 'inventory', label: 'المخزن', icon: '📦', group: 'core', mobile: true, permission: 'MANAGE_INVENTORY' },
  { id: 'ai-audit', label: 'التدقيق الذكي', icon: '🤖', group: 'finance', mobile: true, permission: 'AUDIT_ACCESS' },
  { id: 'reconciliation', label: 'المطابقة المالية', icon: '⚖️', group: 'finance', permission: 'VIEW_FINANCE' },
  { id: 'vouchers', label: 'السندات', icon: '🧾', group: 'finance', permission: 'VIEW_FINANCE' },
  { id: 'system-health', label: 'صحة النظام', icon: '🛡️', group: 'admin', permission: 'SYSTEM_SETTINGS' },
  { id: 'audit', label: 'الجرد اليومي', icon: '🔍', group: 'core', permission: 'MANAGE_INVENTORY' },
  { id: 'partners', label: 'الشركاء', icon: '🤝', group: 'core', permission: 'MANAGE_PURCHASE' },
  { id: 'accounting', label: 'دفتر الأستاذ', icon: '📖', group: 'finance', permission: 'VIEW_FINANCE' },
  { id: 'reports', label: 'التقارير', icon: '📊', group: 'finance', permission: 'VIEW_FINANCE' },
  { id: 'help', label: 'الدليل التقني', icon: '📘', group: 'info' },
  { id: 'settings', label: 'الإعدادات', icon: '⚙️', group: 'admin', mobile: true, permission: 'SYSTEM_SETTINGS' },
];

const LoginPage = ({ onLogin }: { onLogin: (u: User) => void }) => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState(''); 
  const [loading, setLoading] = useState(false);

  const handleLogin = async (role: any) => {
    setLoading(true);
    const user = await authService.login(username || 'user', role);
    onLogin(user);
    setLoading(false);
  };

  return (
    <div className="min-h-screen bg-[#F0F7F7] flex items-center justify-center p-6 text-right" dir="rtl">
       <Card className="max-w-md w-full p-10 space-y-8 animate-in zoom-in duration-500 shadow-2xl">
          <div className="text-center space-y-4">
             <div className="flex justify-center"><Logo size={80} /></div>
             <h2 className="text-3xl font-black text-[#1E4D4D]">PharmaFlow Secure</h2>
             <p className="text-slate-400 font-bold text-xs uppercase tracking-widest leading-none">نظام إدارة الصيدلية الذكي</p>
          </div>
          
          <div className="space-y-4">
             <Input label="اسم المستخدم" placeholder="أدخل اسمك..." value={username} onChange={e => setUsername(e.target.value)} icon="👤" />
             <Input label="كلمة المرور" type="password" placeholder="••••••••" value={password} onChange={e => setPassword(e.target.value)} icon="🔒" />
          </div>

          <div className="space-y-3">
             <p className="text-[10px] font-black text-slate-400 text-center uppercase mb-2">اختر الصلاحية للدخول (محاكاة التجربة)</p>
             <div className="grid grid-cols-1 gap-3">
                <Button variant="primary" isLoading={loading} className="h-14 rounded-2xl" onClick={() => handleLogin('ADMIN')}>دخول كمدير (كامل الصلاحيات) 👑</Button>
                <Button variant="secondary" isLoading={loading} className="h-14 rounded-2xl" onClick={() => handleLogin('PHARMACIST')}>دخول كصيدلاني (مخزون ومبيعات) 💊</Button>
                <Button variant="ghost" isLoading={loading} className="h-14 rounded-2xl border border-slate-100" onClick={() => handleLogin('CASHIER')}>دخول ككاشير (مبيعات فقط) 💳</Button>
             </div>
          </div>

          <div className="pt-4 border-t border-slate-50 flex items-center justify-center gap-2">
             <span className="w-1.5 h-1.5 rounded-full bg-emerald-500"></span>
             <p className="text-[9px] font-black text-slate-300 uppercase tracking-widest">Enterprise Encrypted Environment</p>
          </div>
       </Card>
    </div>
  );
};

const NavItem = React.memo(({ active, icon, label, onClick, restricted }: { active: boolean, icon: string, label: string, onClick: () => void, restricted?: boolean }) => (
  <button 
    onClick={onClick} 
    className={`w-full flex items-center justify-between gap-4 px-6 py-4 rounded-2xl text-[13px] font-black transition-all duration-200 active:scale-95 touch-manipulation ${
      active ? 'bg-[#E5F3F3] text-[#1E4D4D] shadow-sm' : 'text-slate-400 hover:bg-slate-50 hover:text-[#1E4D4D]'
    }`}
  >
    <div className="flex items-center gap-4">
      <span className="text-xl">{icon}</span>
      <span>{label}</span>
    </div>
    {restricted && <span className="text-[10px] opacity-40">🔒</span>}
  </button>
));

const MobileTab = React.memo(({ active, icon, label, onClick }: { active: boolean, icon: string, label: string, onClick: () => void }) => (
  <button 
    onClick={onClick}
    className={`flex-1 flex flex-col items-center justify-center gap-1 py-2 transition-all active:scale-90 touch-manipulation ${active ? 'text-[#10B981]' : 'text-slate-400'}`}
  >
    <span className="text-xl">{icon}</span>
    <span className="text-[8px] font-black uppercase tracking-tighter">{label}</span>
  </button>
));

function MainLayout() {
  const [user, setUser] = useState<User | null>(authService.getCurrentUser());
  const [currentView, setCurrentView] = useState<View>('dashboard');
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [isAiOpen, setIsAiOpen] = useState(false);
  const [isNotifOpen, setIsNotifOpen] = useState(false);
  const [online, setOnline] = useState(navigator.onLine);
  const [syncing, setSyncing] = useState(false);
  const [pendingOps, setPendingOps] = useState(0);
  const [branches, setBranches] = useState<Branch[]>([]);
  const [currentBranchId, setCurrentBranchId] = useState(db.getCurrentBranchId());
  const [notifications, setNotifications] = useState<AppNotification[]>([]);
  
  const [isPending, startTransition] = useTransition();
  const { headerAction, setHeaderAction, refreshGlobal, version, toasts, removeToast, addToast } = useUI();
  const { products } = useInventory();
  
  // نظام التنبيهات الذكي والمستمر
  useEffect(() => {
    if (products.length > 0) {
      const alerts = notificationService.checkInventoryAlerts(products);
      const newNotifs: AppNotification[] = alerts.map(alert => ({
        id: db.generateId('NT'),
        title: alert.type === 'error' ? 'تحذير حرج' : 'تنبيه تشغيلي',
        message: alert.message,
        type: alert.message.includes('مخزون') ? 'STOCK' : 'EXPIRY',
        severity: alert.type === 'error' ? 'high' : 'medium',
        date: new Date().toISOString(),
        isRead: false
      }));
      
      setNotifications(prev => {
        const unique = [...newNotifs, ...prev].filter((v, i, a) => a.findIndex(t => t.message === v.message) === i);
        return unique.slice(0, 50);
      });
    }
  }, [version, products]);

  useEffect(() => {
    document.documentElement.lang = 'ar';
    document.documentElement.dir = 'rtl';
    setBranches(db.getBranches());
    setPendingOps(syncService.getPendingCount());

    const handleOnline = async () => {
      setOnline(true);
      addToast("تمت استعادة الاتصال. جاري المزامنة...", "info");
      setSyncing(true);
      await syncService.performSync();
      setSyncing(false);
      setPendingOps(syncService.getPendingCount());
      refreshGlobal();
    };

    const handleOffline = () => {
      setOnline(false);
      addToast("أنت أوفلاين. سيتم الحفظ محلياً.", "warning");
    };

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);
    
    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, [refreshGlobal, addToast]);

  const handleNav = useCallback((view: View) => {
    const module = MODULES.find(m => m.id === view);
    if (module?.permission && !authService.hasPermission(module.permission)) {
       addToast("غير مصرح لك بالوصول لهذا القسم", "error");
       return;
    }

    startTransition(() => {
      setCurrentView(view);
    });
    setIsSidebarOpen(false); 
    setHeaderAction(null); 
    window.scrollTo({ top: 0, behavior: 'auto' });
  }, [setHeaderAction, addToast]);

  const unreadCount = useMemo(() => notifications.filter(n => !n.isRead).length, [notifications]);

  if (!user) return <LoginPage onLogin={setUser} />;

  const currentBranch = branches.find(b => b.id === currentBranchId) || branches[0];
  const groups = { core: 'العمليات الأساسية', finance: 'المالية والتقارير', admin: 'الإدارة', info: 'المساعدة' };

  return (
    <div className="flex h-screen bg-[#F8FAFA] overflow-hidden font-['Cairo'] select-none relative" dir="rtl">
      {isPending && <div className="fixed top-0 left-0 right-0 h-1.5 bg-[#10B981] z-[1000] animate-pulse"></div>}
      
      <div className="pointer-events-none fixed inset-x-0 bottom-24 sm:bottom-0 z-[1000] flex flex-col items-center">
        {toasts.map(t => <div key={t.id} className="pointer-events-auto"><Toast message={t.message} type={t.type as any} onClose={() => removeToast(t.id)} /></div>)}
      </div>

      {/* Side Panels */}
      {(isSidebarOpen || isAiOpen || isNotifOpen) && <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-[2px] z-[60] animate-in fade-in duration-300" onClick={() => { setIsSidebarOpen(false); setIsAiOpen(false); setIsNotifOpen(false); }} />}

      <aside className={`fixed inset-y-0 right-0 w-72 bg-white border-l border-slate-100 z-[70] transition-all duration-300 transform lg:relative lg:translate-x-0 lg:z-10 ${isSidebarOpen ? 'translate-x-0 shadow-2xl' : 'translate-x-full'}`}>
        <div className="flex flex-col h-full">
          <div className="px-6 py-8 border-b border-slate-50 flex justify-between items-center">
             <Logo showText size={42} />
             <button onClick={() => setIsSidebarOpen(false)} className="lg:hidden w-10 h-10 flex items-center justify-center text-slate-300 hover:text-red-500 transition-colors">✕</button>
          </div>
          <nav className="flex-1 px-3 py-4 space-y-6 overflow-y-auto custom-scrollbar">
            {(Object.keys(groups) as Array<keyof typeof groups>).map(groupKey => {
              const groupModules = MODULES.filter(m => m.group === groupKey);
              if (groupModules.length === 0) return null;
              return (
                <div key={groupKey} className="space-y-1">
                  <p className="px-4 text-[9px] font-black text-slate-300 uppercase tracking-[2px] mb-2">{groups[groupKey]}</p>
                  {groupModules.map(module => (
                    <RoleGuard key={module.id} permission={module.permission} hideOnFailure>
                       <NavItem active={currentView === module.id} icon={module.icon} label={module.label} onClick={() => handleNav(module.id)} />
                    </RoleGuard>
                  ))}
                </div>
              );
            })}
          </nav>
          <div className="p-6 border-t border-slate-50 space-y-3">
            <button onClick={() => authService.logout()} className="w-full py-3 rounded-xl font-black text-[10px] text-red-400 hover:bg-red-50 transition-all flex items-center justify-center gap-2">🚪 تسجيل الخروج</button>
          </div>
        </div>
      </aside>

      <div className="flex-1 flex flex-col min-w-0 overflow-hidden relative">
        <header className="h-16 sm:h-20 bg-white/80 backdrop-blur-md border-b border-slate-100 flex items-center px-4 sm:px-8 shrink-0 z-50 relative">
          <div className="flex-1 flex items-center gap-3">
            <button onClick={() => setIsSidebarOpen(true)} className="lg:hidden w-12 h-12 bg-slate-50 border border-slate-200 rounded-2xl flex items-center justify-center text-xl shadow-sm active:scale-90 touch-manipulation">☰</button>
            <button onClick={() => setIsNotifOpen(true)} className="relative w-12 h-12 bg-white border border-slate-100 rounded-2xl flex items-center justify-center text-xl shadow-sm hover:bg-slate-50 transition-all active:scale-90 touch-manipulation">
               🔔
               {unreadCount > 0 && <span className="absolute top-2 right-2 w-4 h-4 bg-red-500 text-white text-[8px] font-black rounded-full flex items-center justify-center border-2 border-white">{unreadCount}</span>}
            </button>
          </div>

          <div className="flex-1 flex justify-center gap-3">
            {headerAction && !isPending && (
              <button onClick={headerAction.onClick} className="w-12 h-12 rounded-full bg-[#1E4D4D] text-white shadow-lg flex items-center justify-center animate-in zoom-in">{headerAction.icon}</button>
            )}
          </div>

          <div className="flex-1 flex items-center justify-end gap-3 sm:gap-4">
             <button onClick={() => setIsAiOpen(true)} className="px-5 py-2.5 rounded-2xl bg-emerald-600 text-white text-[10px] font-black shadow-lg shadow-emerald-100 flex items-center gap-2 hover:bg-emerald-700 transition-all active:scale-95">
                <span className="animate-pulse">✨</span> المساعد
             </button>
             <div className="w-10 sm:w-11 shrink-0"><Logo size={36} /></div>
          </div>
        </header>

        <main className="flex-1 overflow-y-auto custom-scrollbar bg-[#F8FAFA] pb-24 lg:pb-0 scroll-smooth">
          <div className="view-animate max-w-7xl mx-auto h-full px-1 sm:px-0">
            <Suspense fallback={<div className="flex flex-col items-center justify-center h-full"><div className="w-8 h-8 border-2 border-[#1E4D4D] border-t-transparent rounded-full animate-spin"></div></div>}>
              {(() => {
                switch (currentView) {
                  case 'sales': return <SalesModule onNavigate={handleNav} />;
                  case 'purchases': return <PurchasesModule onNavigate={handleNav} />;
                  case 'vouchers': return <VouchersModule onNavigate={handleNav} />;
                  case 'inventory': return <InventoryModule onNavigate={handleNav} />;
                  case 'partners': return <SupplierManagement lang="ar" onNavigate={handleNav} />;
                  case 'expenses': return <ExpensesModule lang="ar" onNavigate={handleNav} />;
                  case 'reports': return <ReportsModule lang="ar" onNavigate={handleNav} />;
                  case 'audit': return <InventoryAuditModule lang="ar" onNavigate={handleNav} />;
                  case 'logs': return <AuditLogModule onNavigate={handleNav} />;
                  case 'settings': return <SettingsModule onNavigate={handleNav} />;
                  case 'accounting': return <AccountingModule onNavigate={handleNav} />;
                  case 'account-management': return <AccountManagement onNavigate={handleNav} />;
                  case 'integrations': return <IntegrationsModule onNavigate={handleNav} />;
                  case 'help': return <HelpModule onNavigate={handleNav} />;
                  case 'ai-audit': return <AIAuditModule onNavigate={handleNav} />;
                  case 'reconciliation': return <ReconciliationModule onNavigate={handleNav} />;
                  case 'system-health': return <SystemHealthModule onNavigate={handleNav} />;
                  case 'invoices': return <InvoiceModule lang="ar" onNavigate={handleNav} />;
                  default: return <Dashboard lang="ar" onNavigate={handleNav} />;
                }
              })()}
            </Suspense>
          </div>
        </main>
        
        <nav className="lg:hidden fixed bottom-0 left-0 right-0 bg-white/95 backdrop-blur-md border-t border-slate-100 h-20 flex items-center px-4 z-[50] shadow-[0_-10px_25px_rgba(0,0,0,0.05)]">
           {MODULES.filter(m => m.mobile).map(module => (
              <MobileTab key={module.id} active={currentView === module.id} icon={module.icon} label={module.label} onClick={() => handleNav(module.id)} />
           ))}
        </nav>
      </div>

      {/* AI Panel */}
      {isAiOpen && (
        <div className="fixed inset-y-0 left-0 w-full sm:w-96 bg-white z-[100] shadow-2xl animate-in slide-in-from-left duration-500 flex flex-col">
           <GeminiTools lang="ar" />
           <button onClick={() => setIsAiOpen(false)} className="absolute top-4 right-4 w-10 h-10 bg-slate-50 rounded-full flex items-center justify-center font-black text-slate-400">✕</button>
        </div>
      )}

      {/* Notifications Panel */}
      {isNotifOpen && (
        <div className="fixed inset-y-0 right-0 w-full sm:w-96 bg-white z-[100] shadow-2xl animate-in slide-in-from-right duration-500 flex flex-col border-l border-slate-100">
           <NotificationCenter 
             notifications={notifications} 
             onMarkRead={(id) => setNotifications(prev => prev.map(n => n.id === id ? {...n, isRead: true} : n))}
             onClearAll={() => setNotifications([])}
           />
           <button onClick={() => setIsNotifOpen(false)} className="absolute top-4 left-4 w-10 h-10 bg-slate-50 rounded-full flex items-center justify-center font-black text-slate-400">✕</button>
        </div>
      )}
    </div>
  );
}

export default function App() { return ( <ErrorBoundary> <AppProvider> <MainLayout /> </AppProvider> </ErrorBoundary> ); }
