
import { JournalLine } from "../types";

// Update: Align with the professional line-based accounting system used in types.ts
export type AccountingEntry = {
  id: string;
  date: string;
  lines: JournalLine[];
  sourceId: string;
  sourceType: "PURCHASE" | "SALE" | "EXPENSE" | "OpeningBalance" | "Payment" | "Receipt" | "COGS";
  notes?: string;
};
