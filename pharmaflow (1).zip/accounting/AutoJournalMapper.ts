import { AccountingEntry, JournalLine, EntryStatus } from '../types';
import { db } from '../services/database';
import { JournalRulesProvider } from './JournalRules';
import { ChartOfAccounts } from './ChartOfAccounts';

/**
 * AutoJournalMapper - النسخة الديناميكية (v2)
 */
export const AutoJournalMapper = {
  
  /**
   * إنشاء سطر محاسبي بناءً على ID الحساب والمبلغ
   */
  // Fix: Removed private modifier as it is not allowed in object literal properties
  createLine(entryId: string, accId: string, amount: number, type: 'DEBIT' | 'CREDIT'): JournalLine {
    const account = ChartOfAccounts.getAccountById(accId);
    const accName = account ? account.name : "حساب غير معرف";
    
    return {
      lineId: db.generateId('DET'),
      entryId,
      accountId: accId,
      accountName: accName,
      debit: type === 'DEBIT' ? amount : 0,
      credit: type === 'CREDIT' ? amount : 0,
      type,
      amount
    };
  },

  /**
   * دالة عامة لتوليد القيد بناءً على مفتاح القاعدة (Rule Key)
   */
  // Fix: Removed private modifier as it is not allowed in object literal properties
  generateEntryFromRule(
    ruleKey: string, 
    amount: number, 
    sourceId: string, 
    sourceType: any, 
    date: string,
    customDescription?: string
  ): AccountingEntry {
    const rule = JournalRulesProvider.getRule(ruleKey);
    const entryId = db.generateId('ENT');
    
    return {
      EntryID: entryId,
      id: entryId,
      SourceID: sourceId,
      sourceId: sourceId,
      EntryType: sourceType,
      sourceType: sourceType,
      TotalAmount: amount,
      // Fix: Added totalAmount to satisfy the AccountingEntry interface requirement
      totalAmount: amount,
      Status: 'Posted',
      status: 'Posted',
      date,
      description: customDescription || `${rule.description} #${sourceId}`,
      branchId: db.getCurrentBranchId(),
      lines: [
        this.createLine(entryId, rule.debit, amount, 'DEBIT'),
        this.createLine(entryId, rule.credit, amount, 'CREDIT')
      ]
    };
  },

  /**
   * رسم خرائط المبيعات (Sale Mapping)
   */
  mapSaleToEntries(saleData: { 
    id: string; 
    total: number; 
    cost: number; 
    paymentStatus: 'Cash' | 'Credit';
    tax?: number;
    discount?: number;
    isReturn?: boolean;
  }): AccountingEntry[] {
    const entries: AccountingEntry[] = [];
    const date = new Date().toISOString();
    
    // 1. قيد المبيعات الأساسي (أو المرتجع)
    const ruleBase = saleData.isReturn ? 'SALE_RETURN' : (saleData.paymentStatus === 'Cash' ? 'SALE_CASH' : 'SALE_CREDIT');
    entries.push(this.generateEntryFromRule(ruleBase, saleData.total, saleData.id, 'SALE', date));

    // 2. قيد التكلفة (COGS) - يتم عكسه في حالة المرتجع آلياً إذا لزم الأمر
    if (saleData.cost > 0) {
      const cogsRule = JournalRulesProvider.getRule('COGS');
      // في المرتجع: مدين (المخزون)، دائن (التكلفة) - عكس القاعدة الأصلية
      const debitAcc = saleData.isReturn ? cogsRule.credit : cogsRule.debit;
      const creditAcc = saleData.isReturn ? cogsRule.debit : cogsRule.credit;
      
      const cogsId = db.generateId('ENT');
      entries.push({
        EntryID: cogsId, id: cogsId, SourceID: saleData.id, sourceId: saleData.id,
        EntryType: "COGS", sourceType: "COGS", TotalAmount: saleData.cost,
        // Fix: Added totalAmount to satisfy the AccountingEntry interface requirement
        totalAmount: saleData.cost,
        Status: 'Posted', status: 'Posted', date, branchId: db.getCurrentBranchId(),
        description: `إثبات تكلفة ${saleData.isReturn ? 'مرتجع' : ''} #${saleData.id}`,
        lines: [
          this.createLine(cogsId, debitAcc, saleData.cost, 'DEBIT'),
          this.createLine(cogsId, creditAcc, saleData.cost, 'CREDIT')
        ]
      });
    }

    // 3. قيد الضريبة (إذا وجد)
    if (saleData.tax && saleData.tax > 0) {
      entries.push(this.generateEntryFromRule('TAX_VAT', saleData.tax, saleData.id, 'SALE', date));
    }

    // 4. قيد الخصم (إذا وجد)
    if (saleData.discount && saleData.discount > 0) {
      entries.push(this.generateEntryFromRule('DISCOUNT_ALLOWED', saleData.discount, saleData.id, 'SALE', date));
    }

    return entries;
  },

  /**
   * رسم خرائط المشتريات (Purchase Mapping)
   */
  mapPurchaseToEntries(purData: { 
    id: string; 
    total: number; 
    isCash: boolean;
    isReturn?: boolean;
  }): AccountingEntry[] {
    const date = new Date().toISOString();
    const ruleKey = purData.isReturn ? 'PURCHASE_RETURN' : (purData.isCash ? 'PURCHASE_CASH' : 'PURCHASE_CREDIT');
    return [this.generateEntryFromRule(ruleKey, purData.total, purData.id, 'PURCHASE', date)];
  },

  /**
   * رسم خرائط السندات (Vouchers)
   */
  mapVoucherToEntries(vData: { id: string, type: 'دخل' | 'خرج', amount: number, name: string, category: string, notes: string }): AccountingEntry {
    const isIncome = vData.type === 'دخل';
    // استخدام توجيه ديناميكي بناءً على الفئة إذا لزم الأمر، هنا نستخدم الافتراضي
    const debitAcc = isIncome ? 'ACC-101' : 'ACC-502'; 
    const creditAcc = isIncome ? 'ACC-401' : 'ACC-101'; 
    
    const entryId = db.generateId('ENT');
    return {
      EntryID: entryId, id: entryId, SourceID: vData.id, sourceId: vData.id,
      EntryType: "VOUCHER", sourceType: "VOUCHER", TotalAmount: vData.amount,
      // Fix: Added totalAmount to satisfy the AccountingEntry interface requirement
      totalAmount: vData.amount,
      Status: 'Posted', status: 'Posted', date: new Date().toISOString(),
      description: `سند ${vData.type} #${vData.id} - ${vData.name}`,
      branchId: db.getCurrentBranchId(),
      lines: [
        this.createLine(entryId, debitAcc, vData.amount, 'DEBIT'),
        this.createLine(entryId, creditAcc, vData.amount, 'CREDIT')
      ]
    };
  }
};

export const createSaleJournal = (d: any) => AutoJournalMapper.mapSaleToEntries(d);
export const createPurchaseJournal = (d: any) => AutoJournalMapper.mapPurchaseToEntries(d);
export const createVoucherJournal = (d: any) => AutoJournalMapper.mapVoucherToEntries(d);