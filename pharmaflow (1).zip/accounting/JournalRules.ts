import { journalRules } from '../config/journalRules.ts';

export interface JournalRule {
  debit: string;
  credit: string;
  description: string;
}

/**
 * محرك استرجاع القواعد الديناميكي
 */
export const JournalRulesProvider = {
  getRule(key: string): JournalRule {
    const rules = (journalRules as any).rules;
    if (rules && rules[key]) {
      return rules[key];
    }
    
    // Fallback في حالة عدم وجود القاعدة في الملف
    console.warn(`[JournalRules] Rule key "${key}" not found in config. Using fallback.`);
    return {
      debit: 'ACC-SUSPENSE',
      credit: 'ACC-SUSPENSE',
      description: 'قيد معلق - قاعدة غير معرفة'
    };
  },

  getAllRules(): Record<string, JournalRule> {
    return (journalRules as any).rules;
  }
};

// الحفاظ على التوافق مع الكود القديم عبر التصدير الثابت
export const JOURNAL_RULES = JournalRulesProvider.getAllRules();