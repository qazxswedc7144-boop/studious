// Fix: Added React import to resolve React namespace errors
import React from 'react';

/**
 * تم استبدال هذا الملف بـ useAppStore.ts (Zustand)
 * الملف موجود حالياً فقط لتجنب أخطاء الاستيراد أثناء المرحلة الانتقالية
 * سيتم حذفه في الإصدار القادم.
 */
export const AppStoreProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => <>{children}</>;
export const useStore = () => { throw new Error("يرجى استخدام useAppStore بدلاً من useStore"); };
export const useUI = () => { throw new Error("يرجى استيراد useUI من AppContext أو useAppStore"); };