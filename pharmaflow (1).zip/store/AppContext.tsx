
import React, { useEffect, useCallback, useRef } from 'react';
import { useAppStore } from './useAppStore';
import { eventBus, EVENTS } from '../services/eventBus';

/**
 * AppProvider - الجسر المركزي
 */
export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const refreshData = useAppStore(s => s.refreshData);
  
  useEffect(() => {
    refreshData();
  }, [refreshData]);

  return <>{children}</>;
};

/**
 * useEventBus - Hook آمن ومحسن لمنع تسرب الذاكرة
 * يستخدم الآن نمط الـ Unsubscribe الوظيفي الجديد
 */
export const useEventBus = (event: string, callback: (data: any) => void) => {
  const callbackRef = useRef(callback);
  useEffect(() => { callbackRef.current = callback; }, [callback]);
  
  useEffect(() => {
    // الاشتراك والحصول على دالة التنظيف مباشرة
    const unsubscribe = eventBus.subscribe(event, (data) => { 
      callbackRef.current(data); 
    });
    
    // تنفيذ التنظيف عند الـ Unmount أو تغير الـ Event
    return () => unsubscribe();
  }, [event]);
};

/**
 * واجهة التحكم في واجهة المستخدم (UI Facade)
 */
export const useUI = () => {
  const currency = useAppStore(s => s.currency);
  const version = useAppStore(s => s.version);
  const toasts = useAppStore(s => s.toasts);
  const isSyncing = useAppStore(s => s.isSyncing);
  const headerAction = useAppStore(s => s.headerAction);
  
  const setCurrency = useAppStore(s => s.setCurrency);
  const addToast = useAppStore(s => s.addToast);
  const removeToast = useAppStore(s => s.removeToast);
  const setHeaderAction = useAppStore(s => s.setHeaderAction);
  const refreshGlobal = useAppStore(s => s.refreshData);
  const setSyncing = useAppStore(s => s.setSyncing);

  return {
    currency,
    setCurrency,
    version,
    toasts,
    addToast,
    removeToast,
    headerAction,
    setHeaderAction,
    refreshGlobal,
    isSyncing,
    setSyncing
  };
};

/**
 * واجهة التحكم في المخزون (Inventory Facade)
 */
export const useInventory = () => {
  const products = useAppStore(s => s.products);
  const updateStock = useAppStore(s => s.updateInventory);
  const refreshInventory = useAppStore(s => s.refreshData);
  
  return { 
    products, 
    updateStock,
    refreshInventory 
  };
};

/**
 * واجهة المحاسبة والعمليات المالية (Accounting Facade)
 */
export const useAccounting = () => {
  const products = useAppStore(s => s.products);
  const sales = useAppStore(s => s.sales);
  const purchases = useAppStore(s => s.purchases);
  const journalEntries = useAppStore(s => s.journalEntries);
  const suppliers = useAppStore(s => s.suppliers);
  const customers = useAppStore(s => s.customers);
  const addInvoice = useAppStore(s => s.addInvoice);
  const addCustomer = useAppStore(s => s.addCustomer);
  const addSupplier = useAppStore(s => s.addSupplier);
  const refreshData = useAppStore(s => s.refreshData);
  
  const processSale = useCallback(async (customerId: string, cart: any[], total: number, options: any) => {
    const res = await addInvoice({
      type: 'SALE',
      payload: { customerId, cart, total },
      options: {
        paymentStatus: options.isCash ? 'Cash' : 'Credit',
        customInvNum: options.customInvNum,
        currency: options.currency,
        isReturn: options.isReturn || false
      }
    });
    if (res.success) {
      eventBus.emit(EVENTS.SALE_COMPLETED, { id: customerId });
    } else {
      throw new Error(res.error);
    }
  }, [addInvoice]);

  const processPurchase = useCallback(async (supplierId: string, items: any[], total: number, invoiceId?: string, isCash: boolean = false, isReturn: boolean = false) => {
    const res = await addInvoice({
      type: 'PURCHASE',
      payload: { supplierId, items, total, invoiceId },
      options: { isCash, isReturn }
    });
    if (res.success) {
      eventBus.emit(EVENTS.PURCHASE_COMPLETED, { id: invoiceId });
    } else {
      throw new Error(res.error);
    }
  }, [addInvoice]);

  return { 
    products,
    sales,
    purchases,
    journalEntries,
    suppliers,
    customers,
    processSale, 
    processPurchase, 
    addCustomer,
    addSupplier,
    refreshAccounting: refreshData 
  };
};

/**
 * واجهة نظام الفواتير
 */
export const useInvoice = () => {
  const [generatedHtml, setGeneratedHtml] = React.useState<string | null>(null);
  const [isGenerating, setIsGenerating] = React.useState(false);
  const [lastUsedStyle, setLastUsedStyle] = React.useState('Modern Medical Green');

  return {
    generatedHtml, setGeneratedHtml,
    isGenerating, setIsGenerating,
    lastUsedStyle, setLastUsedStyle
  };
};
