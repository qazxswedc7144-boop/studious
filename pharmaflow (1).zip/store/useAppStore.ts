
import { create } from 'zustand';
import { subscribeWithSelector } from 'zustand/middleware';
import { ProductRepository } from '../repositories/ProductRepository';
import { PurchaseRepository } from '../repositories/PurchaseRepository';
import { AccountingRepository } from '../repositories/AccountingRepository';
import { SupplierRepository } from '../repositories/SupplierRepository';
import { SalesRepository } from '../repositories/SalesRepository';
import { transactionOrchestrator } from '../services/transactionOrchestrator';
import { 
  Product, Sale, Purchase, CashFlow, AccountingEntry, 
  Supplier, User, ToastMessage, Account 
} from '../types';

interface AppState {
  // Data State
  version: number;
  currency: string;
  user: User | null;
  products: Product[];
  sales: Sale[];
  purchases: Purchase[];
  cashFlow: CashFlow[];
  journalEntries: AccountingEntry[];
  suppliers: Supplier[];
  customers: Supplier[];
  accounts: Account[];
  
  // UI State
  toasts: ToastMessage[];
  isSyncing: boolean;
  headerAction: any | null;

  // core refresh
  refreshData: () => void;

  // Required Actions (Task 4)
  addInvoice: (invoice: { type: 'SALE' | 'PURCHASE', payload: any, options?: any }) => Promise<{ success: boolean, error?: string }>;
  updateInventory: (productId: string, delta: number) => Promise<void>;
  addCustomer: (customer: Supplier) => Promise<void>;
  addSupplier: (supplier: Supplier) => Promise<void>;

  // UI Actions
  setUser: (user: User | null) => void;
  setCurrency: (currency: string) => void;
  setSyncing: (status: boolean) => void;
  setHeaderAction: (action: any | null) => void;
  addToast: (message: string, type?: 'success' | 'error' | 'info') => void;
  removeToast: (id: string) => void;
}

export const useAppStore = create<AppState>()(
  subscribeWithSelector((set, get) => ({
    version: 0,
    currency: localStorage.getItem('pharma_currency') || 'AED',
    user: JSON.parse(sessionStorage.getItem('pharmaflow_session_secure') || 'null'),
    products: [],
    sales: [],
    purchases: [],
    cashFlow: [],
    journalEntries: [],
    suppliers: [],
    customers: [],
    accounts: [],
    toasts: [],
    isSyncing: false,
    headerAction: null,

    /**
     * تحديث شامل لكافة البيانات من المستودعات (Repositories)
     */
    refreshData: () => {
      set((state) => ({
        products: ProductRepository.getAll(),
        sales: SalesRepository.getAll(),
        purchases: PurchaseRepository.getAll(),
        journalEntries: AccountingRepository.getEntries(),
        cashFlow: AccountingRepository.getCashFlow(),
        suppliers: SupplierRepository.getSuppliers(),
        customers: SupplierRepository.getCustomers(),
        accounts: AccountingRepository.getEntries().length > 0 ? AccountingRepository.getEntries()[0].branchId ? [] : [] : [], // Placeholder for accounts logic if needed
        // سنقوم بجلب الحسابات مباشرة من قاعدة البيانات
        version: state.version + 1
      }));
    },

    /**
     * تنفيذ فاتورة (بيع أو شراء) بشكل ذري
     */
    addInvoice: async (invoice) => {
      const result = await transactionOrchestrator.processInvoiceTransaction(invoice);
      if (result.success) {
        get().refreshData();
        get().addToast(`تم ترحيل فاتورة ${invoice.type === 'SALE' ? 'المبيعات' : 'المشتريات'} بنجاح ✅`, 'success');
      }
      return result;
    },

    /**
     * تحديث أرصدة المخزون يدوياً (تسويات أو هالك)
     */
    updateInventory: async (productId, delta) => {
      await ProductRepository.updateStock(productId, delta);
      get().refreshData();
      get().addToast("تم تحديث أرصدة المخزون بنجاح 📦", "success");
    },

    /**
     * إضافة عميل جديد
     */
    addCustomer: async (customer) => {
      await SupplierRepository.save(customer, 'C');
      get().refreshData();
      get().addToast(`تم تسجيل العميل ${customer.name} بنجاح`, "success");
    },

    /**
     * إضافة مورد جديد
     */
    addSupplier: async (supplier) => {
      await SupplierRepository.save(supplier, 'S');
      get().refreshData();
      get().addToast(`تم تسجيل المورد ${supplier.name} بنجاح`, "success");
    },

    // UI & Auth Helpers
    setUser: (user) => set({ user }),
    setCurrency: (currency) => {
      localStorage.setItem('pharma_currency', currency);
      set({ currency });
    },
    setSyncing: (isSyncing) => set({ isSyncing }),
    setHeaderAction: (headerAction) => set({ headerAction }),
    addToast: (message, type = 'info') => {
      const id = Math.random().toString(36).substr(2, 9);
      set((state) => ({ toasts: [...state.toasts, { id, message, type }] }));
      setTimeout(() => get().removeToast(id), 4000);
    },
    removeToast: (id) => set((state) => ({ toasts: state.toasts.filter(t => t.id !== id) }))
  }))
);
