
export class AppError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'AppError';
  }
}

export class ValidationError extends AppError {
  constructor(message: string) {
    super(message);
    this.name = 'ValidationError';
  }
}

export class AccountingError extends AppError {
  constructor(message: string) {
    super(message);
    this.name = 'AccountingError';
  }
}

export class InventoryError extends AppError {
  constructor(message: string) {
    super(message);
    this.name = 'InventoryError';
  }
}

export type UserRole = 'ADMIN' | 'PHARMACIST' | 'CASHIER';

export interface User {
  id: string;
  username: string;
  name: string;
  role: UserRole;
  isActive: boolean;
  lastLogin?: string;
  branchId?: string;
}

export type Permission = 
  | 'VIEW_FINANCE' 
  | 'MANAGE_INVENTORY' 
  | 'PERFORM_SALE' 
  | 'MANAGE_PURCHASE' 
  | 'SYSTEM_SETTINGS' 
  | 'MANAGE_USERS'
  | 'DELETE_RECORDS'
  | 'AUDIT_ACCESS';

export const ROLE_PERMISSIONS: Record<UserRole, Permission[]> = {
  ADMIN: [
    'VIEW_FINANCE', 'MANAGE_INVENTORY', 'PERFORM_SALE', 
    'MANAGE_PURCHASE', 'SYSTEM_SETTINGS', 'MANAGE_USERS', 
    'DELETE_RECORDS', 'AUDIT_ACCESS'
  ],
  PHARMACIST: [
    'MANAGE_INVENTORY', 'PERFORM_SALE', 'MANAGE_PURCHASE', 
    'VIEW_FINANCE', 'AUDIT_ACCESS'
  ],
  CASHIER: [
    'PERFORM_SALE', 'MANAGE_INVENTORY'
  ]
};

export type AccountType = 'ASSET' | 'LIABILITY' | 'EQUITY' | 'REVENUE' | 'EXPENSE';

export interface Account {
  id: string;
  code: string;
  name: string;
  type: AccountType;
  description?: string;
  isSystem?: boolean; 
  isActive: boolean;
  branchId?: string;
}

export interface InventoryBatch {
  batchNo: string;
  expiryDate: string;
  quantity: number;
}

export interface Product {
  id: string;
  ProductID: string; // Used in DB/Repositories
  product_id?: string; // Sometimes used
  Name: string; // Used in UI/DB
  name: string; // camelCase fallback
  category: string;
  Category?: string;
  UnitPrice: number;
  unitPrice: number;
  CostPrice: number;
  costPrice: number;
  StockQuantity: number;
  stockQuantity: number;
  quantityinstock?: number; // Used in some services
  MinLevel: number;
  minLevel: number;
  ExpiryDate: string;
  expiryDate: string;
  supplierId: string;
  SupplierID?: string;
  barcode?: string;
  costMethod: 'FIFO' | 'AVG';
  batches: InventoryBatch[];
  branchId?: string;
  lastModified?: string;
}

export type EntryStatus = 'Draft' | 'Posted';

export interface AccountingEntry {
  id: string;
  EntryID?: string; // Legacy ID field used in code
  sourceId: string;
  SourceID?: string; // Legacy ID field used in code
  sourceType: "SALE" | "PURCHASE" | "VOUCHER" | "COGS" | "MANUAL" | "ADJUSTMENT";
  EntryType?: string; // Legacy type field
  totalAmount: number;
  TotalAmount?: number; // Legacy total field
  status: EntryStatus;
  Status?: EntryStatus; // Legacy status field
  date: string;
  description: string;
  lines: JournalLine[];
  notes?: string;
  branchId: string;
}

export interface JournalLine {
  lineId: string;
  entryId: string;
  accountId: string;
  accountName: string;
  debit: number;
  credit: number;
  type: 'DEBIT' | 'CREDIT';
  amount: number;
}

export interface Sale {
  id: string;
  SaleID?: string; // Legacy ID field used in code
  sale_id?: string; // Used in some services
  Date: string; // Legacy date field
  date: string; // camelCase date
  customerId: string;
  CustomerID?: string; // Legacy customer field
  finalTotal: number;
  FinalTotal?: number; // Legacy total field
  paymentStatus: 'Cash' | 'Credit';
  PaymentStatus?: 'Cash' | 'Credit';
  totalCost: number;
  total_cost?: number; // used in accounting.service.ts
  branchId: string;
  subtotal: number;
  items: any[];
}

export interface Purchase {
  id: string;
  purchase_id?: string; // Used in some services
  invoiceId: string;
  date: string;
  partnerId: string;
  partnerName: string;
  totalAmount: number;
  total_amount?: number; // used in database.ts
  finalAmount: number;
  status: 'PAID' | 'UNPAID';
  branchId: string;
  items: any[];
}

export interface ToastMessage {
  id: string;
  message: string;
  type: 'success' | 'error' | 'info' | 'warning';
}

export interface AppNotification {
  id: string;
  title: string;
  message: string;
  type: 'EXPIRY' | 'STOCK' | 'SYSTEM' | 'FINANCE';
  severity: 'low' | 'medium' | 'high';
  date: string;
  isRead: boolean;
}

export interface Branch {
  id: string;
  name: string;
  location?: string;
  isMain?: boolean;
}

export interface Supplier {
  id: string;
  name: string;
  phone?: string;
  email?: string;
  contactPerson?: string;
  paymentTerms?: string;
  openingBalance: number;
  purchaseHistory: PurchaseRecord[];
}

export interface PurchaseRecord {
  id: string;
  date: string;
  amount: number;
  status: 'paid' | 'pending';
  items?: string[];
}

export interface SupplierLedgerEntry {
  id: string;
  date: string;
  description: string;
  debit: number;
  credit: number;
  runningBalance: number;
}

export interface PartnerLedgerEntry extends SupplierLedgerEntry {
  partnerId: string;
  referenceId?: string;
  type?: 'SALE' | 'PURCHASE' | 'PAYMENT' | 'RECEIPT';
}

export interface AuditLog {
  id: string;
  action: string;
  entity: string;
  details?: string;
  date: string;
  severity: 'info' | 'warning' | 'error' | 'critical';
  user?: string;
}

export interface IntegrityReport {
  isHealthy: boolean;
  totalDiff: number;
  timestamp: string;
  points: ReconciliationPoint[];
}

export interface ReconciliationPoint {
  id: string;
  label: string;
  status: 'balanced' | 'discrepancy' | 'critical';
  details: string;
  ledgerBalance: number;
  subledgerBalance: number;
  diff: number;
}

export interface Transaction {
  id: string;
  date: string;
  amount: number;
  type: 'sale' | 'purchase' | 'income' | 'expense';
  customer?: string;
  items?: any[];
}

export interface DailyAuditTask {
  date: string;
  completed: boolean;
  items: AuditItem[];
}

export interface AuditItem {
  itemId: string;
  name: string;
  bookQty: number;
  actualQty?: number;
  status: 'pending' | 'matched' | 'mismatch';
  reason?: string;
}

export interface PendingOperation {
  id: string;
  type: string;
  status: 'pending' | 'syncing' | 'failed' | 'success';
  payload: any;
  retries: number;
  createdAt: string;
  lastError?: string;
}

export interface BankTransaction {
  id: string;
  date: string;
  description: string;
  amount: number;
  type: 'DEBIT' | 'CREDIT';
  status: 'pending' | 'completed';
}

export interface BankAccount {
  id: string;
  bankName: string;
  accountNumber: string;
  lastSync?: string;
  status: 'connected' | 'disconnected' | 'error';
}

export interface PaymentGateway {
  id: string;
  name: string;
  provider: string;
  isActive: boolean;
  config: any;
}

export interface WebhookConfig {
  id: string;
  url: string;
  secret: string;
  events: string[];
  isActive: boolean;
}

export interface CartItem {
  id: string;
  product_id: string;
  name: string;
  qty: number;
  price: number;
  sum: number;
  note?: string;
  expiry?: string;
}

export interface CashFlow {
  transaction_id: string;
  date: string;
  type: 'دخل' | 'خرج';
  category: string;
  amount: number;
  notes?: string;
  branchId: string;
}

export interface AccountingPeriod {
  id: string;
  name: string;
  startDate: string;
  endDate: string;
  isClosed: boolean;
  closedBy?: string;
  closedAt?: string;
}
